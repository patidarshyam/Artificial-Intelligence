# 🚀 QUICK START - Get Real Fact-Checking in 5 Minutes

## Current Status: ✅ Working with Mock Data

Your system is **fully functional** right now! But for REAL fact-checking...

---

## Get FREE API Keys (Optional but Recommended)

### 1. Google Fact Check API (2 minutes)
```
1. Visit: https://console.cloud.google.com/
2. Enable "Fact Check Tools API"  
3. Create API Key
4. Copy key to config.py
```

### 2. NewsAPI (1 minute)
```
1. Visit: https://newsapi.org/register
2. Sign up (free)
3. Copy API key
4. Paste in config.py
```

### 3. Edit config.py
```python
# Open c:\PythonWS\DemoProjectUsingAgenticAI\config.py

GOOGLE_FACTCHECK_API_KEY = "paste-your-key-here"
NEWS_API_KEY = "paste-your-key-here"
```

### 4. Reload Browser
```
Just refresh http://localhost:8501
Should see: "✅ Real APIs Enabled!"
```

---

## 🧪 Test Claims (Try in UI)

### With APIs - These will hit real fact-checkers:
```
COVID-19 vaccines contain microchips for tracking.
```
→ Should be flagged as FALSE by real fact-checkers

```
Global temperatures have risen over the past century.
```
→ Should be confirmed as TRUE with high confidence

### Without APIs - Pattern detection still works:
```
SHOCKING news that will DESTROY everything! Sources say allegedly...
```
→ Bias detection works regardless of APIs!

---

## What You Get With Real APIs

| Feature | Mock Data | Real APIs |
|---------|-----------|-----------|
| Bias Detection | ✅ Yes | ✅ Yes |
| Language Analysis | ✅ Yes | ✅ Yes |
| Pattern Recognition | ✅ Yes | ✅ Yes |
| **Real Fact-Checks** | ❌ No | ✅ **Yes!** |
| **Live News Coverage** | ❌ No | ✅ **Yes!** |
| **Entity Verification** | ❌ Limited | ✅ **Yes!** |

---

## 💰 Cost

**Everything is FREE:**
- Google Fact Check: Free with generous limits
- NewsAPI: 100 requests/day free
- Wikidata: Unlimited, always free
- No credit card required!

---

## 📍 Your Current UI

**Running at:** http://localhost:8501

**Files to edit:**
```
config.py          ← Add API keys here
app.py             ← Main UI code
orchestrator.py    ← Agent coordinator
```

---

## ❓ FAQ

**Q: Do I need API keys to use the system?**  
A: No! It works now with pattern detection and mock data.

**Q: What's the benefit of API keys?**  
A: Real fact-checks from Snopes, PolitiFact, actual news verification.

**Q: Is setup difficult?**  
A: No - just copy/paste 2 API keys. Takes 3 minutes.

**Q: Will it cost money?**  
A: No! All APIs have free tiers that are plenty for testing.

---

## 🎯 Ready to Use RIGHT NOW

Your UI is live at: **http://localhost:8501**

1. Click example buttons (left sidebar)
2. Or paste any news snippet
3. Click "🔍 Verify News"
4. See instant analysis!

**Add API keys later for real fact-checking** 🚀
