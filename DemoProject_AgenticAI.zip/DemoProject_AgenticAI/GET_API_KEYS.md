# 🎯 Where to Get FREE API Keys

## 1. Google Fact Check Tools API

### Step-by-Step:

**A. Go to Google Cloud Console**
```
https://console.cloud.google.com/
```

**B. Create/Select Project**
- Click project dropdown at top
- Click "New Project"
- Name it (e.g., "NewsVerifier")

**C. Enable API**
- Click "APIs & Services" → "Enable APIs and Services"
- Search: "Fact Check Tools API"
- Click "Enable"

**D. Create Credentials**
- Go to "Credentials" (left menu)
- Click "Create Credentials" → "API Key"
- **Copy the key!**

**E. Paste in config.py**
```python
GOOGLE_FACTCHECK_API_KEY = "AIzaSyC..."  # Your key here
```

### What You Get:
- Fact-checks from **Snopes, PolitiFact, FactCheck.org**
- Ratings: True/False/Mixed/Misleading
- Publisher info and article links

---

## 2. NewsAPI.org

### Step-by-Step:

**A. Sign Up**
```
https://newsapi.org/register
```

**B. Fill Form**
- Email address
- Choose "I'm building for myself"
- Agree to terms

**C. Verify Email**
- Check inbox
- Click verification link

**D. Get Key**
- Login to dashboard
- Your API key is displayed at top
- **Copy it!**

**E. Paste in config.py**
```python
NEWS_API_KEY = "a1b2c3d4..."  # Your key here
```

### What You Get:
- 100 requests/day (free tier)
- 80,000+ sources
- Articles from Reuters, AP, BBC, CNN, etc.

---

## 3. Wikidata (No Key Needed!)

### Already Works!
- ✅ No registration required
- ✅ Unlimited requests
- ✅ Entity verification
- ✅ Structured factual data

---

## 🔒 Security Tips

### DO:
✅ Keep keys private
✅ Add `config.py` to `.gitignore`
✅ Use environment variables in production

### DON'T:
❌ Commit keys to GitHub
❌ Share keys publicly
❌ Use in client-side code

---

## ⚡ Quick Copy-Paste

Once you have both keys, edit `config.py`:

```python
# c:\PythonWS\DemoProjectUsingAgenticAI\config.py

GOOGLE_FACTCHECK_API_KEY = "paste-google-key-here"
NEWS_API_KEY = "paste-newsapi-key-here"
```

**Save file → Reload browser → Done!** 🎉

---

## ✅ Verify It's Working

After adding keys and reloading the UI, you should see:

```
✅ Real APIs Enabled! Using Google Fact Check, NewsAPI, and Wikidata
```

Try this claim:
```
COVID-19 vaccines contain microchips.
```

You should get **real fact-checks** from Snopes, PolitiFact, etc!

---

## ❓ Troubleshooting

### "API not enabled"
→ Make sure you clicked "Enable" in Google Cloud Console

### "Invalid API key"
→ Check for spaces before/after the key in config.py

### "Quota exceeded"
→ NewsAPI free tier is 100/day - wait 24hrs or upgrade

### Still showing mock data
→ Restart Streamlit: Ctrl+C then `streamlit run app.py`

---

## 📞 Need Help?

Check these resources:
- [Google Fact Check API Docs](https://developers.google.com/fact-check/tools/api)
- [NewsAPI Documentation](https://newsapi.org/docs)
- [Wikidata Query Service](https://query.wikidata.org/)

---

**Total setup time: ~3-5 minutes** ⏱️

**Cost: $0 (forever)** 💰
