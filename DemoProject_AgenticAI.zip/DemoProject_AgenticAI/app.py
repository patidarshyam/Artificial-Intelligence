"""Web UI using Streamlit - Interactive news verification interface."""

import streamlit as st
from orchestrator import NewsVerificationOrchestrator
import json
import config


# Page configuration
st.set_page_config(
    page_title="News Verification Assistant",
    page_icon="📰",
    layout="wide"
)

# Initialize orchestrator
@st.cache_resource
def get_orchestrator():
    # Check if API keys are configured
    google_key = config.GOOGLE_FACTCHECK_API_KEY
    news_key = config.NEWS_API_KEY
    
    use_real = bool(google_key or news_key)
    
    return NewsVerificationOrchestrator(
        use_real_apis=use_real,
        google_api_key=google_key,
        news_api_key=news_key
    ), use_real

orchestrator, using_real_apis = get_orchestrator()


# App header
st.title("📰 Multi-Agent News Verification Assistant")

# Show API status
if using_real_apis:
    st.success("✅ **Real APIs Enabled!** Using Google Fact Check, NewsAPI, and Wikidata")
else:
    st.warning("⚠️ **Mock Data Mode** - Configure API keys in `config.py` to use real fact-checking")

st.markdown("""
This AI-powered system analyzes news snippets using four specialized agents:
- **Claim Extraction** - Identifies verifiable claims
- **Cross-Check** - Verifies against fact-checking databases
- **Bias Detection** - Analyzes language for bias indicators
- **Verdict** - Synthesizes findings into reliability assessment
""")

st.divider()

# Sidebar with examples
st.sidebar.title("📋 Example Snippets")
st.sidebar.markdown("Click to load pre-made examples:")

examples = {
    "Verified Scientific News": """According to NASA and NOAA, global temperatures have risen significantly 
over the past century. The data shows a clear warming trend that scientists 
have confirmed through multiple independent studies. Research published in 
leading journals indicates this trend is consistent with climate change models.""",
    
    "Fake News / Conspiracy": """SHOCKING: Rumors suggest that the moon landing was faked! Anonymous sources 
claim there is evidence that allegedly proves the entire event never happened. 
This unbelievable conspiracy has been reportedly discussed by various groups. 
Sources say the truth is finally out!""",
    
    "Sensational Headline": """DEVASTATING news that will COMPLETELY destroy everything you thought you knew! 
This shocking revelation allegedly changes absolutely everything. Experts claim 
this unbelievable announcement will obliterate all opposition!""",
    
    "Well-Sourced Report": """The Reuters news agency reported that major economic policy changes were 
announced yesterday. The Associated Press and BBC also covered the story, 
citing official government statements. According to the announcement, 
the changes will take effect next quarter.""",
    
    "Mixed Content": """Scientists at major research institutions have confirmed rising global 
temperatures. Some experts believe this could lead to unexpected consequences 
in the future. The consensus among climatologists suggests immediate action 
is necessary, though opinions vary on the best approach."""
}

# Example buttons in sidebar
if 'news_text' not in st.session_state:
    st.session_state.news_text = ""

for example_name, example_text in examples.items():
    if st.sidebar.button(example_name):
        st.session_state.news_text = example_text

st.sidebar.divider()

if using_real_apis:
    st.sidebar.success("""
    **Real APIs Active!**
    
    This system is using:
    - Google Fact Check API
    - NewsAPI.org
    - Wikidata (always free)
    
    Results are from actual fact-checking sources.
    """)
else:
    st.sidebar.info("""
    **Demo Mode - Mock Data**
    
    To use REAL fact-checking:
    1. Edit `config.py`
    2. Add API keys:
       - Google Fact Check (free)
       - NewsAPI (free tier)
    3. Restart the app
    
    See config.py for instructions.
    """)

# Main input area
st.subheader("📝 Enter News Snippet")
news_snippet = st.text_area(
    "Paste or type the news text you want to verify:",
    value=st.session_state.news_text,
    height=200,
    placeholder="Enter news snippet here...",
    key="news_input"
)

# Verify button
col1, col2, col3 = st.columns([1, 1, 4])
with col1:
    verify_button = st.button("🔍 Verify News", type="primary", use_container_width=True)
with col2:
    clear_button = st.button("🗑️ Clear", use_container_width=True)

if clear_button:
    st.session_state.news_text = ""
    st.rerun()

# Process verification
if verify_button and news_snippet.strip():
    with st.spinner("🤖 Analyzing with multi-agent system..."):
        # Get verdict
        verdict_dict = orchestrator.verify_news(news_snippet, verbose=False)
        
        st.divider()
        
        # Display results
        st.header("📊 Verification Results")
        
        # Top-level verdict
        verdict = verdict_dict["verdict"]
        bias = verdict_dict["bias"]
        
        # Color coding for verdict
        verdict_colors = {
            "Reliable": "🟢",
            "Likely Reliable": "🟡",
            "Uncertain": "🟠",
            "Likely Unreliable": "🔴"
        }
        
        verdict_emoji = verdict_colors.get(verdict["label"], "⚪")
        
        # Main metrics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric(
                "Verdict",
                f"{verdict_emoji} {verdict['label']}",
                help="Overall reliability assessment"
            )
        
        with col2:
            st.metric(
                "Confidence",
                f"{verdict['confidence']:.0%}",
                help="Confidence in the verdict (0-100%)"
            )
        
        with col3:
            st.metric(
                "Reliability Score",
                f"{verdict['reliability_score']:.0%}",
                help="Computed reliability score (0-100%)"
            )
        
        # Tabs for detailed results
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📋 Summary", 
            "🔍 Claims", 
            "✅ Verification", 
            "⚖️ Bias Analysis",
            "📄 Full JSON"
        ])
        
        with tab1:
            st.subheader("Key Reasons")
            for reason in verdict["reasons"]:
                st.markdown(f"- {reason}")
            
            st.subheader("⚠️ Limitations")
            for limitation in verdict_dict["limitations"]:
                st.markdown(f"- {limitation}")
        
        with tab2:
            st.subheader(f"Extracted Claims ({len(verdict_dict['claims'])})")
            
            if verdict_dict["claims"]:
                for claim in verdict_dict["claims"]:
                    with st.expander(f"Claim #{claim['id']} - {claim['type'].title()}"):
                        st.write(claim["text"])
            else:
                st.info("No verifiable claims extracted from the snippet.")
        
        with tab3:
            st.subheader("Claim Verification Results")
            
            if verdict_dict["corroboration"]:
                for corr in verdict_dict["corroboration"]:
                    status_emoji = {
                        "supported": "✅",
                        "disputed": "❌",
                        "unverified": "❓"
                    }
                    
                    claim = next(c for c in verdict_dict["claims"] if c["id"] == corr["claim_id"])
                    
                    with st.expander(f"{status_emoji[corr['status']]} Claim #{corr['claim_id']} - {corr['status'].title()}"):
                        st.write(f"**Claim:** {claim['text']}")
                        st.write(f"**Status:** {corr['status'].title()}")
                        st.write(f"**Confidence:** {corr['confidence']:.0%}")
                        st.write(f"**Evidence Sources:** {corr['evidence_count']}")
            else:
                st.info("No claims to verify.")
        
        with tab4:
            st.subheader(f"Bias Assessment: {bias['level']}")
            st.metric("Bias Score", f"{bias['score']:.0%}", help="0% = No bias, 100% = Very biased")
            
            if bias["signals"]:
                st.write(f"**{len(bias['signals'])} bias signal(s) detected:**")
                for signal in bias["signals"]:
                    severity_emoji = {
                        "low": "🟢",
                        "medium": "🟡",
                        "high": "🔴"
                    }
                    emoji = severity_emoji.get(signal["severity"], "⚪")
                    st.markdown(f"{emoji} **{signal['type'].replace('_', ' ').title()}** - {signal['description']}")
            else:
                st.success("No significant bias indicators detected.")
        
        with tab5:
            st.subheader("Complete Analysis (JSON)")
            st.json(verdict_dict)

elif verify_button:
    st.warning("⚠️ Please enter a news snippet to verify.")

# Footer
st.divider()
st.markdown("""
<div style='text-align: center; color: gray; font-size: 0.9em;'>
    <p>Multi-Agent News Verification Assistant | Demo System with Mock Data Sources</p>
</div>
""", unsafe_allow_html=True)
