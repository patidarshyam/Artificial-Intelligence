"""Orchestrator - coordinates all agents for news verification."""

from typing import Dict, Optional
from agents.claim_extraction_agent import ClaimExtractionAgent
from agents.cross_check_agent import CrossCheckAgent
from agents.hybrid_cross_check_agent import HybridCrossCheckAgent
from agents.bias_detection_agent import BiasDetectionAgent
from agents.verdict_agent import VerdictAgent


class NewsVerificationOrchestrator:
    """
    Main orchestrator that coordinates the multi-agent news verification system.
    
    Workflow:
    1. Claim Extraction Agent extracts verifiable claims
    2. Cross-Check Agent verifies claims against data sources (mock or real APIs)
    3. Bias Detection Agent analyzes language bias
    4. Verdict Agent synthesizes findings into final verdict
    """
    
    def __init__(self, use_real_apis: bool = False, 
                 google_api_key: Optional[str] = None,
                 news_api_key: Optional[str] = None):
        """
        Initialize orchestrator.
        
        Args:
            use_real_apis: If True, use real API integrations (requires API keys)
            google_api_key: Google Fact Check API key (optional)
            news_api_key: NewsAPI.org API key (optional)
        """
        self.claim_agent = ClaimExtractionAgent()
        
        # Use hybrid agent if real APIs requested, otherwise use mock-only
        if use_real_apis or google_api_key or news_api_key:
            self.crosscheck_agent = HybridCrossCheckAgent(google_api_key, news_api_key)
            self.using_real_apis = True
        else:
            self.crosscheck_agent = CrossCheckAgent()
            self.using_real_apis = False
        
        self.bias_agent = BiasDetectionAgent()
        self.verdict_agent = VerdictAgent()
    
    def verify_news(self, snippet: str, verbose: bool = False) -> Dict:
        """
        Main entry point: verify a news snippet.
        
        Args:
            snippet: The news text to verify
            verbose: If True, print intermediate results
        
        Returns:
            Dict containing the final verdict with all analysis
        """
        if verbose:
            print(f"\n{'='*60}")
            print("NEWS VERIFICATION PROCESS")
            print(f"{'='*60}")
            print(f"\nInput Snippet ({len(snippet)} chars):")
            print(f"{snippet[:200]}..." if len(snippet) > 200 else snippet)
            print(f"\n{'-'*60}")
        
        # Step 1: Extract claims
        if verbose:
            print("\n[1/4] Extracting claims...")
        
        claims_result = self.claim_agent.extract_claims(snippet)
        
        if verbose:
            summary = self.claim_agent.get_summary(claims_result)
            print(f"      {summary}")
            if claims_result["claims"]:
                for claim in claims_result["claims"][:3]:  # Show first 3
                    print(f"      - [{claim['type']}] {claim['text'][:80]}...")
        
        # Step 2: Cross-check claims
        if verbose:
            print(f"\n[2/4] Cross-checking claims...")
        
        verification_result = self.crosscheck_agent.verify_claims(
            claims_result["claims"],
            snippet
        )
        
        if verbose:
            summary = self.crosscheck_agent.get_summary(verification_result)
            print(f"      {summary}")
            
            # Show API status if using real APIs
            if self.using_real_apis:
                data_sources = verification_result.get("data_sources_used", {})
                if data_sources.get("real_apis"):
                    print(f"      ✓ Real APIs used for verification")
                else:
                    api_status = data_sources.get("api_status", {})
                    if any(api_status.values()):
                        print(f"      ⚠ Real APIs configured but no results found")
                    else:
                        print(f"      ℹ No API keys configured, using mock data")
        
        # Step 3: Detect bias
        if verbose:
            print(f"\n[3/4] Analyzing bias...")
        
        bias_result = self.bias_agent.detect_bias(snippet, claims_result["claims"])
        
        if verbose:
            summary = self.bias_agent.get_summary(bias_result)
            print(f"      {summary}")
        
        # Step 4: Generate verdict
        if verbose:
            print(f"\n[4/4] Generating verdict...")
        
        verdict_dict = self.verdict_agent.generate_verdict(
            snippet,
            claims_result,
            verification_result,
            bias_result
        )
        
        if verbose:
            summary = self.verdict_agent.get_summary(verdict_dict)
            print(f"      {summary}")
            print(f"\n{'-'*60}")
        
        return verdict_dict
    
    def verify_and_format(self, snippet: str, verbose: bool = False) -> str:
        """
        Verify news and return formatted output (JSON + summary).
        
        Args:
            snippet: The news text to verify
            verbose: If True, print intermediate results
        
        Returns:
            Formatted string with JSON and human-readable summary
        """
        verdict_dict = self.verify_news(snippet, verbose)
        return self.verdict_agent.format_output(verdict_dict)
    
    def batch_verify(self, snippets: list, verbose: bool = False) -> list:
        """
        Verify multiple news snippets.
        
        Args:
            snippets: List of news texts to verify
            verbose: If True, print intermediate results
        
        Returns:
            List of verdict dicts
        """
        results = []
        
        for idx, snippet in enumerate(snippets, 1):
            if verbose:
                print(f"\n\n{'#'*60}")
                print(f"Processing snippet {idx}/{len(snippets)}")
                print(f"{'#'*60}")
            
            verdict = self.verify_news(snippet, verbose)
            results.append(verdict)
        
        return results
