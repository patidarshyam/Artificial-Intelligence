"""Mock FactCheckDB - simulates a fact-checking database."""

from datetime import datetime, timedelta
from typing import List, Dict, Optional


class FactCheckDB:
    """Simulates a fact-checking database with known claims."""
    
    def __init__(self):
        # Mock fact-check records
        self.records = [
            {
                "claim": "The moon landing was faked",
                "status": "false",
                "sources": ["NASA", "Independent researchers"],
                "confidence": 0.99,
                "last_updated": datetime.now() - timedelta(days=30)
            },
            {
                "claim": "COVID-19 vaccines have microchips",
                "status": "false",
                "sources": ["CDC", "WHO", "Multiple fact-checkers"],
                "confidence": 1.0,
                "last_updated": datetime.now() - timedelta(days=15)
            },
            {
                "claim": "Global temperatures have risen over the past century",
                "status": "true",
                "sources": ["NOAA", "NASA", "IPCC"],
                "confidence": 0.99,
                "last_updated": datetime.now() - timedelta(days=5)
            },
            {
                "claim": "Drinking water helps with hydration",
                "status": "true",
                "sources": ["Medical consensus"],
                "confidence": 1.0,
                "last_updated": datetime.now() - timedelta(days=100)
            }
        ]
    
    def check_claim(self, claim: str) -> Optional[Dict]:
        """
        Check if a claim exists in the database.
        Returns match if similarity is high enough (simple keyword matching).
        """
        claim_lower = claim.lower()
        
        for record in self.records:
            record_claim_lower = record["claim"].lower()
            # Simple keyword matching
            keywords = set(record_claim_lower.split())
            claim_keywords = set(claim_lower.split())
            
            # If significant overlap, consider it a match
            overlap = len(keywords.intersection(claim_keywords))
            if overlap >= min(3, len(keywords) * 0.5):
                return {
                    "matched_claim": record["claim"],
                    "status": record["status"],
                    "sources": record["sources"],
                    "confidence": record["confidence"],
                    "last_updated": record["last_updated"].isoformat()
                }
        
        return None
    
    def search_similar(self, claim: str) -> List[Dict]:
        """Search for similar claims in the database."""
        results = []
        claim_lower = claim.lower()
        
        for record in self.records:
            record_claim_lower = record["claim"].lower()
            keywords = set(record_claim_lower.split())
            claim_keywords = set(claim_lower.split())
            
            overlap = len(keywords.intersection(claim_keywords))
            if overlap >= 2:
                results.append({
                    "claim": record["claim"],
                    "status": record["status"],
                    "confidence": record["confidence"],
                    "relevance_score": overlap / max(len(keywords), len(claim_keywords))
                })
        
        return sorted(results, key=lambda x: x["relevance_score"], reverse=True)[:5]
