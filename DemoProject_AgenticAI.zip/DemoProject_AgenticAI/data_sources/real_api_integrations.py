"""Real API integrations for fact-checking and news verification."""

import requests
from typing import Dict, List, Optional
import json
from datetime import datetime


class GoogleFactCheckAPI:
    """
    Google Fact Check Tools API integration.
    Free API - requires API key from: https://console.cloud.google.com/
    """
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.base_url = "https://factchecktools.googleapis.com/v1alpha1/claims:search"
    
    def search_claims(self, query: str, language: str = "en") -> List[Dict]:
        """
        Search for fact-checks using Google Fact Check API.
        
        Args:
            query: The claim to fact-check
            language: Language code (default: en)
        
        Returns:
            List of fact-check results
        """
        if not self.api_key:
            return []
        
        try:
            params = {
                "key": self.api_key,
                "query": query,
                "languageCode": language
            }
            
            response = requests.get(self.base_url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return self._parse_results(data)
            else:
                print(f"Google Fact Check API error: {response.status_code}")
                return []
        
        except Exception as e:
            print(f"Error calling Google Fact Check API: {e}")
            return []
    
    def _parse_results(self, data: Dict) -> List[Dict]:
        """Parse Google API response."""
        results = []
        
        if "claims" not in data:
            return results
        
        for claim_review in data["claims"]:
            result = {
                "claim_text": claim_review.get("text", ""),
                "claimant": claim_review.get("claimant", "Unknown"),
                "reviews": []
            }
            
            for review in claim_review.get("claimReview", []):
                result["reviews"].append({
                    "publisher": review.get("publisher", {}).get("name", "Unknown"),
                    "url": review.get("url", ""),
                    "title": review.get("title", ""),
                    "rating": review.get("textualRating", ""),
                    "language": review.get("languageCode", "en")
                })
            
            results.append(result)
        
        return results


class NewsAPIIntegration:
    """
    NewsAPI.org integration for source verification.
    Free tier: 100 requests/day - Get key at: https://newsapi.org/
    """
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.base_url = "https://newsapi.org/v2/everything"
    
    def search_news(self, query: str, days: int = 7) -> List[Dict]:
        """
        Search news articles related to a claim.
        
        Args:
            query: Search query
            days: Number of days to search back
        
        Returns:
            List of news articles
        """
        if not self.api_key:
            return []
        
        try:
            params = {
                "apiKey": self.api_key,
                "q": query,
                "language": "en",
                "sortBy": "relevancy",
                "pageSize": 10
            }
            
            response = requests.get(self.base_url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return self._parse_articles(data)
            else:
                print(f"NewsAPI error: {response.status_code}")
                return []
        
        except Exception as e:
            print(f"Error calling NewsAPI: {e}")
            return []
    
    def _parse_articles(self, data: Dict) -> List[Dict]:
        """Parse NewsAPI response."""
        articles = []
        
        if "articles" not in data:
            return articles
        
        for article in data["articles"]:
            articles.append({
                "title": article.get("title", ""),
                "source": article.get("source", {}).get("name", "Unknown"),
                "author": article.get("author", "Unknown"),
                "description": article.get("description", ""),
                "url": article.get("url", ""),
                "published_at": article.get("publishedAt", ""),
                "content": article.get("content", "")
            })
        
        return articles


class WikidataAPI:
    """
    Free Wikidata API for entity verification and fact-checking.
    No API key required.
    """
    
    def __init__(self):
        self.search_url = "https://www.wikidata.org/w/api.php"
        self.entity_url = "https://www.wikidata.org/wiki/Special:EntityData/{}.json"
    
    def search_entity(self, query: str) -> List[Dict]:
        """
        Search for entities in Wikidata.
        
        Args:
            query: Entity to search for
        
        Returns:
            List of matching entities
        """
        try:
            params = {
                "action": "wbsearchentities",
                "format": "json",
                "language": "en",
                "search": query,
                "limit": 5
            }
            
            response = requests.get(self.search_url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return data.get("search", [])
            
            return []
        
        except Exception as e:
            print(f"Error calling Wikidata API: {e}")
            return []
    
    def get_entity_claims(self, entity_id: str) -> Dict:
        """Get claims/facts about an entity."""
        try:
            url = self.entity_url.format(entity_id)
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            
            return {}
        
        except Exception as e:
            print(f"Error getting entity data: {e}")
            return {}


class OpenSourceFactChecker:
    """
    Combines multiple open-source APIs for comprehensive fact-checking.
    """
    
    def __init__(self, google_api_key: Optional[str] = None, 
                 news_api_key: Optional[str] = None):
        self.google_fc = GoogleFactCheckAPI(google_api_key)
        self.news_api = NewsAPIIntegration(news_api_key)
        self.wikidata = WikidataAPI()
    
    def check_claim(self, claim: str) -> Dict:
        """
        Comprehensive fact-check using multiple sources.
        
        Args:
            claim: The claim to fact-check
        
        Returns:
            Combined results from all sources
        """
        results = {
            "claim": claim,
            "timestamp": datetime.now().isoformat(),
            "sources": {}
        }
        
        # Google Fact Check
        google_results = self.google_fc.search_claims(claim)
        if google_results:
            results["sources"]["google_factcheck"] = {
                "available": True,
                "results_count": len(google_results),
                "results": google_results[:3]  # Top 3
            }
        else:
            results["sources"]["google_factcheck"] = {
                "available": False,
                "message": "No fact-checks found or API key not configured"
            }
        
        # NewsAPI verification
        news_results = self.news_api.search_news(claim)
        if news_results:
            results["sources"]["news_articles"] = {
                "available": True,
                "articles_found": len(news_results),
                "top_sources": [a["source"] for a in news_results[:5]]
            }
        else:
            results["sources"]["news_articles"] = {
                "available": False,
                "message": "No articles found or API key not configured"
            }
        
        # Wikidata entities
        entities = self.wikidata.search_entity(claim)
        if entities:
            results["sources"]["wikidata"] = {
                "available": True,
                "entities_found": len(entities),
                "top_entities": [
                    {"id": e["id"], "label": e.get("label", ""), "description": e.get("description", "")}
                    for e in entities[:3]
                ]
            }
        else:
            results["sources"]["wikidata"] = {
                "available": True,
                "entities_found": 0
            }
        
        return results
    
    def get_api_status(self) -> Dict:
        """Check which APIs are configured and available."""
        return {
            "google_factcheck": self.google_fc.api_key is not None,
            "news_api": self.news_api.api_key is not None,
            "wikidata": True  # Always available (no key needed)
        }
