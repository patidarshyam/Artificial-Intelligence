"""Mock data sources for news verification."""
