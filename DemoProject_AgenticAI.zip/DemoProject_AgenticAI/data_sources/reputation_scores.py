"""Mock ReputationScores - simulates source credibility ratings."""

from typing import Dict, Optional


class ReputationScores:
    """Simulates a source credibility rating system."""
    
    def __init__(self):
        # Comprehensive reputation database
        self.scores = {
            # High credibility (0.85-1.0)
            "reuters": {
                "overall": 0.95,
                "accuracy": 0.96,
                "transparency": 0.94,
                "editorial_standards": 0.95,
                "fact_checking": 0.97
            },
            "ap_news": {
                "overall": 0.94,
                "accuracy": 0.95,
                "transparency": 0.93,
                "editorial_standards": 0.94,
                "fact_checking": 0.95
            },
            "bbc": {
                "overall": 0.90,
                "accuracy": 0.91,
                "transparency": 0.89,
                "editorial_standards": 0.90,
                "fact_checking": 0.90
            },
            
            # Moderate credibility (0.70-0.84)
            "nyt": {
                "overall": 0.85,
                "accuracy": 0.86,
                "transparency": 0.83,
                "editorial_standards": 0.85,
                "fact_checking": 0.86
            },
            "wsj": {
                "overall": 0.83,
                "accuracy": 0.84,
                "transparency": 0.81,
                "editorial_standards": 0.84,
                "fact_checking": 0.83
            },
            "guardian": {
                "overall": 0.82,
                "accuracy": 0.83,
                "transparency": 0.80,
                "editorial_standards": 0.82,
                "fact_checking": 0.83
            },
            "cnn": {
                "overall": 0.70,
                "accuracy": 0.72,
                "transparency": 0.68,
                "editorial_standards": 0.70,
                "fact_checking": 0.71
            },
            "fox_news": {
                "overall": 0.68,
                "accuracy": 0.69,
                "transparency": 0.65,
                "editorial_standards": 0.68,
                "fact_checking": 0.70
            },
            
            # Low credibility (below 0.70)
            "unknown_blog": {
                "overall": 0.30,
                "accuracy": 0.35,
                "transparency": 0.25,
                "editorial_standards": 0.30,
                "fact_checking": 0.30
            },
            "social_media_post": {
                "overall": 0.20,
                "accuracy": 0.25,
                "transparency": 0.15,
                "editorial_standards": 0.20,
                "fact_checking": 0.20
            }
        }
    
    def get_score(self, source: str) -> Optional[Dict]:
        """Get reputation scores for a source."""
        source_key = source.lower().replace(" ", "_")
        return self.scores.get(source_key)
    
    def get_overall_score(self, source: str) -> float:
        """Get just the overall reputation score."""
        scores = self.get_score(source)
        if scores:
            return scores["overall"]
        # Unknown source gets default low score
        return 0.40
    
    def classify_credibility(self, score: float) -> str:
        """Classify credibility level based on score."""
        if score >= 0.85:
            return "High"
        elif score >= 0.70:
            return "Moderate"
        elif score >= 0.50:
            return "Low"
        else:
            return "Very Low"
    
    def aggregate_source_credibility(self, sources: list) -> Dict:
        """Calculate aggregate credibility from multiple sources."""
        if not sources:
            return {
                "average_score": 0.0,
                "classification": "Unknown",
                "source_count": 0
            }
        
        scores = [self.get_overall_score(s) for s in sources]
        avg_score = sum(scores) / len(scores)
        
        return {
            "average_score": round(avg_score, 2),
            "classification": self.classify_credibility(avg_score),
            "source_count": len(sources),
            "score_range": (round(min(scores), 2), round(max(scores), 2))
        }
