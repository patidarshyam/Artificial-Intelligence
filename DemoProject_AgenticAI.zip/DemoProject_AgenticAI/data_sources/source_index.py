"""Mock SourceIndex - simulates a database of news sources and their coverage."""

from datetime import datetime, timedelta
from typing import List, Dict, Optional
import random


class SourceIndex:
    """Simulates an index of news sources and their article coverage."""
    
    def __init__(self):
        # Mock source database
        self.sources = {
            "reuters": {"reputation": 0.95, "bias_score": 0.1},
            "ap_news": {"reputation": 0.94, "bias_score": 0.1},
            "bbc": {"reputation": 0.90, "bias_score": 0.15},
            "nyt": {"reputation": 0.85, "bias_score": 0.25},
            "wsj": {"reputation": 0.83, "bias_score": 0.30},
            "cnn": {"reputation": 0.70, "bias_score": 0.45},
            "fox_news": {"reputation": 0.68, "bias_score": 0.50},
            "guardian": {"reputation": 0.82, "bias_score": 0.35},
            "unknown_blog": {"reputation": 0.30, "bias_score": 0.70}
        }
        
        # Mock article index (claim -> sources that covered it)
        self.coverage = {
            "climate change research": ["reuters", "ap_news", "bbc", "nyt", "guardian"],
            "economic policy": ["wsj", "reuters", "nyt", "bbc"],
            "celebrity gossip": ["unknown_blog"],
            "scientific study": ["reuters", "ap_news", "bbc"],
            "political statement": ["cnn", "fox_news", "nyt", "wsj"]
        }
    
    def find_coverage(self, claim: str) -> List[Dict]:
        """
        Find which sources have covered a claim.
        Returns list of sources with their reputation and article details.
        """
        results = []
        claim_lower = claim.lower()
        
        # Simple keyword matching against coverage topics
        for topic, sources in self.coverage.items():
            keywords = set(topic.split())
            claim_keywords = set(claim_lower.split())
            
            overlap = len(keywords.intersection(claim_keywords))
            if overlap >= 1:
                for source in sources:
                    if source in self.sources:
                        results.append({
                            "source": source,
                            "reputation": self.sources[source]["reputation"],
                            "bias_score": self.sources[source]["bias_score"],
                            "topic": topic,
                            "published": (datetime.now() - timedelta(days=random.randint(1, 30))).isoformat(),
                            "relevance": overlap / max(len(keywords), len(claim_keywords))
                        })
        
        return sorted(results, key=lambda x: x["relevance"] * x["reputation"], reverse=True)[:10]
    
    def get_source_reputation(self, source: str) -> Optional[float]:
        """Get the reputation score for a source."""
        source_key = source.lower().replace(" ", "_")
        if source_key in self.sources:
            return self.sources[source_key]["reputation"]
        return None
    
    def count_independent_sources(self, sources: List[str]) -> int:
        """Count how many are truly independent (simplified)."""
        # In reality, would check ownership, etc.
        return len(set(sources))
