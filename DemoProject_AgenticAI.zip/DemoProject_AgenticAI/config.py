"""Configuration file for API keys and settings."""

# ============================================================================
# REAL API CONFIGURATION
# ============================================================================

# Google Fact Check Tools API
# Get your free API key at: https://console.cloud.google.com/
# Enable "Fact Check Tools API" in your Google Cloud Console
GOOGLE_FACTCHECK_API_KEY = None  # Replace with: "YOUR_API_KEY_HERE"

# NewsAPI.org
# Get your free API key at: https://newsapi.org/register
# Free tier: 100 requests/day
NEWS_API_KEY = None  # Replace with: "YOUR_API_KEY_HERE"

# ============================================================================
# USAGE INSTRUCTIONS
# ============================================================================

"""
To use REAL fact-checking APIs:

1. Google Fact Check API (Free):
   - Go to: https://console.cloud.google.com/
   - Create a project or select existing
   - Enable "Fact Check Tools API"
   - Create credentials (API Key)
   - Copy the key and paste above

2. NewsAPI (Free tier - 100 req/day):
   - Go to: https://newsapi.org/register
   - Sign up for free account
   - Copy your API key
   - Paste above

3. Wikidata API:
   - No key needed! Always available

After adding keys, the system will automatically use REAL data sources!
If no keys are provided, system falls back to mock data.
"""

# ============================================================================
# HOW TO SET API KEYS
# ============================================================================

# Option 1: Edit this file directly
# GOOGLE_FACTCHECK_API_KEY = "your-key-here"
# NEWS_API_KEY = "your-key-here"

# Option 2: Use environment variables (recommended for production)
import os
if not GOOGLE_FACTCHECK_API_KEY:
    GOOGLE_FACTCHECK_API_KEY = os.getenv("GOOGLE_FACTCHECK_API_KEY")
if not NEWS_API_KEY:
    NEWS_API_KEY = os.getenv("NEWS_API_KEY")
