"""Claim Extraction Agent - extracts verifiable claims from news snippets."""

import re
from typing import List, Dict


class ClaimExtractionAgent:
    """Extracts structured, verifiable claims from text."""
    
    def __init__(self):
        # Keywords that often indicate factual claims
        self.factual_indicators = [
            "according to", "research shows", "study finds", "data shows",
            "reported that", "announced", "confirmed", "stated",
            "experts say", "scientists", "percent", "%", "million", "billion"
        ]
        
        # Keywords that indicate opinions/speculation
        self.opinion_indicators = [
            "i think", "i believe", "in my opinion", "might", "could",
            "perhaps", "possibly", "seems", "appears", "allegedly"
        ]
    
    def extract_claims(self, snippet: str) -> Dict:
        """
        Extract verifiable claims from a news snippet.
        
        Returns:
            Dict with extracted claims and metadata
        """
        claims = []
        sentences = self._split_sentences(snippet)
        
        for idx, sentence in enumerate(sentences):
            claim_type = self._classify_sentence(sentence)
            
            if claim_type in ["factual", "statistical"]:
                claim = {
                    "id": idx + 1,
                    "text": sentence.strip(),
                    "type": claim_type,
                    "confidence": self._calculate_confidence(sentence),
                    "contains_numbers": self._contains_numbers(sentence),
                    "named_entities": self._extract_entities(sentence)
                }
                claims.append(claim)
        
        return {
            "claims": claims,
            "total_claims": len(claims),
            "snippet_length": len(snippet),
            "claim_density": len(claims) / max(len(sentences), 1)
        }
    
    def _split_sentences(self, text: str) -> List[str]:
        """Split text into sentences."""
        # Simple sentence splitting
        sentences = re.split(r'[.!?]+', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _classify_sentence(self, sentence: str) -> str:
        """Classify a sentence as factual, opinion, or other."""
        sentence_lower = sentence.lower()
        
        # Check for opinion indicators
        for indicator in self.opinion_indicators:
            if indicator in sentence_lower:
                return "opinion"
        
        # Check for statistical claims
        if re.search(r'\d+\s*%|\d+\s*(million|billion|thousand)', sentence_lower):
            return "statistical"
        
        # Check for factual indicators
        for indicator in self.factual_indicators:
            if indicator in sentence_lower:
                return "factual"
        
        # If sentence contains specific dates, names, or numbers
        if re.search(r'\d{4}|[A-Z][a-z]+ \d+', sentence):
            return "factual"
        
        return "other"
    
    def _calculate_confidence(self, sentence: str) -> float:
        """Calculate confidence that this is a verifiable claim."""
        confidence = 0.5  # Base confidence
        
        sentence_lower = sentence.lower()
        
        # Increase confidence for factual indicators
        for indicator in self.factual_indicators:
            if indicator in sentence_lower:
                confidence += 0.1
        
        # Decrease confidence for opinion indicators
        for indicator in self.opinion_indicators:
            if indicator in sentence_lower:
                confidence -= 0.2
        
        # Increase confidence for numbers
        if self._contains_numbers(sentence):
            confidence += 0.15
        
        # Increase confidence for proper nouns (names, places)
        if re.search(r'[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*', sentence):
            confidence += 0.1
        
        return max(0.0, min(1.0, confidence))
    
    def _contains_numbers(self, sentence: str) -> bool:
        """Check if sentence contains numerical data."""
        return bool(re.search(r'\d+', sentence))
    
    def _extract_entities(self, sentence: str) -> List[str]:
        """Extract named entities (simplified)."""
        # Simple pattern matching for capitalized words (potential names/places)
        entities = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', sentence)
        
        # Filter out sentence-initial words and common words
        filtered = []
        for entity in entities:
            # Skip if it's likely a sentence start
            if not sentence.strip().startswith(entity):
                filtered.append(entity)
            elif len(entity.split()) > 1:  # Multi-word entities are more likely to be names
                filtered.append(entity)
        
        return filtered[:5]  # Limit to top 5
    
    def get_summary(self, extraction_result: Dict) -> str:
        """Generate a human-readable summary of extracted claims."""
        claims = extraction_result["claims"]
        total = extraction_result["total_claims"]
        
        if total == 0:
            return "No verifiable claims found."
        
        factual = sum(1 for c in claims if c["type"] == "factual")
        statistical = sum(1 for c in claims if c["type"] == "statistical")
        
        summary = f"Extracted {total} verifiable claim(s): "
        summary += f"{factual} factual, {statistical} statistical."
        
        return summary
