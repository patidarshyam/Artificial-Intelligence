"""Verdict Agent - synthesizes all findings into a final reliability verdict."""

from typing import Dict, List
import json


class VerdictAgent:
    """Produces final reliability verdict based on all agent findings."""
    
    def __init__(self):
        pass
    
    def generate_verdict(
        self,
        snippet: str,
        claims_result: Dict,
        verification_result: Dict,
        bias_result: Dict
    ) -> Dict:
        """
        Generate final verdict based on all agent outputs.
        
        Returns:
            Dict with structured verdict including label, confidence, and rationale
        """
        # Extract key metrics
        claims = claims_result["claims"]
        corroboration = verification_result["corroboration"]
        credibility = verification_result["overall_credibility"]
        bias = bias_result["bias"]
        
        # Calculate reliability score
        reliability_score = self._calculate_reliability(
            credibility["score"],
            bias["score"],
            verification_result["summary"]
        )
        
        # Determine verdict label
        verdict_label = self._determine_label(reliability_score, credibility, bias)
        
        # Calculate confidence
        confidence = self._calculate_confidence(
            claims,
            corroboration,
            credibility,
            bias
        )
        
        # Generate reasons
        reasons = self._generate_reasons(
            claims,
            verification_result,
            bias,
            reliability_score
        )
        
        # Identify limitations
        limitations = self._identify_limitations(
            claims,
            corroboration,
            bias
        )
        
        # Build structured output
        verdict_dict = {
            "snippet": snippet,
            "claims": [
                {
                    "id": c["id"],
                    "text": c["text"],
                    "type": c["type"]
                } for c in claims
            ],
            "corroboration": [
                {
                    "claim_id": c["claim_id"],
                    "status": c["status"],
                    "confidence": c["confidence"],
                    "evidence_count": len(c["evidence"])
                } for c in corroboration
            ],
            "bias": {
                "score": bias["score"],
                "level": bias["level"],
                "signals": [
                    {
                        "type": s["type"],
                        "severity": s.get("severity", "medium"),
                        "description": s["description"]
                    } for s in bias["signals"]
                ]
            },
            "verdict": {
                "label": verdict_label,
                "confidence": confidence,
                "reliability_score": reliability_score,
                "reasons": reasons
            },
            "limitations": limitations
        }
        
        return verdict_dict
    
    def _calculate_reliability(
        self,
        credibility_score: float,
        bias_score: float,
        verification_summary: Dict
    ) -> float:
        """Calculate overall reliability score."""
        # Higher credibility = higher reliability
        # Higher bias = lower reliability
        # More supported claims = higher reliability
        
        total = verification_summary["total"]
        if total == 0:
            return 0.5
        
        supported_ratio = verification_summary["supported"] / total
        disputed_ratio = verification_summary["disputed"] / total
        
        # Weighted combination
        reliability = (
            credibility_score * 0.40 +           # Evidence quality
            (1 - bias_score) * 0.25 +            # Neutrality
            supported_ratio * 0.25 +             # Verification
            (1 - disputed_ratio) * 0.10          # No false claims
        )
        
        return round(reliability, 2)
    
    def _determine_label(
        self,
        reliability_score: float,
        credibility: Dict,
        bias: Dict
    ) -> str:
        """Determine verdict label."""
        # Consider both reliability and special conditions
        
        # Check for disqualifying factors
        if credibility["level"] == "Very Low":
            return "Likely Unreliable"
        
        if bias["score"] >= 0.75:
            return "Uncertain"  # Too biased to assess objectively
        
        # Base on reliability score
        if reliability_score >= 0.75:
            return "Reliable"
        elif reliability_score >= 0.60:
            return "Likely Reliable"
        elif reliability_score >= 0.40:
            return "Uncertain"
        else:
            return "Likely Unreliable"
    
    def _calculate_confidence(
        self,
        claims: List[Dict],
        corroboration: List[Dict],
        credibility: Dict,
        bias: Dict
    ) -> float:
        """Calculate confidence in the verdict."""
        confidence = 0.5  # Base confidence
        
        # More claims = higher confidence (up to a point)
        if len(claims) >= 2:
            confidence += 0.1
        if len(claims) >= 4:
            confidence += 0.1
        
        # Strong evidence increases confidence
        high_conf_verifications = sum(1 for c in corroboration if c["confidence"] >= 0.75)
        if high_conf_verifications >= 2:
            confidence += 0.15
        
        # Clear credibility signal increases confidence
        if credibility["level"] in ["High", "Very Low"]:
            confidence += 0.10
        
        # Low bias increases confidence in assessment
        if bias["score"] < 0.3:
            confidence += 0.10
        
        # Unverified claims decrease confidence
        unverified = sum(1 for c in corroboration if c["status"] == "unverified")
        if unverified > 0 and len(corroboration) > 0:
            confidence -= (unverified / len(corroboration)) * 0.15
        
        return round(max(0.0, min(1.0, confidence)), 2)
    
    def _generate_reasons(
        self,
        claims: List[Dict],
        verification_result: Dict,
        bias: Dict,
        reliability_score: float
    ) -> List[str]:
        """Generate bullet-point reasons for the verdict."""
        reasons = []
        
        summary = verification_result["summary"]
        credibility = verification_result["overall_credibility"]
        
        # Verification status
        if summary["supported"] > 0:
            reasons.append(
                f"{summary['supported']}/{summary['total']} claim(s) supported by evidence"
            )
        
        if summary["disputed"] > 0:
            reasons.append(
                f"{summary['disputed']} claim(s) disputed by fact-checkers"
            )
        
        # Credibility
        reasons.append(f"Source credibility: {credibility['level']} ({credibility['score']})")
        
        # Bias
        if bias["score"] < 0.3:
            reasons.append("Minimal bias detected in language")
        elif bias["score"] >= 0.6:
            reasons.append(f"Significant bias detected ({bias['level']}, score: {bias['score']})")
        
        # Corroboration details
        high_quality_evidence = sum(
            1 for c in verification_result["corroboration"]
            if c["confidence"] >= 0.75
        )
        if high_quality_evidence >= 2:
            reasons.append(f"Multiple high-confidence verifications ({high_quality_evidence})")
        
        # Limit to 6 reasons
        return reasons[:6]
    
    def _identify_limitations(
        self,
        claims: List[Dict],
        corroboration: List[Dict],
        bias: Dict
    ) -> List[str]:
        """Identify limitations of the analysis."""
        limitations = []
        
        # Unverified claims
        unverified = sum(1 for c in corroboration if c["status"] == "unverified")
        if unverified > 0:
            limitations.append(
                f"{unverified} claim(s) could not be verified against available sources"
            )
        
        # Limited sources
        low_source_count = sum(1 for c in corroboration if c["source_count"] < 2)
        if low_source_count > 0:
            limitations.append(
                f"{low_source_count} claim(s) have limited source coverage"
            )
        
        # No claims extracted
        if len(claims) == 0:
            limitations.append("No verifiable claims extracted from snippet")
        
        # High bias might affect objectivity
        if bias["score"] >= 0.6:
            limitations.append("High bias may obscure factual content")
        
        # General limitations
        limitations.append("Analysis based on mock data sources")
        limitations.append("Recency and paywalled sources not considered")
        
        return limitations[:6]
    
    def format_output(self, verdict_dict: Dict) -> str:
        """Format verdict as JSON + human-readable summary."""
        # JSON output
        json_output = json.dumps(verdict_dict, indent=2)
        
        # Human-readable summary
        verdict = verdict_dict["verdict"]
        summary = f"\n{'='*60}\n"
        summary += "NEWS VERIFICATION VERDICT\n"
        summary += f"{'='*60}\n\n"
        summary += f"Verdict: {verdict['label']}\n"
        summary += f"Confidence: {verdict['confidence']:.2f}\n"
        summary += f"Reliability Score: {verdict['reliability_score']:.2f}\n\n"
        summary += "Key Reasons:\n"
        for reason in verdict["reasons"]:
            summary += f"  • {reason}\n"
        
        if verdict_dict["limitations"]:
            summary += "\nLimitations:\n"
            for limitation in verdict_dict["limitations"]:
                summary += f"  • {limitation}\n"
        
        summary += f"\n{'='*60}\n"
        
        return json_output + "\n" + summary
    
    def get_summary(self, verdict_dict: Dict) -> str:
        """Get brief summary."""
        verdict = verdict_dict["verdict"]
        return f"Verdict: {verdict['label']} (confidence: {verdict['confidence']}, reliability: {verdict['reliability_score']})"
