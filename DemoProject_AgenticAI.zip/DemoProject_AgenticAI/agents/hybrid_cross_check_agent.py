"""Hybrid agent that uses both mock and real APIs for cross-checking."""

from typing import List, Dict, Optional
from data_sources.fact_check_db import FactCheckDB
from data_sources.source_index import SourceIndex
from data_sources.reputation_scores import ReputationScores
from data_sources.real_api_integrations import OpenSourceFactChecker


class HybridCrossCheckAgent:
    """
    Enhanced cross-check agent that uses both mock data and real APIs.
    Falls back to mock data if APIs are not configured.
    """
    
    def __init__(self, google_api_key: Optional[str] = None, 
                 news_api_key: Optional[str] = None):
        # Mock sources (always available)
        self.fact_db = FactCheckDB()
        self.source_index = SourceIndex()
        self.reputation = ReputationScores()
        
        # Real API integration
        self.real_checker = OpenSourceFactChecker(google_api_key, news_api_key)
        self.api_status = self.real_checker.get_api_status()
    
    def verify_claims(self, claims: List[Dict], snippet: str) -> Dict:
        """
        Cross-check claims using both mock and real sources.
        """
        results = []
        real_api_used = False
        
        for claim in claims:
            verification = self._verify_single_claim(claim)
            results.append(verification)
            if verification.get("real_api_data"):
                real_api_used = True
        
        # Calculate overall corroboration metrics
        supported = sum(1 for r in results if r["status"] == "supported")
        disputed = sum(1 for r in results if r["status"] == "disputed")
        unverified = sum(1 for r in results if r["status"] == "unverified")
        
        return {
            "corroboration": results,
            "summary": {
                "supported": supported,
                "disputed": disputed,
                "unverified": unverified,
                "total": len(results)
            },
            "overall_credibility": self._calculate_overall_credibility(results),
            "data_sources_used": {
                "real_apis": real_api_used,
                "mock_data": True,
                "api_status": self.api_status
            }
        }
    
    def _verify_single_claim(self, claim: Dict) -> Dict:
        """Verify using both real APIs and mock data."""
        claim_text = claim["text"]
        
        # Try real APIs first
        real_data = None
        if any(self.api_status.values()):
            try:
                real_data = self.real_checker.check_claim(claim_text)
            except Exception as e:
                print(f"Real API error: {e}")
        
        # Check mock fact-checking database
        fact_check = self.fact_db.check_claim(claim_text)
        
        # Find source coverage (mock)
        coverage = self.source_index.find_coverage(claim_text)
        
        # Determine status
        status = "unverified"
        evidence = []
        confidence = 0.0
        
        # Process real API results
        if real_data and real_data.get("sources"):
            google_fc = real_data["sources"].get("google_factcheck", {})
            news_articles = real_data["sources"].get("news_articles", {})
            
            # Google Fact Check results
            if google_fc.get("available") and google_fc.get("results_count", 0) > 0:
                google_results = google_fc.get("results", [])
                if google_results:
                    # Analyze ratings from fact-checkers
                    ratings = []
                    for result in google_results:
                        for review in result.get("reviews", []):
                            rating = review.get("rating", "").lower()
                            ratings.append(rating)
                    
                    # Determine status from ratings
                    false_keywords = ["false", "incorrect", "misleading", "disputed"]
                    true_keywords = ["true", "correct", "verified", "accurate"]
                    
                    false_count = sum(1 for r in ratings if any(k in r for k in false_keywords))
                    true_count = sum(1 for r in ratings if any(k in r for k in true_keywords))
                    
                    if true_count > false_count:
                        status = "supported"
                        confidence = min(0.95, 0.7 + (true_count * 0.1))
                    elif false_count > 0:
                        status = "disputed"
                        confidence = min(0.95, 0.7 + (false_count * 0.1))
                    
                    evidence.append({
                        "type": "real_fact_check",
                        "source": "Google Fact Check API",
                        "results_count": len(google_results),
                        "fact_checkers": [r["reviews"][0]["publisher"] for r in google_results if r.get("reviews")],
                        "confidence": confidence
                    })
            
            # NewsAPI results
            if news_articles.get("available") and news_articles.get("articles_found", 0) > 0:
                evidence.append({
                    "type": "real_news_coverage",
                    "source": "NewsAPI",
                    "articles_found": news_articles["articles_found"],
                    "top_sources": news_articles.get("top_sources", [])
                })
                
                # If multiple reputable sources cover it, increase confidence
                if status == "unverified" and news_articles["articles_found"] >= 3:
                    status = "supported"
                    confidence = 0.65
        
        # Fallback to mock data if no real API results
        if not evidence:
            if fact_check:
                if fact_check["status"] == "true":
                    status = "supported"
                    confidence = fact_check["confidence"]
                elif fact_check["status"] == "false":
                    status = "disputed"
                    confidence = fact_check["confidence"]
                
                evidence.append({
                    "type": "mock_fact_check",
                    "source": "FactCheckDB (Mock)",
                    "matched_claim": fact_check["matched_claim"],
                    "verdict": fact_check["status"],
                    "confidence": fact_check["confidence"]
                })
            
            # Check mock source coverage
            if coverage:
                high_rep_sources = [c for c in coverage if c["reputation"] >= 0.80]
                
                if len(high_rep_sources) >= 2:
                    if status == "unverified":
                        status = "supported"
                        confidence = min(0.75, sum(s["reputation"] for s in high_rep_sources[:3]) / 3)
                    
                    evidence.append({
                        "type": "mock_source_coverage",
                        "source": "SourceIndex (Mock)",
                        "source_count": len(coverage),
                        "high_reputation_sources": len(high_rep_sources),
                        "top_sources": [s["source"] for s in coverage[:3]]
                    })
        
        return {
            "claim_id": claim["id"],
            "claim_text": claim["text"],
            "status": status,
            "confidence": round(confidence, 2),
            "evidence": evidence,
            "source_count": len(evidence),
            "real_api_data": real_data is not None
        }
    
    def _calculate_overall_credibility(self, results: List[Dict]) -> Dict:
        """Calculate overall credibility based on all verifications."""
        if not results:
            return {"score": 0.0, "level": "Unknown"}
        
        total_weight = 0
        weighted_score = 0
        
        for result in results:
            weight = result["confidence"] if result["confidence"] > 0 else 0.3
            
            if result["status"] == "supported":
                weighted_score += 1.0 * weight
            elif result["status"] == "disputed":
                weighted_score += -1.0 * weight
            else:
                weighted_score += 0.3 * weight
            
            total_weight += weight
        
        if total_weight == 0:
            score = 0.5
        else:
            score = (weighted_score / total_weight + 1) / 2
        
        if score >= 0.75:
            level = "High"
        elif score >= 0.55:
            level = "Moderate"
        elif score >= 0.35:
            level = "Low"
        else:
            level = "Very Low"
        
        return {"score": round(score, 2), "level": level}
    
    def get_summary(self, verification_result: Dict) -> str:
        """Generate human-readable summary."""
        summary = verification_result["summary"]
        credibility = verification_result["overall_credibility"]
        data_sources = verification_result.get("data_sources_used", {})
        
        text = f"Verification: {summary['supported']} supported, "
        text += f"{summary['disputed']} disputed, "
        text += f"{summary['unverified']} unverified. "
        text += f"Overall credibility: {credibility['level']} ({credibility['score']}). "
        
        if data_sources.get("real_apis"):
            text += "[Using REAL APIs]"
        else:
            text += "[Using Mock Data]"
        
        return text
