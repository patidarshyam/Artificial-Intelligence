"""Cross-Check Agent - verifies claims against data sources."""

from typing import List, Dict
from data_sources.fact_check_db import FactCheckDB
from data_sources.source_index import SourceIndex
from data_sources.reputation_scores import ReputationScores


class CrossCheckAgent:
    """Verifies claims against fact-checking databases and news sources."""
    
    def __init__(self):
        self.fact_db = FactCheckDB()
        self.source_index = SourceIndex()
        self.reputation = ReputationScores()
    
    def verify_claims(self, claims: List[Dict], snippet: str) -> Dict:
        """
        Cross-check claims against available data sources.
        
        Returns:
            Dict with corroboration status for each claim
        """
        results = []
        
        for claim in claims:
            verification = self._verify_single_claim(claim)
            results.append(verification)
        
        # Calculate overall corroboration metrics
        supported = sum(1 for r in results if r["status"] == "supported")
        disputed = sum(1 for r in results if r["status"] == "disputed")
        unverified = sum(1 for r in results if r["status"] == "unverified")
        
        return {
            "corroboration": results,
            "summary": {
                "supported": supported,
                "disputed": disputed,
                "unverified": unverified,
                "total": len(results)
            },
            "overall_credibility": self._calculate_overall_credibility(results)
        }
    
    def _verify_single_claim(self, claim: Dict) -> Dict:
        """Verify a single claim against data sources."""
        claim_text = claim["text"]
        
        # Check fact-checking database
        fact_check = self.fact_db.check_claim(claim_text)
        
        # Find source coverage
        coverage = self.source_index.find_coverage(claim_text)
        
        # Determine status
        status = "unverified"
        evidence = []
        confidence = 0.0
        
        if fact_check:
            # Direct fact-check match
            if fact_check["status"] == "true":
                status = "supported"
                confidence = fact_check["confidence"]
            elif fact_check["status"] == "false":
                status = "disputed"
                confidence = fact_check["confidence"]
            
            evidence.append({
                "type": "fact_check",
                "source": "FactCheckDB",
                "matched_claim": fact_check["matched_claim"],
                "verdict": fact_check["status"],
                "confidence": fact_check["confidence"]
            })
        
        # Check source coverage
        if coverage:
            high_rep_sources = [c for c in coverage if c["reputation"] >= 0.80]
            
            if len(high_rep_sources) >= 2:
                # Multiple reputable sources = likely supported
                if status == "unverified":
                    status = "supported"
                    confidence = min(0.75, sum(s["reputation"] for s in high_rep_sources[:3]) / 3)
                
                evidence.append({
                    "type": "source_coverage",
                    "source_count": len(coverage),
                    "high_reputation_sources": len(high_rep_sources),
                    "top_sources": [s["source"] for s in coverage[:3]],
                    "avg_reputation": sum(s["reputation"] for s in coverage) / len(coverage)
                })
            elif len(coverage) == 1 and coverage[0]["reputation"] < 0.60:
                # Only low-reputation source
                evidence.append({
                    "type": "source_coverage",
                    "source_count": 1,
                    "warning": "Only low-reputation source found",
                    "top_sources": [coverage[0]["source"]]
                })
        
        return {
            "claim_id": claim["id"],
            "claim_text": claim["text"],
            "status": status,
            "confidence": round(confidence, 2),
            "evidence": evidence,
            "source_count": len(coverage)
        }
    
    def _calculate_overall_credibility(self, results: List[Dict]) -> Dict:
        """Calculate overall credibility based on all verifications."""
        if not results:
            return {
                "score": 0.0,
                "level": "Unknown"
            }
        
        # Weight by confidence
        total_weight = 0
        weighted_score = 0
        
        for result in results:
            weight = result["confidence"] if result["confidence"] > 0 else 0.3
            
            if result["status"] == "supported":
                weighted_score += 1.0 * weight
            elif result["status"] == "disputed":
                weighted_score += -1.0 * weight
            else:  # unverified
                weighted_score += 0.3 * weight
            
            total_weight += weight
        
        if total_weight == 0:
            score = 0.5
        else:
            # Normalize to 0-1 range
            score = (weighted_score / total_weight + 1) / 2
        
        # Classify credibility level
        if score >= 0.75:
            level = "High"
        elif score >= 0.55:
            level = "Moderate"
        elif score >= 0.35:
            level = "Low"
        else:
            level = "Very Low"
        
        return {
            "score": round(score, 2),
            "level": level
        }
    
    def get_summary(self, verification_result: Dict) -> str:
        """Generate human-readable summary of verification."""
        summary = verification_result["summary"]
        credibility = verification_result["overall_credibility"]
        
        text = f"Verification: {summary['supported']} supported, "
        text += f"{summary['disputed']} disputed, "
        text += f"{summary['unverified']} unverified. "
        text += f"Overall credibility: {credibility['level']} ({credibility['score']})."
        
        return text
