"""Bias Detection Agent - detects bias signals in news text."""

import re
from typing import List, Dict


class BiasDetectionAgent:
    """Detects bias indicators in news snippets."""
    
    def __init__(self):
        # Emotional/loaded language
        self.loaded_terms = [
            "shocking", "outrageous", "devastating", "incredible",
            "unbelievable", "horrifying", "amazing", "stunning",
            "slammed", "blasted", "destroyed", "obliterated"
        ]
        
        # Extreme language
        self.extreme_terms = [
            "always", "never", "everyone", "nobody", "completely",
            "absolutely", "totally", "entirely", "all", "none"
        ]
        
        # Attribution weakness
        self.weak_attribution = [
            "sources say", "reportedly", "allegedly", "rumors",
            "it is said", "some people", "many believe", "critics claim"
        ]
        
        # Opinion markers
        self.opinion_markers = [
            "clearly", "obviously", "undoubtedly", "certainly",
            "must be", "should", "ought to"
        ]
    
    def detect_bias(self, snippet: str, claims: List[Dict]) -> Dict:
        """
        Analyze text for bias indicators.
        
        Returns:
            Dict with bias score and detected signals
        """
        signals = []
        
        # Check for loaded language
        loaded = self._detect_loaded_language(snippet)
        if loaded:
            signals.extend(loaded)
        
        # Check for extreme language
        extreme = self._detect_extreme_language(snippet)
        if extreme:
            signals.extend(extreme)
        
        # Check for weak attribution
        weak_attrib = self._detect_weak_attribution(snippet)
        if weak_attrib:
            signals.extend(weak_attrib)
        
        # Check for opinion markers
        opinions = self._detect_opinion_markers(snippet)
        if opinions:
            signals.extend(opinions)
        
        # Check headline vs content mismatch (if headline present)
        headline_bias = self._check_headline_bias(snippet)
        if headline_bias:
            signals.append(headline_bias)
        
        # Check for lack of attribution
        attribution_score = self._check_attribution_quality(claims)
        if attribution_score < 0.5:
            signals.append({
                "type": "weak_attribution",
                "severity": "medium",
                "description": f"Claims lack strong attribution (score: {attribution_score:.2f})"
            })
        
        # Calculate overall bias score
        bias_score = self._calculate_bias_score(signals, len(snippet))
        
        return {
            "bias": {
                "score": bias_score,
                "level": self._classify_bias_level(bias_score),
                "signals": signals,
                "signal_count": len(signals)
            },
            "interpretation": self._generate_interpretation(bias_score, signals)
        }
    
    def _detect_loaded_language(self, text: str) -> List[Dict]:
        """Detect emotionally loaded terms."""
        signals = []
        text_lower = text.lower()
        
        for term in self.loaded_terms:
            if term in text_lower:
                signals.append({
                    "type": "loaded_language",
                    "severity": "medium",
                    "term": term,
                    "description": f"Emotionally charged term: '{term}'"
                })
        
        return signals
    
    def _detect_extreme_language(self, text: str) -> List[Dict]:
        """Detect absolute/extreme language."""
        signals = []
        text_lower = text.lower()
        
        for term in self.extreme_terms:
            # Use word boundaries to avoid partial matches
            pattern = r'\b' + re.escape(term) + r'\b'
            if re.search(pattern, text_lower):
                signals.append({
                    "type": "extreme_language",
                    "severity": "low",
                    "term": term,
                    "description": f"Absolute/extreme term: '{term}'"
                })
        
        return signals
    
    def _detect_weak_attribution(self, text: str) -> List[Dict]:
        """Detect weak or vague attribution."""
        signals = []
        text_lower = text.lower()
        
        for phrase in self.weak_attribution:
            if phrase in text_lower:
                signals.append({
                    "type": "weak_attribution",
                    "severity": "high",
                    "phrase": phrase,
                    "description": f"Vague source attribution: '{phrase}'"
                })
        
        return signals
    
    def _detect_opinion_markers(self, text: str) -> List[Dict]:
        """Detect opinion masquerading as fact."""
        signals = []
        text_lower = text.lower()
        
        for marker in self.opinion_markers:
            if marker in text_lower:
                signals.append({
                    "type": "opinion_as_fact",
                    "severity": "medium",
                    "marker": marker,
                    "description": f"Opinion marker: '{marker}'"
                })
        
        return signals
    
    def _check_headline_bias(self, text: str) -> Dict:
        """Check for sensationalized headlines (simplified)."""
        # Assume first sentence might be a headline
        sentences = text.split('.')
        if len(sentences) < 2:
            return None
        
        first = sentences[0].strip()
        
        # Check if first sentence has multiple bias indicators
        bias_count = sum(1 for term in self.loaded_terms if term in first.lower())
        
        if bias_count >= 2 and len(first) < 100:
            return {
                "type": "headline_bias",
                "severity": "high",
                "description": "Potentially sensationalized headline/opening"
            }
        
        return None
    
    def _check_attribution_quality(self, claims: List[Dict]) -> float:
        """Check if claims have proper attribution."""
        if not claims:
            return 0.5
        
        attributed = 0
        for claim in claims:
            # Check if claim contains attribution markers
            text = claim["text"].lower()
            if any(marker in text for marker in ["according to", "said", "reported", "announced"]):
                attributed += 1
            # Named entities suggest attribution
            if claim.get("named_entities"):
                attributed += 0.5
        
        return min(1.0, attributed / len(claims))
    
    def _calculate_bias_score(self, signals: List[Dict], text_length: int) -> float:
        """Calculate overall bias score (0-1, higher = more biased)."""
        if not signals:
            return 0.0
        
        # Weight by severity
        severity_weights = {"low": 0.3, "medium": 0.6, "high": 1.0}
        
        total_weight = sum(severity_weights.get(s.get("severity", "medium"), 0.6) for s in signals)
        
        # Normalize by text length (more signals in short text = higher bias)
        density_factor = (len(signals) / max(text_length / 100, 1))
        
        score = min(1.0, (total_weight / 10) + (density_factor * 0.1))
        
        return round(score, 2)
    
    def _classify_bias_level(self, score: float) -> str:
        """Classify bias level."""
        if score < 0.2:
            return "Minimal"
        elif score < 0.4:
            return "Low"
        elif score < 0.6:
            return "Moderate"
        elif score < 0.8:
            return "High"
        else:
            return "Very High"
    
    def _generate_interpretation(self, score: float, signals: List[Dict]) -> str:
        """Generate human-readable interpretation."""
        if score < 0.2:
            return "Text shows minimal bias indicators. Language is largely neutral."
        
        signal_types = {}
        for signal in signals:
            sig_type = signal["type"]
            signal_types[sig_type] = signal_types.get(sig_type, 0) + 1
        
        interp = f"Detected {len(signals)} bias signal(s). "
        
        main_issues = sorted(signal_types.items(), key=lambda x: x[1], reverse=True)[:2]
        if main_issues:
            issue_names = [name.replace("_", " ") for name, _ in main_issues]
            interp += f"Primary concerns: {', '.join(issue_names)}."
        
        return interp
    
    def get_summary(self, bias_result: Dict) -> str:
        """Generate human-readable summary."""
        bias = bias_result["bias"]
        return f"Bias: {bias['level']} (score: {bias['score']}), {bias['signal_count']} signal(s) detected."
