"""Demo script - demonstrates the news verification system with examples."""

from orchestrator import NewsVerificationOrchestrator


def main():
    """Run demo with various news snippet examples."""
    
    print("\n" + "="*70)
    print(" MULTI-AGENT NEWS VERIFICATION ASSISTANT - DEMO")
    print("="*70)
    
    orchestrator = NewsVerificationOrchestrator()
    
    # Example 1: Verified scientific news
    print("\n\n" + "#"*70)
    print("EXAMPLE 1: Verified Scientific News")
    print("#"*70)
    
    snippet1 = (
        "According to NASA and NOAA, global temperatures have risen significantly "
        "over the past century. The data shows a clear warming trend that scientists "
        "have confirmed through multiple independent studies. Research published in "
        "leading journals indicates this trend is consistent with climate change models."
    )
    
    result1 = orchestrator.verify_and_format(snippet1, verbose=True)
    print("\n" + result1)
    
    # Example 2: Sensational headline with weak attribution
    print("\n\n" + "#"*70)
    print("EXAMPLE 2: Sensational Headline with Weak Attribution")
    print("#"*70)
    
    snippet2 = (
        "SHOCKING revelation that will completely destroy everything! Sources say "
        "that allegedly this unbelievable news changes absolutely everything we know. "
        "Many believe this devastating announcement will obliterate all opposition!"
    )
    
    result2 = orchestrator.verify_and_format(snippet2, verbose=True)
    print("\n" + result2)
    
    # Example 3: Mixed content (some verifiable, some opinion)
    print("\n\n" + "#"*70)
    print("EXAMPLE 3: Mixed Content (Fact + Opinion)")
    print("#"*70)
    
    snippet3 = (
        "Scientists at major research institutions have confirmed rising global "
        "temperatures. Some experts believe this could lead to unexpected consequences "
        "in the future. The consensus among climatologists suggests immediate action "
        "is necessary, though opinions vary on the best approach."
    )
    
    result3 = orchestrator.verify_and_format(snippet3, verbose=True)
    print("\n" + result3)
    
    # Example 4: Low credibility claim
    print("\n\n" + "#"*70)
    print("EXAMPLE 4: Dubious Claim")
    print("#"*70)
    
    snippet4 = (
        "Rumors suggest that the moon landing was faked. Anonymous sources claim "
        "there is evidence that allegedly proves the entire event never happened. "
        "This shocking conspiracy has been reportedly discussed by various groups."
    )
    
    result4 = orchestrator.verify_and_format(snippet4, verbose=True)
    print("\n" + result4)
    
    # Example 5: Legitimate news with multiple sources
    print("\n\n" + "#"*70)
    print("EXAMPLE 5: Well-Sourced News Report")
    print("#"*70)
    
    snippet5 = (
        "The Reuters news agency reported that major economic policy changes were "
        "announced yesterday. The Associated Press and BBC also covered the story, "
        "citing official government statements. According to the announcement, "
        "the changes will take effect next quarter."
    )
    
    result5 = orchestrator.verify_and_format(snippet5, verbose=True)
    print("\n" + result5)
    
    print("\n\n" + "="*70)
    print(" DEMO COMPLETE")
    print("="*70)
    print("\nKey Takeaways:")
    print("  • Claims are extracted and classified")
    print("  • Evidence is cross-checked against mock databases")
    print("  • Bias signals are detected in language")
    print("  • Final verdict considers all dimensions")
    print("  • Limitations are transparently reported")
    print("\nNote: This system uses mock data sources for demonstration.")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
