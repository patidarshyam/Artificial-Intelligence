# 🔧 Setting Up Real Fact-Checking APIs

This guide shows you how to configure REAL, FREE fact-checking APIs to replace mock data.

## 📋 Prerequisites

All APIs mentioned are **FREE** with generous limits for personal use.

---

## 1️⃣ Google Fact Check Tools API (FREE)

Google's official fact-checking API aggregates fact-checks from multiple sources.

### Get Your API Key:

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Click **"Enable APIs and Services"**
4. Search for **"Fact Check Tools API"**
5. Click **Enable**
6. Go to **Credentials** → **Create Credentials** → **API Key**
7. Copy your API key

### Configure:

Open `config.py` and add your key:
```python
GOOGLE_FACTCHECK_API_KEY = "YOUR_KEY_HERE"
```

### What it provides:
- Fact-checks from Snopes, PolitiFact, FactCheck.org, etc.
- Ratings: True, False, Misleading, etc.
- Publisher information and URLs

---

## 2️⃣ NewsAPI.org (FREE - 100 requests/day)

Search news articles from 80,000+ sources worldwide.

### Get Your API Key:

1. Go to [NewsAPI.org](https://newsapi.org/register)
2. Sign up (free account)
3. Verify your email
4. Copy your API key from dashboard

### Configure:

Open `config.py` and add your key:
```python
NEWS_API_KEY = "YOUR_KEY_HERE"
```

### What it provides:
- News coverage from Reuters, AP, BBC, CNN, etc.
- Article metadata and sources
- Source reputation verification

---

## 3️⃣ Wikidata API (FREE - No Key Needed!)

Structured data from Wikipedia - always enabled.

### What it provides:
- Entity verification
- Factual data about people, places, events
- No configuration required - works automatically!

---

## 🚀 Quick Setup

### Step 1: Edit config.py

```bash
# Open config.py in your editor
code config.py
```

Replace `None` with your API keys:

```python
GOOGLE_FACTCHECK_API_KEY = "AIzaSyC..." # Your Google key
NEWS_API_KEY = "a1b2c3d4..." # Your NewsAPI key
```

### Step 2: Install requests library

```bash
pip install requests
```

### Step 3: Restart the app

```bash
streamlit run app.py
```

You'll see: **"✅ Real APIs Enabled!"** at the top of the page.

---

## 🧪 Testing Real APIs

Try these claims that should return real fact-check results:

### Climate Change:
```
Global temperatures have risen by 1 degree Celsius since pre-industrial times.
```

### COVID-19:
```
COVID-19 vaccines were developed and tested following standard safety protocols.
```

### Current Events:
```
NASA confirmed water exists on Mars in the form of ice.
```

---

## 💡 API Limits & Best Practices

| API | Free Limit | Notes |
|-----|-----------|-------|
| Google Fact Check | Generous (no specific limit published) | Rate limited |
| NewsAPI | 100 requests/day | Upgrade for more |
| Wikidata | Unlimited | Open source! |

### Tips:
- Use for testing and demos
- Cache results to reduce API calls
- Combine with mock data for fallback
- Monitor usage in API dashboards

---

## ❓ Troubleshooting

### "No results found" message:
- Claim may not have been fact-checked yet
- Try more specific queries
- Check API key validity

### API key errors:
- Verify key is correct (no extra spaces)
- Ensure API is enabled in Google Cloud
- Check API quota/limits

### Still using mock data:
- Restart Streamlit after adding keys
- Check config.py is in the right directory
- Look for console errors

---

## 🔐 Security Note

**Never commit API keys to Git!**

Add to `.gitignore`:
```
config.py
.env
```

Or use environment variables:
```bash
export GOOGLE_FACTCHECK_API_KEY="your-key"
export NEWS_API_KEY="your-key"
```

---

## 📚 Additional Resources

- [Google Fact Check API Docs](https://developers.google.com/fact-check/tools/api)
- [NewsAPI Documentation](https://newsapi.org/docs)
- [Wikidata API Help](https://www.wikidata.org/wiki/Wikidata:Data_access)

---

## ✅ Summary

Once configured, your system will:
1. ✅ Query real fact-checking databases
2. ✅ Search actual news articles
3. ✅ Verify against Wikidata
4. ✅ Fall back to mock data if needed
5. ✅ Show "Real APIs Enabled" badge in UI

**The system works NOW with mock data, but add API keys for REAL fact-checking!** 🚀
