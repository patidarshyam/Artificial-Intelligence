"""Unit and scenario tests for the news verification system."""

import unittest
from agents.claim_extraction_agent import ClaimExtractionAgent
from agents.bias_detection_agent import BiasDetectionAgent
from orchestrator import NewsVerificationOrchestrator


class TestClaimExtraction(unittest.TestCase):
    """Unit tests for Claim Extraction Agent."""
    
    def setUp(self):
        self.agent = ClaimExtractionAgent()
    
    def test_extract_factual_claim(self):
        """Test extraction of factual claims."""
        snippet = "According to NASA, global temperatures have risen by 1.5 degrees since 1900."
        result = self.agent.extract_claims(snippet)
        
        self.assertGreater(result["total_claims"], 0)
        self.assertEqual(result["claims"][0]["type"], "factual")
        self.assertTrue(result["claims"][0]["contains_numbers"])
    
    def test_extract_statistical_claim(self):
        """Test extraction of statistical claims."""
        snippet = "Recent studies show that 75% of consumers prefer online shopping."
        result = self.agent.extract_claims(snippet)
        
        self.assertGreater(result["total_claims"], 0)
        self.assertEqual(result["claims"][0]["type"], "statistical")
    
    def test_no_claims_in_opinion(self):
        """Test that pure opinions are not extracted as claims."""
        snippet = "I think this might be a good idea, but I'm not sure."
        result = self.agent.extract_claims(snippet)
        
        # Should extract minimal or no claims
        self.assertLessEqual(result["total_claims"], 1)
    
    def test_confidence_calculation(self):
        """Test that confidence scores are reasonable."""
        snippet = "Scientists at MIT announced that their research shows significant results."
        result = self.agent.extract_claims(snippet)
        
        self.assertGreater(result["total_claims"], 0)
        # Should have high confidence due to source and factual language
        self.assertGreater(result["claims"][0]["confidence"], 0.5)


class TestBiasDetection(unittest.TestCase):
    """Unit tests for Bias Detection Agent."""
    
    def setUp(self):
        self.agent = BiasDetectionAgent()
    
    def test_loaded_language_detection(self):
        """Test detection of loaded/emotional language."""
        snippet = "This shocking revelation will completely devastate the opposition!"
        result = self.agent.detect_bias(snippet, [])
        
        self.assertGreater(result["bias"]["score"], 0.2)
        self.assertTrue(
            any(s["type"] == "loaded_language" for s in result["bias"]["signals"])
        )
    
    def test_neutral_language(self):
        """Test that neutral language gets low bias score."""
        snippet = "The committee met yesterday to discuss the proposal. A decision will be made next week."
        result = self.agent.detect_bias(snippet, [])
        
        self.assertLess(result["bias"]["score"], 0.3)
        self.assertEqual(result["bias"]["level"], "Minimal")
    
    def test_weak_attribution(self):
        """Test detection of weak attribution."""
        snippet = "Sources say that allegedly something might have happened."
        result = self.agent.detect_bias(snippet, [])
        
        signals = result["bias"]["signals"]
        self.assertTrue(
            any(s["type"] == "weak_attribution" for s in signals)
        )


class TestScenarioVerifiedNews(unittest.TestCase):
    """Scenario test: verified news article."""
    
    def setUp(self):
        self.orchestrator = NewsVerificationOrchestrator()
    
    def test_verified_news_scenario(self):
        """Test with a verified, factual news snippet."""
        snippet = (
            "According to NOAA, global temperatures have risen over the past century. "
            "The data shows a clear warming trend. Scientists at NASA confirmed these findings. "
            "Research indicates that this trend is consistent with climate change models."
        )
        
        verdict = self.orchestrator.verify_news(snippet, verbose=False)
        
        # Should extract multiple claims
        self.assertGreater(len(verdict["claims"]), 0)
        
        # Should have at least one supported claim
        supported = sum(
            1 for c in verdict["corroboration"] if c["status"] == "supported"
        )
        self.assertGreater(supported, 0)
        
        # Should have low-moderate bias
        self.assertLess(verdict["bias"]["score"], 0.5)
        
        # Should be reliable or likely reliable
        self.assertIn(
            verdict["verdict"]["label"],
            ["Reliable", "Likely Reliable"]
        )


class TestScenarioSensationalHeadline(unittest.TestCase):
    """Scenario test: sensational headline."""
    
    def setUp(self):
        self.orchestrator = NewsVerificationOrchestrator()
    
    def test_sensational_headline_scenario(self):
        """Test with a sensational, biased snippet."""
        snippet = (
            "SHOCKING news that will completely destroy everything you thought you knew! "
            "Experts allegedly claim that this unbelievable revelation changes absolutely everything. "
            "Sources say the truth is finally out!"
        )
        
        verdict = self.orchestrator.verify_news(snippet, verbose=False)
        
        # Should detect high bias
        self.assertGreater(verdict["bias"]["score"], 0.4)
        
        # Should detect multiple bias signals
        self.assertGreater(len(verdict["bias"]["signals"]), 2)
        
        # Verdict should reflect uncertainty or unreliability
        self.assertIn(
            verdict["verdict"]["label"],
            ["Uncertain", "Likely Unreliable"]
        )
        
        # Should have limitations noted
        self.assertGreater(len(verdict["limitations"]), 0)


class TestScenarioMixedContent(unittest.TestCase):
    """Scenario test: mixed verified and unverified content."""
    
    def setUp(self):
        self.orchestrator = NewsVerificationOrchestrator()
    
    def test_mixed_content_scenario(self):
        """Test with mix of verifiable and unverifiable claims."""
        snippet = (
            "Scientists confirmed that global temperatures are rising. "
            "Some experts believe this could lead to unexpected consequences. "
            "Research shows significant data supporting climate science."
        )
        
        verdict = self.orchestrator.verify_news(snippet, verbose=False)
        
        # Should extract multiple claims
        self.assertGreater(len(verdict["claims"]), 1)
        
        # Should have mixed verification status
        statuses = set(c["status"] for c in verdict["corroboration"])
        # Either should have variety, or at least one supported
        self.assertTrue(
            len(statuses) > 1 or "supported" in statuses
        )
        
        # Confidence should be moderate (not too high, not too low)
        self.assertGreater(verdict["verdict"]["confidence"], 0.3)
        self.assertLess(verdict["verdict"]["confidence"], 0.9)


def run_tests():
    """Run all tests."""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestClaimExtraction))
    suite.addTests(loader.loadTestsFromTestCase(TestBiasDetection))
    suite.addTests(loader.loadTestsFromTestCase(TestScenarioVerifiedNews))
    suite.addTests(loader.loadTestsFromTestCase(TestScenarioSensationalHeadline))
    suite.addTests(loader.loadTestsFromTestCase(TestScenarioMixedContent))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result


if __name__ == "__main__":
    print("Running News Verification System Tests...\n")
    result = run_tests()
    
    print(f"\n{'='*60}")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success: {result.wasSuccessful()}")
    print(f"{'='*60}")
