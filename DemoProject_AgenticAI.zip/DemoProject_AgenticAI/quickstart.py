"""Quick start example - simple usage of the news verification system."""

from orchestrator import NewsVerificationOrchestrator


# Create orchestrator
orchestrator = NewsVerificationOrchestrator()

# Example news snippet
news_snippet = """
Scientists at MIT announced groundbreaking research showing that renewable energy 
could meet 80% of global demand by 2040. The study, published in Nature, analyzed 
data from multiple countries. According to the researchers, this transition is 
both technologically feasible and economically viable.
"""

# Verify the news (verbose=True shows the process)
print("Verifying news snippet...\n")
result = orchestrator.verify_and_format(news_snippet, verbose=True)

# The result includes JSON and human-readable summary
print("\nFull Output:")
print(result)

# Or just get the verdict dictionary for programmatic use
verdict_dict = orchestrator.verify_news(news_snippet, verbose=False)
print(f"\n\nQuick Summary:")
print(f"Verdict: {verdict_dict['verdict']['label']}")
print(f"Confidence: {verdict_dict['verdict']['confidence']}")
print(f"Reliability Score: {verdict_dict['verdict']['reliability_score']}")
print(f"Claims Found: {len(verdict_dict['claims'])}")
print(f"Bias Level: {verdict_dict['bias']['level']}")
