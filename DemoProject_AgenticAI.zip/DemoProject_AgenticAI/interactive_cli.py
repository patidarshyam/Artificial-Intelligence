"""Interactive CLI - Type or paste news snippets for verification."""

from orchestrator import NewsVerificationOrchestrator
import sys


def print_banner():
    """Print welcome banner."""
    print("\n" + "="*70)
    print(" 📰 MULTI-AGENT NEWS VERIFICATION ASSISTANT")
    print("="*70)
    print("\nPaste or type news snippets to verify their reliability.")
    print("Type 'quit' or 'exit' to close the application.\n")


def print_menu():
    """Print options menu."""
    print("\n" + "-"*70)
    print("Options:")
    print("  1. Enter/paste a news snippet")
    print("  2. Try example: Verified news")
    print("  3. Try example: Fake news / conspiracy")
    print("  4. Try example: Sensational headline")
    print("  5. Quit")
    print("-"*70)


def get_example_news(choice):
    """Return example news snippets."""
    examples = {
        "2": """According to NASA and NOAA, global temperatures have risen significantly 
over the past century. The data shows a clear warming trend that scientists 
have confirmed through multiple independent studies. Research published in 
leading journals indicates this trend is consistent with climate change models.""",
        
        "3": """SHOCKING: Rumors suggest that the moon landing was faked! Anonymous sources 
claim there is evidence that allegedly proves the entire event never happened. 
This unbelievable conspiracy has been reportedly discussed by various groups. 
Sources say the truth is finally out!""",
        
        "4": """DEVASTATING news that will COMPLETELY destroy everything you thought you knew! 
This shocking revelation allegedly changes absolutely everything. Experts claim 
this unbelievable announcement will obliterate all opposition!"""
    }
    return examples.get(choice, None)


def main():
    """Run interactive CLI."""
    print_banner()
    
    orchestrator = NewsVerificationOrchestrator()
    
    while True:
        print_menu()
        choice = input("\nEnter your choice (1-5): ").strip()
        
        if choice in ['5', 'quit', 'exit', 'q']:
            print("\n👋 Thank you for using the News Verification Assistant!\n")
            sys.exit(0)
        
        snippet = None
        
        if choice == '1':
            print("\n" + "="*70)
            print("Enter or paste your news snippet below.")
            print("(Press Enter twice when done, or type END on a new line)")
            print("="*70 + "\n")
            
            lines = []
            empty_count = 0
            
            while True:
                try:
                    line = input()
                    if line.strip().upper() == 'END':
                        break
                    if not line.strip():
                        empty_count += 1
                        if empty_count >= 2:
                            break
                    else:
                        empty_count = 0
                    lines.append(line)
                except EOFError:
                    break
            
            snippet = '\n'.join(lines).strip()
            
            if not snippet:
                print("\n❌ No text entered. Please try again.")
                continue
        
        elif choice in ['2', '3', '4']:
            snippet = get_example_news(choice)
            example_names = {
                '2': 'Verified Scientific News',
                '3': 'Fake News / Conspiracy Theory',
                '4': 'Sensational Headline'
            }
            print(f"\n📋 Loading example: {example_names[choice]}")
            print("\n" + "-"*70)
            print(f"Snippet:\n{snippet[:200]}...")
            print("-"*70)
        
        else:
            print("\n❌ Invalid choice. Please select 1-5.")
            continue
        
        if snippet:
            print("\n🔍 Analyzing news snippet...\n")
            print("="*70)
            
            # Verify the news
            result = orchestrator.verify_and_format(snippet, verbose=False)
            print(result)
            
            input("\n\nPress Enter to continue...")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!\n")
        sys.exit(0)
