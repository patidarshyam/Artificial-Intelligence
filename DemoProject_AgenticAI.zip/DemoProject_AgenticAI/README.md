# Multi-Agent News Verification Assistant

A Python-based news verification system that uses multiple specialized agents to assess the reliability of news snippets.

## 🎯 Quick Start

**Your UI is ready!** Running at: http://localhost:8501

- ✅ **Works NOW** with mock data + pattern detection
- 🚀 **Add FREE API keys** for real fact-checking (optional)
- 📖 See [QUICK_START.md](QUICK_START.md) for 5-minute setup
- 🔧 See [API_SETUP_GUIDE.md](API_SETUP_GUIDE.md) for detailed instructions

## Overview

This system coordinates four specialized agents to evaluate news reliability:

1. **Claim Extraction Agent** - Extracts verifiable claims from text
2. **Cross-Check Agent** - Verifies claims against mock fact-checking databases
3. **Bias Detection Agent** - Analyzes language for bias indicators
4. **Verdict Agent** - Synthesizes findings into a final reliability verdict

## Features

- 🌐 **Real API Integration** - Google Fact Check, NewsAPI, Wikidata (all FREE!)
- 🤖 **Smart Fallback** - Works with mock data if APIs not configured
- 📊 **Pattern Detection** - Bias analysis works regardless of APIs
- 🎨 **Interactive Web UI** - Visual, easy-to-use interface
- Structured claim extraction with confidence scoring
- Cross-referencing against fact-checking databases
- Bias detection analyzing emotional language, weak attribution, and opinion markers
- Final verdict with reliability score, confidence level, and transparent limitations
- JSON output with human-readable summaries

## Project Structure

```
DemoProjectUsingAgenticAI/
├── agents/
│   ├── __init__.py
│   ├── claim_extraction_agent.py
│   ├── cross_check_agent.py
│   ├── bias_detection_agent.py
│   └── verdict_agent.py
├── data_sources/
│   ├── __init__.py
│   ├── fact_check_db.py
│   ├── source_index.py
│   └── reputation_scores.py
├── orchestrator.py
├── demo.py
├── tests.py
└── README.md
```

## Usage

### 🌐 Web UI (Recommended)
Interactive web interface with real-time verification:
```bash
# Install Streamlit first
pip install streamlit

# Run the web app
streamlit run app.py
```
Then open your browser to `http://localhost:8501`

**Features:**
- Paste any news snippet for instant verification
- Pre-loaded examples (verified news, fake news, sensational headlines)
- Visual metrics and color-coded verdicts
- Detailed tabs for claims, verification, and bias analysis

### 💻 Interactive CLI
Terminal-based interactive interface:
```bash
python interactive_cli.py
```
- Type or paste news snippets
- Try built-in examples
- Get formatted results in the terminal

### 🎬 Run Demo Examples
See 5 pre-configured examples:
```bash
python demo.py
```

### ✅ Run Tests
```bash
python tests.py
```

### 🔧 Use in Code
```python
from orchestrator import NewsVerificationOrchestrator

orchestrator = NewsVerificationOrchestrator()

snippet = "According to NASA, global temperatures have risen..."
result = orchestrator.verify_and_format(snippet, verbose=True)
print(result)
```

## Output Format

The system produces:
- **JSON** with structured data (claims, corroboration, bias signals, verdict)
- **Human-readable summary** with verdict label, confidence, key reasons, and limitations

## Verdict Labels

- **Reliable** - High confidence in accuracy
- **Likely Reliable** - Good evidence, minor concerns
- **Uncertain** - Insufficient evidence or high bias
- **Likely Unreliable** - Contradicted or low credibility

## Limitations

- Uses mock data sources (not real fact-checking APIs)
- Simple keyword matching for claim verification
- No deep NLP or machine learning models
- Cannot access paywalled sources or very recent news

## Testing

Includes:
- **Unit tests** for claim extraction and bias detection
- **Scenario tests** for verified news, sensational headlines, and mixed content

## Design Principles

- Objectivity: No political persuasion or moralizing
- Transparency: Limitations clearly stated
- Separation of concerns: Bias ≠ falsity
- Multi-source corroboration preferred
- Confidence scoring with uncertainty acknowledgment
streamlit - Web UI framework
- requests - HTTP library for API calls
- Standard library modules

## Real API Setup (Optional)

To use **REAL fact-checking** instead of mock data:

1. **Get FREE API keys** (takes 3 minutes):
   - [Google Fact Check API](https://console.cloud.google.com/) - Free, aggregates fact-checkers
   - [NewsAPI.org](https://newsapi.org/register) - Free tier: 100 req/day
   - Wikidata - No key needed, always free!

2. **Edit config.py**:
   ```python
   GOOGLE_FACTCHECK_API_KEY = "your-key-here"
   NEWS_API_KEY = "your-key-here"
   ```

3. **Reload the app** - You'll see "✅ Real APIs Enabled!"

📖 **Detailed setup:** See [API_SETUP_GUIDE.md](API_SETUP_GUIDE.md)

### What Changes With Real APIs:

| Feature | Mock Data | With APIs |
|---------|-----------|-----------|
| Bias Detection | ✅ Works | ✅ Works |
| Pattern Analysis | ✅ Works | ✅ Works |
| Fact Verification | Mock results | ✅ **Real fact-checks!** |
| News Coverage | Simulated | ✅ **Live articles!** |
| Sources | Fictional | ✅ **Snopes, PolitiFact, etc.** |
## Dependencies

- Python 3.7+
- Standard library only (no external packages required)

## License

This is a demonstration project created for educational purposes.
