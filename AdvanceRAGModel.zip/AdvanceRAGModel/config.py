"""
Configuration management for the Advanced RAG Handmade Paintings Store
"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Supabase
    supabase_url: str
    supabase_key: str
    
    # AI Gateway Configuration
    ai_gateway_client_registration: str
    ai_gateway_client_id: str
    ai_gateway_client_secret: str
    galileo_console_url: str
    okta_sso_token_endpoint: str
    ai_gateway_base_url: str
    ai_gateway_enabled: bool = True
    
    # Application
    app_host: str = "localhost"
    app_port: int = 8000
    debug: bool = True
    
    # Vector Search
    embedding_model: str = "text-embedding-3-small"
    llm_model: str = "gpt-4-turbo-preview"
    vector_dimensions: int = 1536
    similarity_threshold: float = 0.7
    
    # Database Tables
    paintings_table: str = "paintings"
    embeddings_table: str = "painting_embeddings"
    
    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance"""
    return Settings()
