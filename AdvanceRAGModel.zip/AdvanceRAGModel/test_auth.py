"""
Test script to verify AI Gateway authentication
"""
import httpx
from config import get_settings

def test_ai_gateway_auth():
    """Test AI Gateway OAuth authentication"""
    settings = get_settings()
    
    print("=" * 60)
    print("AI GATEWAY AUTHENTICATION TEST")
    print("=" * 60)
    print(f"\nClient ID: {settings.ai_gateway_client_id}")
    print(f"Gateway URL: {settings.ai_gateway_base_url}")
    print(f"Token Endpoint: {settings.okta_sso_token_endpoint}")
    
    try:
        print("\n[1/2] Requesting OAuth token...")
        
        token_data = {
            'grant_type': 'client_credentials',
            'client_id': settings.ai_gateway_client_id,
            'client_secret': settings.ai_gateway_client_secret
        }
        
        with httpx.Client() as client:
            response = client.post(
                settings.okta_sso_token_endpoint,
                data=token_data,
                headers={'Content-Type': 'application/x-www-form-urlencoded'}
            )
            
            if response.status_code == 200:
                token_response = response.json()
                access_token = token_response.get('access_token')
                expires_in = token_response.get('expires_in', 0)
                
                print(f"✓ Token obtained successfully!")
                print(f"  - Token length: {len(access_token) if access_token else 0} characters")
                print(f"  - Expires in: {expires_in} seconds ({expires_in/60:.1f} minutes)")
                print(f"  - Token prefix: {access_token[:20]}..." if access_token else "")
                
                print("\n[2/2] AI Gateway is ready!")
                print("✓ Authentication configured correctly")
                return True
            else:
                print(f"✗ Failed to obtain token")
                print(f"  Status code: {response.status_code}")
                print(f"  Response: {response.text}")
                return False
                
    except Exception as e:
        print(f"✗ Error during authentication: {e}")
        return False

if __name__ == "__main__":
    success = test_ai_gateway_auth()
    print("\n" + "=" * 60)
    if success:
        print("STATUS: ✓ AI Gateway authentication working!")
        print("\nYou can now proceed to:")
        print("1. Setup Supabase database tables")
        print("2. Run: python seed_data.py")
        print("3. Run: python main.py")
    else:
        print("STATUS: ✗ Authentication failed")
        print("\nPlease check your .env file credentials")
    print("=" * 60)
