// API Base URL
const API_URL = 'http://localhost:8000/api';

// State
let currentPaintingId = null;
let allPaintings = [];

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadPaintings();
    loadFilters();
    setupEventListeners();
});

// Setup Event Listeners
function setupEventListeners() {
    // Hero search
    document.getElementById('hero-search-btn').addEventListener('click', () => {
        const query = document.getElementById('hero-search-input').value;
        if (query.trim()) {
            performConversationalSearch(query);
            // Scroll to search section
            document.getElementById('search').scrollIntoView({ behavior: 'smooth' });
        }
    });
    
    document.getElementById('hero-search-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            document.getElementById('hero-search-btn').click();
        }
    });
    
    // Conversational search
    document.getElementById('conversational-search-btn').addEventListener('click', () => {
        const query = document.getElementById('conversational-input').value;
        if (query.trim()) {
            performConversationalSearch(query);
        }
    });
    
    document.getElementById('conversational-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            document.getElementById('conversational-search-btn').click();
        }
    });
    
    // Filters
    document.getElementById('apply-filters-btn').addEventListener('click', applyFilters);
    document.getElementById('clear-filters-btn').addEventListener('click', clearFilters);
    
    // Modal
    document.querySelector('.close-modal').addEventListener('click', closeModal);
    document.getElementById('painting-modal').addEventListener('click', (e) => {
        if (e.target.id === 'painting-modal') {
            closeModal();
        }
    });
    
    // Recommendations
    document.getElementById('get-recommendations-btn').addEventListener('click', () => {
        if (currentPaintingId) {
            getRecommendations(currentPaintingId);
        }
    });
    
    // Smooth scroll for navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
                
                // Update active nav link
                document.querySelectorAll('.nav-links a').forEach(link => {
                    link.classList.remove('active');
                });
                this.classList.add('active');
            }
        });
    });
}

// Load Statistics
async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/stats`);
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('total-paintings').textContent = data.stats.total_paintings;
            document.getElementById('total-artists').textContent = data.stats.total_artists;
            document.getElementById('total-styles').textContent = data.stats.total_styles;
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load Paintings
async function loadPaintings(filters = {}) {
    showLoading();
    hideNoResults();
    
    try {
        let url = `${API_URL}/paintings?limit=50`;
        
        if (filters.style) url += `&style=${encodeURIComponent(filters.style)}`;
        if (filters.artist) url += `&artist=${encodeURIComponent(filters.artist)}`;
        if (filters.min_price) url += `&min_price=${filters.min_price}`;
        if (filters.max_price) url += `&max_price=${filters.max_price}`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            allPaintings = data.paintings;
            displayPaintings(data.paintings);
        } else {
            showNoResults();
        }
    } catch (error) {
        console.error('Error loading paintings:', error);
        showNoResults();
    } finally {
        hideLoading();
    }
}

// Display Paintings
function displayPaintings(paintings) {
    const grid = document.getElementById('paintings-grid');
    grid.innerHTML = '';
    
    if (paintings.length === 0) {
        showNoResults();
        return;
    }
    
    paintings.forEach(painting => {
        const card = createPaintingCard(painting);
        grid.appendChild(card);
    });
}

// Create Painting Card
function createPaintingCard(painting) {
    const card = document.createElement('div');
    card.className = 'painting-card';
    card.onclick = () => openModal(painting);
    
    card.innerHTML = `
        <div class="painting-image">
            <span class="image-icon">🖼️</span>
        </div>
        <div class="painting-info">
            <h3 class="painting-title">${painting.title}</h3>
            <p class="painting-artist">by ${painting.artist}</p>
            <div class="painting-meta">
                <span class="tag">${painting.style}</span>
                <span class="price">$${painting.price}</span>
            </div>
        </div>
    `;
    
    return card;
}

// Conversational Search
async function performConversationalSearch(query) {
    const resultsDiv = document.getElementById('ai-results');
    const responseDiv = document.getElementById('ai-response');
    const answerP = document.getElementById('ai-answer');
    
    // Show loading state
    responseDiv.classList.remove('hidden');
    answerP.textContent = 'Thinking...';
    resultsDiv.innerHTML = '<div class="loading"><div class="spinner"></div><p>AI is searching...</p></div>';
    
    try {
        const response = await fetch(`${API_URL}/search/conversational`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query, limit: 6 })
        });
        
        const data = await response.json();
        
        if (data.success) {
            answerP.textContent = data.answer;
            
            resultsDiv.innerHTML = '';
            if (data.paintings && data.paintings.length > 0) {
                data.paintings.forEach(painting => {
                    const card = createPaintingCard(painting);
                    resultsDiv.appendChild(card);
                });
            } else {
                resultsDiv.innerHTML = '<p class="no-results">No paintings found matching your query.</p>';
            }
        } else {
            answerP.textContent = 'Sorry, I encountered an error. Please try again.';
        }
    } catch (error) {
        console.error('Error in conversational search:', error);
        answerP.textContent = 'Sorry, I encountered an error. Please try again.';
    }
}

// Load Filter Options
async function loadFilters() {
    try {
        // Load styles
        const stylesResponse = await fetch(`${API_URL}/styles`);
        const stylesData = await stylesResponse.json();
        
        if (stylesData.success) {
            const styleSelect = document.getElementById('style-filter');
            stylesData.styles.forEach(style => {
                const option = document.createElement('option');
                option.value = style;
                option.textContent = style;
                styleSelect.appendChild(option);
            });
        }
        
        // Load artists
        const artistsResponse = await fetch(`${API_URL}/artists`);
        const artistsData = await artistsResponse.json();
        
        if (artistsData.success) {
            const artistSelect = document.getElementById('artist-filter');
            artistsData.artists.forEach(artist => {
                const option = document.createElement('option');
                option.value = artist;
                option.textContent = artist;
                artistSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading filters:', error);
    }
}

// Apply Filters
function applyFilters() {
    const filters = {
        style: document.getElementById('style-filter').value,
        artist: document.getElementById('artist-filter').value,
        min_price: document.getElementById('min-price').value,
        max_price: document.getElementById('max-price').value
    };
    
    // Remove empty filters
    Object.keys(filters).forEach(key => {
        if (!filters[key]) delete filters[key];
    });
    
    loadPaintings(filters);
    
    // Scroll to gallery
    document.getElementById('gallery').scrollIntoView({ behavior: 'smooth' });
}

// Clear Filters
function clearFilters() {
    document.getElementById('style-filter').value = '';
    document.getElementById('artist-filter').value = '';
    document.getElementById('min-price').value = '';
    document.getElementById('max-price').value = '';
    
    loadPaintings();
}

// Open Modal
function openModal(painting) {
    currentPaintingId = painting.id;
    
    document.getElementById('modal-title').textContent = painting.title;
    document.getElementById('modal-artist').textContent = painting.artist;
    document.getElementById('modal-style').textContent = painting.style;
    document.getElementById('modal-medium').textContent = painting.medium;
    document.getElementById('modal-size').textContent = painting.size;
    document.getElementById('modal-year').textContent = painting.year || 'N/A';
    document.getElementById('modal-description').textContent = painting.description;
    document.getElementById('modal-price').textContent = `$${painting.price}`;
    
    // Display tags
    const tagsDiv = document.getElementById('modal-tags');
    tagsDiv.innerHTML = '';
    if (painting.tags && painting.tags.length > 0) {
        painting.tags.forEach(tag => {
            const tagSpan = document.createElement('span');
            tagSpan.className = 'tag';
            tagSpan.textContent = tag;
            tagsDiv.appendChild(tagSpan);
        });
    }
    
    // Hide recommendations initially
    document.getElementById('recommendations').classList.add('hidden');
    
    // Show modal
    document.getElementById('painting-modal').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

// Close Modal
function closeModal() {
    document.getElementById('painting-modal').classList.add('hidden');
    document.body.style.overflow = 'auto';
    currentPaintingId = null;
}

// Get Recommendations
async function getRecommendations(paintingId) {
    const recommendationsDiv = document.getElementById('recommendations');
    const recommendationsGrid = document.getElementById('recommendations-grid');
    
    recommendationsDiv.classList.remove('hidden');
    recommendationsGrid.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
    
    try {
        const response = await fetch(`${API_URL}/recommendations/${paintingId}?limit=3`);
        const data = await response.json();
        
        if (data.success && data.recommendations.length > 0) {
            recommendationsGrid.innerHTML = '';
            
            data.recommendations.forEach(rec => {
                const card = document.createElement('div');
                card.className = 'recommendation-card';
                card.onclick = () => {
                    closeModal();
                    setTimeout(() => openModal(rec), 300);
                };
                
                card.innerHTML = `
                    <div class="recommendation-image">
                        <span class="image-icon" style="font-size: 2rem;">🖼️</span>
                    </div>
                    <div class="recommendation-title">${rec.title}</div>
                    <div class="recommendation-price">$${rec.price}</div>
                `;
                
                recommendationsGrid.appendChild(card);
            });
        } else {
            recommendationsGrid.innerHTML = '<p>No recommendations available.</p>';
        }
    } catch (error) {
        console.error('Error getting recommendations:', error);
        recommendationsGrid.innerHTML = '<p>Error loading recommendations.</p>';
    }
}

// Utility Functions
function showLoading() {
    document.getElementById('loading').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loading').classList.add('hidden');
}

function showNoResults() {
    document.getElementById('no-results').classList.remove('hidden');
}

function hideNoResults() {
    document.getElementById('no-results').classList.add('hidden');
}
