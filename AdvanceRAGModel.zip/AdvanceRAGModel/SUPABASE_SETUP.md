# SQL Setup Scripts for Supabase

## Run these scripts in your Supabase SQL Editor

### 1. Enable pgvector Extension

```sql
-- Enable the pgvector extension for vector similarity search
CREATE EXTENSION IF NOT EXISTS vector;
```

### 2. Create Paintings Table

```sql
-- Main paintings catalog table
CREATE TABLE IF NOT EXISTS paintings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    description TEXT NOT NULL,
    style TEXT NOT NULL,
    medium TEXT NOT NULL,
    size TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    year INTEGER,
    availability TEXT DEFAULT 'available',
    image_url TEXT,
    tags TEXT[],
    created_at TIMESTAMP DEFAULT NOW()
);
```

### 3. Create Painting Embeddings Table

```sql
-- Vector embeddings table for semantic search
CREATE TABLE IF NOT EXISTS painting_embeddings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    painting_id UUID REFERENCES paintings(id) ON DELETE CASCADE,
    embedding vector(1536),
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);
```

### 4. Create Indexes

```sql
-- Create vector similarity search index
CREATE INDEX IF NOT EXISTS painting_embeddings_embedding_idx 
ON painting_embeddings USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);

-- Create indexes for common queries
CREATE INDEX IF NOT EXISTS paintings_style_idx ON paintings(style);
CREATE INDEX IF NOT EXISTS paintings_artist_idx ON paintings(artist);
CREATE INDEX IF NOT EXISTS paintings_price_idx ON paintings(price);
```

### 5. Create Vector Similarity Search Function

```sql
-- Function for vector similarity search with paintings data
CREATE OR REPLACE FUNCTION match_paintings(
    query_embedding vector(1536),
    match_threshold float,
    match_count int
)
RETURNS TABLE (
    id UUID,
    painting_id UUID,
    title TEXT,
    artist TEXT,
    description TEXT,
    style TEXT,
    medium TEXT,
    size TEXT,
    price DECIMAL,
    similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        pe.id,
        pe.painting_id,
        p.title,
        p.artist,
        p.description,
        p.style,
        p.medium,
        p.size,
        p.price,
        1 - (pe.embedding <=> query_embedding) as similarity
    FROM painting_embeddings pe
    JOIN paintings p ON pe.painting_id = p.id
    WHERE 1 - (pe.embedding <=> query_embedding) > match_threshold
    ORDER BY pe.embedding <=> query_embedding
    LIMIT match_count;
END;
$$;
```

## Verification Queries

After running the above scripts, verify everything is set up correctly:

### Check if tables exist:
```sql
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public';
```

### Check if pgvector extension is enabled:
```sql
SELECT * FROM pg_extension WHERE extname = 'vector';
```

### Check paintings count (after seeding):
```sql
SELECT COUNT(*) FROM paintings;
SELECT COUNT(*) FROM painting_embeddings;
```

### Test vector search function:
```sql
-- This will fail before seeding but should work after
SELECT * FROM match_paintings(
    (SELECT embedding FROM painting_embeddings LIMIT 1),
    0.5,
    5
);
```

## Notes

- The `vector(1536)` dimension matches OpenAI's text-embedding-3-small model
- The `ivfflat` index improves search performance for large datasets
- Adjust `lists = 100` based on your dataset size (rule of thumb: rows/1000)
- The similarity threshold can be tuned in your application settings
