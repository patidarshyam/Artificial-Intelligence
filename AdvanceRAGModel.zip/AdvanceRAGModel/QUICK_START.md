# 🚀 Quick Start Guide - Running the Advanced RAG Paintings Store

## Prerequisites Checklist
- ✅ Python 3.9+ installed
- ✅ Supabase account with project created
- ✅ AI Gateway credentials configured in `.env`

---

## Step-by-Step Setup & Run Process

### **STEP 1: Verify Environment Configuration**

**Check your `.env` file exists and contains:**
```env
SUPABASE_URL=https://nvvizvmkvzbivkrxkpeg.supabase.co
SUPABASE_KEY=eyJhbGc...  (your full key)
AI_GATEWAY_CLIENT_REGISTRATION=isg-digital-pune-ai-gateway-training
AI_GATEWAY_CLIENT_ID=0oa2ks9mc0b7S1SFs0h8
AI_GATEWAY_CLIENT_SECRET=hEbha1...  (your full secret)
```

**✓ Verification:**
```powershell
Get-Content .env | Select-String "SUPABASE_URL|AI_GATEWAY_CLIENT_ID"
```

---

### **STEP 2: Activate Virtual Environment & Verify Installation**

**Activate virtual environment:**
```powershell
.\venv\Scripts\Activate
```

You should see `(venv)` in your prompt.

**Verify Python and packages:**
```powershell
python --version
# Should show: Python 3.12.4 or similar

pip list | Select-String "fastapi|langchain|supabase"
# Should show installed packages
```

---

### **STEP 3: Test AI Gateway Authentication**

**Run authentication test:**
```powershell
python test_auth.py
```

**Expected output:**
```
============================================================
AI GATEWAY AUTHENTICATION TEST
============================================================

Client ID: 0oa2ks9mc0b7S1SFs0h8
Gateway URL: https://ai-gateway.deere.com/openai/

[1/2] Requesting OAuth token...
✓ Token obtained successfully!
  - Token length: XXX characters
  - Expires in: 3600 seconds (60.0 minutes)

[2/2] AI Gateway is ready!
✓ Authentication configured correctly

============================================================
STATUS: ✓ AI Gateway authentication working!
============================================================
```

**⚠️ If authentication fails:**
- Verify credentials in `.env` file
- Check network connectivity
- Ensure AI Gateway client is active

---

### **STEP 4: Setup Supabase Database Tables**

**4.1 Open Supabase SQL Editor:**
- Go to: https://supabase.com/dashboard/project/nvvizvmkvzbivkrxkpeg/sql
- Login to your Supabase account

**4.2 Run SQL Scripts in order:**

**Script 1 - Enable pgvector:**
```sql
CREATE EXTENSION IF NOT EXISTS vector;
```
Click **"Run"**

**Script 2 - Create paintings table:**
```sql
CREATE TABLE IF NOT EXISTS paintings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    description TEXT NOT NULL,
    style TEXT NOT NULL,
    medium TEXT NOT NULL,
    size TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    year INTEGER,
    availability TEXT DEFAULT 'available',
    image_url TEXT,
    tags TEXT[],
    created_at TIMESTAMP DEFAULT NOW()
);
```
Click **"Run"**

**Script 3 - Create embeddings table:**
```sql
CREATE TABLE IF NOT EXISTS painting_embeddings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    painting_id UUID REFERENCES paintings(id) ON DELETE CASCADE,
    embedding vector(1536),
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);
```
Click **"Run"**

**Script 4 - Create indexes:**
```sql
CREATE INDEX IF NOT EXISTS painting_embeddings_embedding_idx 
ON painting_embeddings USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);

CREATE INDEX IF NOT EXISTS paintings_style_idx ON paintings(style);
CREATE INDEX IF NOT EXISTS paintings_artist_idx ON paintings(artist);
CREATE INDEX IF NOT EXISTS paintings_price_idx ON paintings(price);
```
Click **"Run"**

**Script 5 - Create vector search function:**
```sql
CREATE OR REPLACE FUNCTION match_paintings(
    query_embedding vector(1536),
    match_threshold float,
    match_count int
)
RETURNS TABLE (
    id UUID,
    painting_id UUID,
    title TEXT,
    artist TEXT,
    description TEXT,
    style TEXT,
    medium TEXT,
    size TEXT,
    price DECIMAL,
    similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        pe.id,
        pe.painting_id,
        p.title,
        p.artist,
        p.description,
        p.style,
        p.medium,
        p.size,
        p.price,
        1 - (pe.embedding <=> query_embedding) as similarity
    FROM painting_embeddings pe
    JOIN paintings p ON pe.painting_id = p.id
    WHERE 1 - (pe.embedding <=> query_embedding) > match_threshold
    ORDER BY pe.embedding <=> query_embedding
    LIMIT match_count;
END;
$$;
```
Click **"Run"**

**4.3 Verify tables created:**
```sql
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('paintings', 'painting_embeddings');
```
Should return 2 rows.

---

### **STEP 5: Seed Database with Sample Paintings**

**Run the seeding script:**
```powershell
python seed_data.py
```

**Expected output:**
```
============================================================
HANDMADE PAINTINGS STORE - DATABASE SEEDER
============================================================

This script will populate your database with sample paintings.
...
Starting in 3 seconds...

Starting database seeding process...
[1/20] Inserted: Sunset Over Lavender Fields
[1/20] Indexed: Sunset Over Lavender Fields
[2/20] Inserted: Abstract Dreams in Coral
[2/20] Indexed: Abstract Dreams in Coral
...
[20/20] Inserted: Peaceful Koi Pond
[20/20] Indexed: Peaceful Koi Pond

Database seeding completed successfully!
Total paintings added: 20
```

**⏱️ Estimated time:** 2-5 minutes (depending on AI Gateway response time)

**⚠️ If errors occur:**
- Check AI Gateway authentication (Step 3)
- Verify Supabase tables created (Step 4)
- Check network connectivity

**Verify data in Supabase:**
- Go to Table Editor in Supabase dashboard
- Check `paintings` table has 20 rows
- Check `painting_embeddings` table has 20 rows

---

### **STEP 6: Start the Application Server**

**Run the FastAPI server:**
```powershell
python main.py
```

**Expected output:**
```
============================================================
HANDMADE PAINTINGS STORE - API SERVER
============================================================

Starting server on http://localhost:8000
API Documentation: http://localhost:8000/docs
Alternative Docs: http://localhost:8000/redoc

Press CTRL+C to stop the server
============================================================
INFO:     Started server process [XXXX]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://localhost:8000 (Press CTRL+C to quit)
```

**Server is now running!** ✓

---

## 🧪 Testing the Application

### **TEST 1: Access Web Application**

**Open browser and visit:**
```
http://localhost:8000
```

**✓ You should see:**
- Beautiful landing page
- "Artisan Gallery" header
- Statistics showing "20 Unique Paintings"
- Search bar with AI search functionality

---

### **TEST 2: Test API Documentation**

**Visit Swagger UI:**
```
http://localhost:8000/docs
```

**✓ You should see:**
- Complete API documentation
- Interactive API endpoints
- Try the `/api/paintings` endpoint - click "Try it out" → "Execute"

---

### **TEST 3: Test Basic Painting Retrieval**

**In browser or API docs:**
```
GET http://localhost:8000/api/paintings
```

**Expected response:**
```json
{
  "success": true,
  "count": 20,
  "paintings": [
    {
      "id": "uuid-here",
      "title": "Sunset Over Lavender Fields",
      "artist": "Emma Richardson",
      "price": 450.00,
      ...
    }
  ]
}
```

---

### **TEST 4: Test AI-Powered Search (Web Interface)**

**On the homepage:**
1. Type in the search box: **"Show me peaceful landscapes under $500"**
2. Click "Search with AI" or press Enter

**✓ Expected behavior:**
- AI response appears with personalized recommendation
- Relevant paintings displayed below
- Each painting card shows title, artist, style, and price

---

### **TEST 5: Test Conversational AI Search (API)**

**In API docs or using curl:**
```
POST http://localhost:8000/api/search/conversational
Content-Type: application/json

{
  "query": "I need a calming piece for my bedroom with ocean themes",
  "limit": 5
}
```

**Expected response:**
```json
{
  "success": true,
  "query": "I need a calming piece for my bedroom with ocean themes",
  "answer": "Based on your needs for a calming bedroom piece with ocean themes, I'd recommend...",
  "paintings": [...],
  "count": 5
}
```

---

### **TEST 6: Test Filters (Web Interface)**

**On the homepage:**
1. Scroll to filter section
2. Select "Impressionism" from Style dropdown
3. Set Max Price to 500
4. Click "Apply Filters"

**✓ Expected behavior:**
- Gallery updates to show only Impressionism paintings under $500
- Filtered results display immediately

---

### **TEST 7: Test Painting Details & Recommendations**

**On the homepage:**
1. Click any painting card
2. Modal opens with full details
3. Click "Similar Paintings" button

**✓ Expected behavior:**
- Detailed painting information displayed
- Price, artist, style, description shown
- 3 similar painting recommendations appear
- Recommendations are contextually relevant

---

### **TEST 8: Test Statistics Endpoint**

```
GET http://localhost:8000/api/stats
```

**Expected response:**
```json
{
  "success": true,
  "stats": {
    "total_paintings": 20,
    "total_artists": 7,
    "total_styles": 8,
    "average_price": 486.25,
    "price_range": {
      "min": 325.00,
      "max": 720.00
    }
  }
}
```

---

## 📊 Performance & Monitoring

### **Check Server Logs**

Monitor terminal where `main.py` is running:
- Each API request logged
- AI Gateway token requests visible
- Any errors displayed in real-time

### **Test Response Times**

**Good performance indicators:**
- Standard queries: < 1 second
- AI conversational search: 2-5 seconds (includes LLM response)
- Embedding generation: 1-3 seconds per painting

---

## 🐛 Troubleshooting Guide

### **Problem: AI Gateway authentication fails**
**Solution:**
```powershell
python test_auth.py
```
- Check credentials in `.env`
- Verify network can reach Okta SSO endpoint
- Check client secret hasn't expired

### **Problem: No paintings returned**
**Solution:**
```powershell
python seed_data.py
```
- Re-run seeding script
- Check Supabase connection
- Verify tables exist in Supabase dashboard

### **Problem: Vector search returns empty**
**Solution:**
- Check embeddings were generated during seeding
- Verify pgvector extension enabled
- Check `match_paintings` function exists in Supabase

### **Problem: Server won't start**
**Solution:**
```powershell
# Check if port 8000 is in use
netstat -ano | findstr :8000

# If in use, change port in .env:
APP_PORT=8001

# Restart server
python main.py
```

---

## 🎯 Success Criteria Checklist

✅ **Authentication Test Passes** (test_auth.py)  
✅ **Database Tables Created** (5 tables/functions in Supabase)  
✅ **20 Paintings Seeded** (verified in Supabase dashboard)  
✅ **Server Starts Successfully** (no errors in terminal)  
✅ **Homepage Loads** (http://localhost:8000)  
✅ **API Docs Accessible** (http://localhost:8000/docs)  
✅ **AI Search Works** (returns relevant paintings)  
✅ **Filters Function** (can filter by style/price)  
✅ **Recommendations Work** (similar paintings displayed)  

---

## 🎨 Sample Test Queries

Try these AI search queries on the homepage:

1. **"Show me colorful abstract paintings under $600"**
2. **"I need something peaceful for a meditation room"**
3. **"Find me artwork with ocean or water themes"**
4. **"What impressionist pieces do you have?"**
5. **"I'm looking for large paintings with warm colors"**
6. **"Show me contemporary art by Marcus Chen"**
7. **"I need a gift for someone who loves nature"**
8. **"Find me paintings similar to Japanese art"**

---

## 📞 Next Steps After Testing

**Once all tests pass:**

1. **Explore the gallery** - Browse all 20 paintings
2. **Test different search queries** - See how AI responds
3. **Check recommendations** - Verify similarity works
4. **Add your own paintings** - Use POST /api/paintings endpoint
5. **Customize prompts** - Edit rag_engine.py to adjust AI behavior

---

## 🔐 Security Notes

- Never commit `.env` file to version control
- Keep AI Gateway credentials secure
- Supabase keys are for development only
- Use environment-specific configurations for production

---

## ✨ You're Ready!

Your Advanced RAG Handmade Paintings Store is now fully functional with:
- 🤖 AI-powered intelligent search
- 🎨 20 beautiful handmade paintings
- 🔍 Semantic vector search
- 💬 Conversational AI consultant
- 🎯 Smart recommendations

**Enjoy your AI-powered art gallery!** 🖼️

---

*Last Updated: December 18, 2025*
