"""
Advanced RAG (Retrieval-Augmented Generation) System for Handmade Paintings Store
Implements semantic search, embedding generation, and intelligent query answering
"""
from typing import List, Dict, Any, Optional
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from config import get_settings
from database import SupabaseDB
import logging
import json
import httpx
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AdvancedRAG:
    """Advanced RAG system for intelligent painting search and recommendations"""
    
    def __init__(self):
        settings = get_settings()
        self.settings = settings
        self._access_token = None
        self._token_expiry = 0
        
        # Get AI Gateway token
        api_key = self._get_ai_gateway_token()
        
        # Prepare custom headers for AI Gateway
        custom_headers = {
            "deere-ai-gateway-registration-id": settings.ai_gateway_client_registration
        }
        
        # Initialize embeddings model with AI Gateway
        self.embeddings = OpenAIEmbeddings(
            model=settings.embedding_model,
            openai_api_key=api_key,
            openai_api_base=settings.ai_gateway_base_url,
            default_headers=custom_headers
        )
        
        # Initialize LLM with AI Gateway
        self.llm = ChatOpenAI(
            model=settings.llm_model,
            temperature=0.7,
            openai_api_key=api_key,
            openai_api_base=settings.ai_gateway_base_url,
            default_headers=custom_headers
        )
        
        # Database client
        self.db = SupabaseDB()
        self.similarity_threshold = settings.similarity_threshold
    
    def _get_ai_gateway_token(self) -> str:
        """Get OAuth token from AI Gateway using client credentials"""
        # Check if token is still valid
        if self._access_token and time.time() < self._token_expiry:
            return self._access_token
        
        try:
            logger.info("Obtaining AI Gateway token...")
            
            # Prepare OAuth token request
            token_data = {
                'grant_type': 'client_credentials',
                'client_id': self.settings.ai_gateway_client_id,
                'client_secret': self.settings.ai_gateway_client_secret
            }
            
            # Request token from Okta SSO
            with httpx.Client() as client:
                response = client.post(
                    self.settings.okta_sso_token_endpoint,
                    data=token_data,
                    headers={'Content-Type': 'application/x-www-form-urlencoded'}
                )
                response.raise_for_status()
                
                token_response = response.json()
                self._access_token = token_response['access_token']
                
                # Set expiry with 5 minute buffer
                expires_in = token_response.get('expires_in', 3600)
                self._token_expiry = time.time() + expires_in - 300
                
                logger.info("Successfully obtained AI Gateway token")
                return self._access_token
                
        except Exception as e:
            logger.error(f"Error obtaining AI Gateway token: {e}")
            raise RuntimeError(f"Failed to authenticate with AI Gateway: {e}")
    
    def create_painting_document(self, painting: Dict[str, Any]) -> str:
        """Create a rich text document from painting data for embedding"""
        doc_parts = [
            f"Title: {painting.get('title', '')}",
            f"Artist: {painting.get('artist', '')}",
            f"Description: {painting.get('description', '')}",
            f"Style: {painting.get('style', '')}",
            f"Medium: {painting.get('medium', '')}",
            f"Size: {painting.get('size', '')}",
            f"Price: ${painting.get('price', '')}",
            f"Year: {painting.get('year', 'N/A')}"
        ]
        
        if painting.get('tags'):
            doc_parts.append(f"Tags: {', '.join(painting['tags'])}")
        
        return "\n".join(doc_parts)
    
    async def generate_embedding(self, text: str) -> List[float]:
        """Generate embedding vector for text"""
        try:
            embedding = await self.embeddings.aembed_query(text)
            return embedding
        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            raise
    
    def generate_embedding_sync(self, text: str) -> List[float]:
        """Generate embedding vector for text (synchronous)"""
        try:
            embedding = self.embeddings.embed_query(text)
            return embedding
        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            raise
    
    async def index_painting(self, painting: Dict[str, Any]) -> bool:
        """Index a painting by generating and storing its embedding"""
        try:
            # Create rich document
            doc_text = self.create_painting_document(painting)
            
            # Generate embedding
            embedding = await self.generate_embedding(doc_text)
            
            # Store in database
            metadata = {
                "title": painting.get('title'),
                "artist": painting.get('artist'),
                "style": painting.get('style'),
                "price": float(painting.get('price', 0))
            }
            
            self.db.insert_embedding(
                painting_id=painting['id'],
                embedding=embedding,
                metadata=metadata
            )
            
            logger.info(f"Successfully indexed painting: {painting.get('title')}")
            return True
        except Exception as e:
            logger.error(f"Error indexing painting: {e}")
            return False
    
    def index_painting_sync(self, painting: Dict[str, Any]) -> bool:
        """Index a painting synchronously"""
        try:
            doc_text = self.create_painting_document(painting)
            embedding = self.generate_embedding_sync(doc_text)
            
            metadata = {
                "title": painting.get('title'),
                "artist": painting.get('artist'),
                "style": painting.get('style'),
                "price": float(painting.get('price', 0))
            }
            
            self.db.insert_embedding(
                painting_id=painting['id'],
                embedding=embedding,
                metadata=metadata
            )
            
            logger.info(f"Successfully indexed painting: {painting.get('title')}")
            return True
        except Exception as e:
            logger.error(f"Error indexing painting: {e}")
            return False
    
    async def semantic_search(
        self, 
        query: str, 
        limit: int = 5,
        filters: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """Perform semantic search using RAG"""
        try:
            # Generate query embedding
            query_embedding = await self.generate_embedding(query)
            
            # Search in vector database
            results = self.db.search_paintings(
                query_embedding=query_embedding,
                limit=limit,
                similarity_threshold=self.similarity_threshold
            )
            
            # If vector search returns no results, fallback to regular search
            if not results:
                logger.info("Vector search returned no results, using fallback")
                results = self.db.get_all_paintings(limit=limit, filters=filters)
            
            return results
        except Exception as e:
            logger.error(f"Error in semantic search: {e}")
            return []
    
    def semantic_search_sync(
        self, 
        query: str, 
        limit: int = 5,
        filters: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """Perform semantic search synchronously"""
        try:
            query_embedding = self.generate_embedding_sync(query)
            results = self.db.search_paintings(
                query_embedding=query_embedding,
                limit=limit,
                similarity_threshold=self.similarity_threshold
            )
            
            if not results:
                logger.info("Vector search returned no results, using fallback")
                results = self.db.get_all_paintings(limit=limit, filters=filters)
            
            return results
        except Exception as e:
            logger.error(f"Error in semantic search: {e}")
            return []
    
    async def generate_recommendations(
        self, 
        painting_id: str, 
        limit: int = 3
    ) -> List[Dict[str, Any]]:
        """Generate similar painting recommendations"""
        try:
            # Get the original painting
            painting = self.db.get_painting_by_id(painting_id)
            if not painting:
                return []
            
            # Create query from painting
            query = self.create_painting_document(painting)
            
            # Find similar paintings
            results = await self.semantic_search(query, limit=limit + 1)
            
            # Filter out the original painting
            recommendations = [r for r in results if r.get('id') != painting_id][:limit]
            
            return recommendations
        except Exception as e:
            logger.error(f"Error generating recommendations: {e}")
            return []
    
    async def intelligent_query(self, user_query: str, context_paintings: List[Dict[str, Any]]) -> str:
        """
        Use LLM to generate intelligent responses based on painting context
        This is the core RAG functionality
        """
        try:
            # Prepare context from paintings
            context_text = "\n\n".join([
                f"Painting {i+1}:\n{self.create_painting_document(p)}"
                for i, p in enumerate(context_paintings)
            ])
            
            # Create prompt template
            prompt_template = ChatPromptTemplate.from_messages([
                ("system", """You are an expert art consultant for a handmade paintings online store. 
                Your role is to help customers find the perfect artwork based on their preferences, 
                space requirements, budget, and artistic taste.
                
                Use the following painting information to provide helpful, detailed, and personalized recommendations.
                Be enthusiastic about the art while being informative. Mention specific paintings by name when relevant.
                If asked about price, availability, or specific details, refer to the information provided.
                """),
                ("user", """Here are the available paintings that match your interest:
                
{context}

Customer Question: {query}

Please provide a helpful, personalized response:""")
            ])
            
            # Generate response
            chain = prompt_template | self.llm
            response = await chain.ainvoke({
                "context": context_text,
                "query": user_query
            })
            
            return response.content
        except Exception as e:
            logger.error(f"Error in intelligent query: {e}")
            return "I apologize, but I'm having trouble processing your request. Please try again."
    
    def intelligent_query_sync(self, user_query: str, context_paintings: List[Dict[str, Any]]) -> str:
        """Synchronous version of intelligent query"""
        try:
            context_text = "\n\n".join([
                f"Painting {i+1}:\n{self.create_painting_document(p)}"
                for i, p in enumerate(context_paintings)
            ])
            
            prompt_template = ChatPromptTemplate.from_messages([
                ("system", """You are an expert art consultant for a handmade paintings online store. 
                Your role is to help customers find the perfect artwork based on their preferences, 
                space requirements, budget, and artistic taste.
                
                Use the following painting information to provide helpful, detailed, and personalized recommendations.
                Be enthusiastic about the art while being informative. Mention specific paintings by name when relevant.
                If asked about price, availability, or specific details, refer to the information provided.
                """),
                ("user", """Here are the available paintings that match your interest:
                
{context}

Customer Question: {query}

Please provide a helpful, personalized response:""")
            ])
            
            chain = prompt_template | self.llm
            response = chain.invoke({
                "context": context_text,
                "query": user_query
            })
            
            return response.content
        except Exception as e:
            logger.error(f"Error in intelligent query: {e}")
            return "I apologize, but I'm having trouble processing your request. Please try again."
    
    async def conversational_search(self, user_query: str, limit: int = 5) -> Dict[str, Any]:
        """
        Complete RAG pipeline: semantic search + intelligent response generation
        """
        try:
            # Step 1: Retrieve relevant paintings using semantic search
            paintings = await self.semantic_search(user_query, limit=limit)
            
            # Step 2: Generate intelligent response using LLM
            response = await self.intelligent_query(user_query, paintings)
            
            return {
                "answer": response,
                "paintings": paintings,
                "query": user_query
            }
        except Exception as e:
            logger.error(f"Error in conversational search: {e}")
            return {
                "answer": "I apologize, but I encountered an error. Please try again.",
                "paintings": [],
                "query": user_query
            }
    
    def conversational_search_sync(self, user_query: str, limit: int = 5) -> Dict[str, Any]:
        """Synchronous version of conversational search"""
        try:
            paintings = self.semantic_search_sync(user_query, limit=limit)
            response = self.intelligent_query_sync(user_query, paintings)
            
            return {
                "answer": response,
                "paintings": paintings,
                "query": user_query
            }
        except Exception as e:
            logger.error(f"Error in conversational search: {e}")
            return {
                "answer": "I apologize, but I encountered an error. Please try again.",
                "paintings": [],
                "query": user_query
            }
