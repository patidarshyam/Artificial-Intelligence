"""
Supabase database client and operations
"""
from supabase import create_client, Client
from typing import List, Dict, Any, Optional
from config import get_settings
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SupabaseDB:
    """Supabase database client wrapper"""
    
    def __init__(self):
        settings = get_settings()
        self.client: Client = create_client(
            settings.supabase_url,
            settings.supabase_key
        )
        self.paintings_table = settings.paintings_table
        self.embeddings_table = settings.embeddings_table
    
    async def setup_database(self):
        """
        Setup database tables and enable pgvector extension.
        Run this SQL in your Supabase SQL Editor:
        
        -- Enable pgvector extension
        CREATE EXTENSION IF NOT EXISTS vector;
        
        -- Paintings table
        CREATE TABLE IF NOT EXISTS paintings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            description TEXT NOT NULL,
            style TEXT NOT NULL,
            medium TEXT NOT NULL,
            size TEXT NOT NULL,
            price DECIMAL(10, 2) NOT NULL,
            year INTEGER,
            availability TEXT DEFAULT 'available',
            image_url TEXT,
            tags TEXT[],
            created_at TIMESTAMP DEFAULT NOW()
        );
        
        -- Painting embeddings table with vector support
        CREATE TABLE IF NOT EXISTS painting_embeddings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            painting_id UUID REFERENCES paintings(id) ON DELETE CASCADE,
            embedding vector(1536),
            metadata JSONB,
            created_at TIMESTAMP DEFAULT NOW()
        );
        
        -- Create index for vector similarity search
        CREATE INDEX IF NOT EXISTS painting_embeddings_embedding_idx 
        ON painting_embeddings USING ivfflat (embedding vector_cosine_ops)
        WITH (lists = 100);
        
        -- Create indexes for common queries
        CREATE INDEX IF NOT EXISTS paintings_style_idx ON paintings(style);
        CREATE INDEX IF NOT EXISTS paintings_artist_idx ON paintings(artist);
        CREATE INDEX IF NOT EXISTS paintings_price_idx ON paintings(price);
        """
        logger.info("Database schema provided. Please run the SQL in Supabase SQL Editor.")
    
    def insert_painting(self, painting_data: Dict[str, Any]) -> Dict[str, Any]:
        """Insert a new painting"""
        try:
            result = self.client.table(self.paintings_table).insert(painting_data).execute()
            return result.data[0] if result.data else None
        except Exception as e:
            logger.error(f"Error inserting painting: {e}")
            raise
    
    def insert_embedding(self, painting_id: str, embedding: List[float], metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Insert painting embedding"""
        try:
            embedding_data = {
                "painting_id": painting_id,
                "embedding": embedding,
                "metadata": metadata
            }
            result = self.client.table(self.embeddings_table).insert(embedding_data).execute()
            return result.data[0] if result.data else None
        except Exception as e:
            logger.error(f"Error inserting embedding: {e}")
            raise
    
    def search_paintings(
        self, 
        query_embedding: List[float], 
        limit: int = 5,
        similarity_threshold: float = 0.7
    ) -> List[Dict[str, Any]]:
        """Vector similarity search for paintings"""
        try:
            # Use Supabase RPC for vector similarity search
            result = self.client.rpc(
                'match_paintings',
                {
                    'query_embedding': query_embedding,
                    'match_threshold': similarity_threshold,
                    'match_count': limit
                }
            ).execute()
            return result.data if result.data else []
        except Exception as e:
            logger.error(f"Error searching paintings: {e}")
            # Fallback to regular search
            return self.get_all_paintings(limit=limit)
    
    def get_all_paintings(self, limit: int = 50, filters: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """Get all paintings with optional filters"""
        try:
            query = self.client.table(self.paintings_table).select("*")
            
            if filters:
                if 'style' in filters:
                    query = query.eq('style', filters['style'])
                if 'artist' in filters:
                    query = query.eq('artist', filters['artist'])
                if 'min_price' in filters:
                    query = query.gte('price', filters['min_price'])
                if 'max_price' in filters:
                    query = query.lte('price', filters['max_price'])
            
            result = query.limit(limit).execute()
            return result.data if result.data else []
        except Exception as e:
            logger.error(f"Error getting paintings: {e}")
            return []
    
    def get_painting_by_id(self, painting_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific painting by ID"""
        try:
            result = self.client.table(self.paintings_table)\
                .select("*")\
                .eq('id', painting_id)\
                .single()\
                .execute()
            return result.data
        except Exception as e:
            logger.error(f"Error getting painting by ID: {e}")
            return None
    
    def update_painting(self, painting_id: str, update_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a painting"""
        try:
            result = self.client.table(self.paintings_table)\
                .update(update_data)\
                .eq('id', painting_id)\
                .execute()
            return result.data[0] if result.data else None
        except Exception as e:
            logger.error(f"Error updating painting: {e}")
            return None
    
    def delete_painting(self, painting_id: str) -> bool:
        """Delete a painting"""
        try:
            self.client.table(self.paintings_table)\
                .delete()\
                .eq('id', painting_id)\
                .execute()
            return True
        except Exception as e:
            logger.error(f"Error deleting painting: {e}")
            return False


# Create SQL function for vector similarity search
# Run this in Supabase SQL Editor:
"""
CREATE OR REPLACE FUNCTION match_paintings(
    query_embedding vector(1536),
    match_threshold float,
    match_count int
)
RETURNS TABLE (
    id UUID,
    painting_id UUID,
    title TEXT,
    artist TEXT,
    description TEXT,
    style TEXT,
    medium TEXT,
    size TEXT,
    price DECIMAL,
    similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        pe.id,
        pe.painting_id,
        p.title,
        p.artist,
        p.description,
        p.style,
        p.medium,
        p.size,
        p.price,
        1 - (pe.embedding <=> query_embedding) as similarity
    FROM painting_embeddings pe
    JOIN paintings p ON pe.painting_id = p.id
    WHERE 1 - (pe.embedding <=> query_embedding) > match_threshold
    ORDER BY pe.embedding <=> query_embedding
    LIMIT match_count;
END;
$$;
"""
