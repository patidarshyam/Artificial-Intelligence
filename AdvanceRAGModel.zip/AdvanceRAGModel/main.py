"""
FastAPI Backend Server for Advanced RAG Handmade Paintings Store
"""
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from database import SupabaseDB
from rag_engine import AdvancedRAG
from config import get_settings
import logging
import os

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Handmade Paintings Store API",
    description="Advanced RAG-powered API for intelligent painting search and recommendations",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize services
db = SupabaseDB()
rag = AdvancedRAG()
settings = get_settings()

# Mount static files directory
os.makedirs("static", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")


# Pydantic models for request/response
class PaintingCreate(BaseModel):
    title: str
    artist: str
    description: str
    style: str
    medium: str
    size: str
    price: float
    year: Optional[int] = None
    availability: str = "available"
    image_url: Optional[str] = None
    tags: Optional[List[str]] = []


class PaintingUpdate(BaseModel):
    title: Optional[str] = None
    artist: Optional[str] = None
    description: Optional[str] = None
    style: Optional[str] = None
    medium: Optional[str] = None
    size: Optional[str] = None
    price: Optional[float] = None
    year: Optional[int] = None
    availability: Optional[str] = None
    image_url: Optional[str] = None
    tags: Optional[List[str]] = None


class SearchQuery(BaseModel):
    query: str = Field(..., description="Natural language search query")
    limit: int = Field(5, ge=1, le=20, description="Number of results to return")
    filters: Optional[Dict[str, Any]] = None


class ConversationalQuery(BaseModel):
    query: str = Field(..., description="Natural language question about paintings")
    limit: int = Field(5, ge=1, le=20, description="Number of context paintings")


class SearchFilters(BaseModel):
    style: Optional[str] = None
    artist: Optional[str] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None


# API Endpoints

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main web application"""
    try:
        return FileResponse("static/index.html")
    except:
        return """
        <html>
            <head><title>Handmade Paintings Store</title></head>
            <body>
                <h1>Welcome to Handmade Paintings Store</h1>
                <p>The frontend is not yet set up. Please access the API at <a href="/docs">/docs</a></p>
            </body>
        </html>
        """


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Handmade Paintings Store API",
        "version": "1.0.0"
    }


@app.get("/api/paintings")
async def get_paintings(
    limit: int = Query(50, ge=1, le=100),
    style: Optional[str] = None,
    artist: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None
):
    """Get all paintings with optional filters"""
    try:
        filters = {}
        if style:
            filters['style'] = style
        if artist:
            filters['artist'] = artist
        if min_price is not None:
            filters['min_price'] = min_price
        if max_price is not None:
            filters['max_price'] = max_price
        
        paintings = db.get_all_paintings(limit=limit, filters=filters)
        return {
            "success": True,
            "count": len(paintings),
            "paintings": paintings
        }
    except Exception as e:
        logger.error(f"Error fetching paintings: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/paintings/{painting_id}")
async def get_painting(painting_id: str):
    """Get a specific painting by ID"""
    try:
        painting = db.get_painting_by_id(painting_id)
        if not painting:
            raise HTTPException(status_code=404, detail="Painting not found")
        return {
            "success": True,
            "painting": painting
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching painting: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/paintings")
async def create_painting(painting: PaintingCreate):
    """Create a new painting"""
    try:
        painting_data = painting.dict()
        new_painting = db.insert_painting(painting_data)
        
        if new_painting:
            # Index the painting for RAG search
            await rag.index_painting(new_painting)
            
            return {
                "success": True,
                "message": "Painting created successfully",
                "painting": new_painting
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to create painting")
    except Exception as e:
        logger.error(f"Error creating painting: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/paintings/{painting_id}")
async def update_painting(painting_id: str, painting: PaintingUpdate):
    """Update a painting"""
    try:
        update_data = {k: v for k, v in painting.dict().items() if v is not None}
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No update data provided")
        
        updated_painting = db.update_painting(painting_id, update_data)
        
        if not updated_painting:
            raise HTTPException(status_code=404, detail="Painting not found")
        
        # Re-index the painting
        await rag.index_painting(updated_painting)
        
        return {
            "success": True,
            "message": "Painting updated successfully",
            "painting": updated_painting
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating painting: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/paintings/{painting_id}")
async def delete_painting(painting_id: str):
    """Delete a painting"""
    try:
        success = db.delete_painting(painting_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Painting not found")
        
        return {
            "success": True,
            "message": "Painting deleted successfully"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting painting: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/search/semantic")
async def semantic_search(query: SearchQuery):
    """
    Semantic search using RAG
    Returns paintings similar to the natural language query
    """
    try:
        results = await rag.semantic_search(
            query=query.query,
            limit=query.limit,
            filters=query.filters
        )
        
        return {
            "success": True,
            "query": query.query,
            "count": len(results),
            "results": results
        }
    except Exception as e:
        logger.error(f"Error in semantic search: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/search/conversational")
async def conversational_search(query: ConversationalQuery):
    """
    Advanced RAG: Conversational search with intelligent responses
    Returns both an AI-generated answer and relevant paintings
    """
    try:
        result = await rag.conversational_search(
            user_query=query.query,
            limit=query.limit
        )
        
        return {
            "success": True,
            "query": query.query,
            "answer": result["answer"],
            "paintings": result["paintings"],
            "count": len(result["paintings"])
        }
    except Exception as e:
        logger.error(f"Error in conversational search: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/recommendations/{painting_id}")
async def get_recommendations(
    painting_id: str,
    limit: int = Query(3, ge=1, le=10)
):
    """Get similar painting recommendations"""
    try:
        recommendations = await rag.generate_recommendations(
            painting_id=painting_id,
            limit=limit
        )
        
        return {
            "success": True,
            "painting_id": painting_id,
            "count": len(recommendations),
            "recommendations": recommendations
        }
    except Exception as e:
        logger.error(f"Error generating recommendations: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/artists")
async def get_artists():
    """Get list of all artists"""
    try:
        paintings = db.get_all_paintings(limit=1000)
        artists = list(set(p.get('artist', '') for p in paintings if p.get('artist')))
        artists.sort()
        
        return {
            "success": True,
            "count": len(artists),
            "artists": artists
        }
    except Exception as e:
        logger.error(f"Error fetching artists: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/styles")
async def get_styles():
    """Get list of all painting styles"""
    try:
        paintings = db.get_all_paintings(limit=1000)
        styles = list(set(p.get('style', '') for p in paintings if p.get('style')))
        styles.sort()
        
        return {
            "success": True,
            "count": len(styles),
            "styles": styles
        }
    except Exception as e:
        logger.error(f"Error fetching styles: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/stats")
async def get_stats():
    """Get store statistics"""
    try:
        paintings = db.get_all_paintings(limit=1000)
        
        if not paintings:
            return {
                "success": True,
                "stats": {
                    "total_paintings": 0,
                    "total_artists": 0,
                    "total_styles": 0,
                    "average_price": 0,
                    "price_range": {"min": 0, "max": 0}
                }
            }
        
        prices = [float(p.get('price', 0)) for p in paintings if p.get('price')]
        
        stats = {
            "total_paintings": len(paintings),
            "total_artists": len(set(p.get('artist', '') for p in paintings)),
            "total_styles": len(set(p.get('style', '') for p in paintings)),
            "average_price": sum(prices) / len(prices) if prices else 0,
            "price_range": {
                "min": min(prices) if prices else 0,
                "max": max(prices) if prices else 0
            }
        }
        
        return {
            "success": True,
            "stats": stats
        }
    except Exception as e:
        logger.error(f"Error fetching stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    
    print("=" * 60)
    print("HANDMADE PAINTINGS STORE - API SERVER")
    print("=" * 60)
    print(f"\nStarting server on http://{settings.app_host}:{settings.app_port}")
    print(f"API Documentation: http://{settings.app_host}:{settings.app_port}/docs")
    print(f"Alternative Docs: http://{settings.app_host}:{settings.app_port}/redoc")
    print("\nPress CTRL+C to stop the server")
    print("=" * 60)
    
    uvicorn.run(
        "main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=False  # Disable reload to avoid Windows multiprocessing issues
    )
