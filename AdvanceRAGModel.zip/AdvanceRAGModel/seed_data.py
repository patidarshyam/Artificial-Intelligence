"""
Sample painting catalog data generator and database seeder
"""
import asyncio
from database import SupabaseDB
from rag_engine import AdvancedRAG
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


SAMPLE_PAINTINGS = [
    {
        "title": "Sunset Over Lavender Fields",
        "artist": "Emma Richardson",
        "description": "A breathtaking landscape capturing the golden hour over endless rows of purple lavender. The warm sunset creates a magical contrast with the cool purple hues. Hand-painted with meticulous attention to detail, this piece brings tranquility and natural beauty to any space.",
        "style": "Impressionism",
        "medium": "Oil on Canvas",
        "size": "24x36 inches",
        "price": 450.00,
        "year": 2023,
        "availability": "available",
        "image_url": "/static/images/sunset-lavender.jpg",
        "tags": ["landscape", "nature", "sunset", "lavender", "peaceful", "impressionist"]
    },
    {
        "title": "Abstract Dreams in Coral",
        "artist": "Marcus Chen",
        "description": "A vibrant abstract composition featuring flowing coral, peach, and turquoise tones. This contemporary piece evokes emotion through bold brushstrokes and dynamic color interplay. Perfect for modern interiors seeking a statement piece.",
        "style": "Abstract",
        "medium": "Acrylic on Canvas",
        "size": "30x40 inches",
        "price": 580.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/abstract-coral.jpg",
        "tags": ["abstract", "modern", "colorful", "contemporary", "bold", "statement piece"]
    },
    {
        "title": "Venetian Morning",
        "artist": "Sofia Lombardi",
        "description": "A romantic portrayal of Venice at dawn, with gondolas gently floating on misty canals. The soft morning light reflects off ancient architecture, creating an atmosphere of timeless beauty and Italian charm.",
        "style": "Realism",
        "medium": "Watercolor on Paper",
        "size": "18x24 inches",
        "price": 325.00,
        "year": 2023,
        "availability": "available",
        "image_url": "/static/images/venetian-morning.jpg",
        "tags": ["venice", "watercolor", "architecture", "romantic", "european", "travel"]
    },
    {
        "title": "Wildflower Meadow",
        "artist": "Emma Richardson",
        "description": "A joyful celebration of spring featuring a vibrant meadow bursting with wildflowers. Daisies, poppies, and cornflowers dance in the breeze. This cheerful piece brings the outdoors inside with its bright, uplifting energy.",
        "style": "Impressionism",
        "medium": "Oil on Canvas",
        "size": "20x30 inches",
        "price": 395.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/wildflower-meadow.jpg",
        "tags": ["flowers", "spring", "nature", "colorful", "cheerful", "botanical"]
    },
    {
        "title": "Urban Rhythm",
        "artist": "Jamal Washington",
        "description": "A dynamic urban scene capturing the energy of city life at night. Neon lights, bustling streets, and architectural silhouettes create a contemporary narrative about modern existence. Bold contrasts and geometric forms define this striking piece.",
        "style": "Contemporary",
        "medium": "Mixed Media on Canvas",
        "size": "36x48 inches",
        "price": 720.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/urban-rhythm.jpg",
        "tags": ["urban", "cityscape", "night", "contemporary", "architecture", "modern life"]
    },
    {
        "title": "Serene Mountain Lake",
        "artist": "Catherine O'Brien",
        "description": "A peaceful mountain landscape featuring a crystal-clear lake reflecting snow-capped peaks and pine forests. The tranquil scene invites meditation and appreciation of nature's grandeur. Painted with careful attention to light and atmosphere.",
        "style": "Realism",
        "medium": "Oil on Canvas",
        "size": "28x42 inches",
        "price": 525.00,
        "year": 2023,
        "availability": "available",
        "image_url": "/static/images/mountain-lake.jpg",
        "tags": ["mountains", "lake", "nature", "peaceful", "landscape", "scenic"]
    },
    {
        "title": "Jazz in Blue",
        "artist": "Marcus Chen",
        "description": "An energetic abstract interpretation of jazz music, with swirling blues, purples, and gold creating a visual symphony. The painting captures the spontaneity and soul of live jazz performance through bold, expressive marks.",
        "style": "Abstract Expressionism",
        "medium": "Acrylic on Canvas",
        "size": "32x32 inches",
        "price": 480.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/jazz-blue.jpg",
        "tags": ["abstract", "music", "jazz", "blue", "expressive", "contemporary"]
    },
    {
        "title": "Tuscan Vineyard at Harvest",
        "artist": "Sofia Lombardi",
        "description": "Rolling hills of Italian vineyards during harvest season, bathed in warm afternoon light. The painting captures the romance of wine country with rich earth tones and the charm of rustic Italian countryside.",
        "style": "Impressionism",
        "medium": "Oil on Canvas",
        "size": "24x30 inches",
        "price": 465.00,
        "year": 2023,
        "availability": "available",
        "image_url": "/static/images/tuscan-vineyard.jpg",
        "tags": ["italy", "vineyard", "landscape", "tuscany", "wine country", "rural"]
    },
    {
        "title": "Ocean Whispers",
        "artist": "Emma Richardson",
        "description": "An ethereal seascape capturing the gentle movement of waves meeting sandy shore. Soft blues and whites create a calming, meditative atmosphere. Perfect for bringing coastal serenity into your home.",
        "style": "Contemporary",
        "medium": "Acrylic on Canvas",
        "size": "30x40 inches",
        "price": 550.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/ocean-whispers.jpg",
        "tags": ["ocean", "seascape", "waves", "coastal", "serene", "blue"]
    },
    {
        "title": "Autumn Forest Path",
        "artist": "Catherine O'Brien",
        "description": "A winding forest path lined with trees ablaze in autumn colors. Golden yellows, burnt oranges, and deep reds create a warm, nostalgic atmosphere. The dappled light through the canopy invites viewers into the scene.",
        "style": "Realism",
        "medium": "Oil on Canvas",
        "size": "22x28 inches",
        "price": 410.00,
        "year": 2023,
        "availability": "available",
        "image_url": "/static/images/autumn-forest.jpg",
        "tags": ["autumn", "forest", "nature", "trees", "seasonal", "warm colors"]
    },
    {
        "title": "Geometric Harmony",
        "artist": "Jamal Washington",
        "description": "A bold geometric composition exploring the relationship between form, color, and space. Clean lines and vibrant color blocks create visual rhythm and balance. This modern piece adds sophistication to contemporary spaces.",
        "style": "Modern",
        "medium": "Acrylic on Canvas",
        "size": "36x36 inches",
        "price": 495.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/geometric-harmony.jpg",
        "tags": ["geometric", "modern", "abstract", "colorful", "minimalist", "contemporary"]
    },
    {
        "title": "Cherry Blossoms in Spring",
        "artist": "Yuki Tanaka",
        "description": "Delicate cherry blossoms in full bloom, painted with traditional Japanese-inspired techniques. Soft pinks and whites against a subtle background capture the fleeting beauty of sakura season. A celebration of renewal and natural elegance.",
        "style": "Asian Contemporary",
        "medium": "Watercolor on Silk",
        "size": "20x26 inches",
        "price": 385.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/cherry-blossoms.jpg",
        "tags": ["cherry blossoms", "sakura", "japanese", "spring", "delicate", "floral"]
    },
    {
        "title": "Desert Sunset Majesty",
        "artist": "Catherine O'Brien",
        "description": "Dramatic desert landscape with towering saguaro cacti silhouetted against a spectacular sunset sky. Rich purples, oranges, and reds create an unforgettable southwestern scene full of natural wonder.",
        "style": "Realism",
        "medium": "Oil on Canvas",
        "size": "30x40 inches",
        "price": 595.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/desert-sunset.jpg",
        "tags": ["desert", "sunset", "southwest", "cacti", "landscape", "dramatic"]
    },
    {
        "title": "Parisian Café Corner",
        "artist": "Sofia Lombardi",
        "description": "A charming street scene capturing the essence of Parisian café culture. Umbrellas, bistro chairs, and cobblestone streets evoke the romantic atmosphere of the City of Light. Perfect for Francophiles and travel enthusiasts.",
        "style": "Impressionism",
        "medium": "Oil on Canvas",
        "size": "24x32 inches",
        "price": 475.00,
        "year": 2023,
        "availability": "available",
        "image_url": "/static/images/parisian-cafe.jpg",
        "tags": ["paris", "cafe", "european", "street scene", "romantic", "urban"]
    },
    {
        "title": "Midnight Garden",
        "artist": "Emma Richardson",
        "description": "A mysterious nocturnal garden scene where moonlight illuminates exotic flowers and foliage. Deep blues and silvery whites create an enchanting, dreamlike quality. This unique piece adds intrigue and beauty to any room.",
        "style": "Contemporary",
        "medium": "Acrylic on Canvas",
        "size": "28x36 inches",
        "price": 520.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/midnight-garden.jpg",
        "tags": ["flowers", "night", "mysterious", "botanical", "moonlight", "enchanting"]
    },
    {
        "title": "Color Burst",
        "artist": "Marcus Chen",
        "description": "An explosive celebration of color featuring radiating patterns and energetic brushwork. Vibrant hues blend and contrast in a joyful display of artistic freedom. This piece instantly energizes any space with its positive vibes.",
        "style": "Abstract",
        "medium": "Acrylic on Canvas",
        "size": "40x40 inches",
        "price": 650.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/color-burst.jpg",
        "tags": ["abstract", "colorful", "vibrant", "energetic", "bold", "joyful"]
    },
    {
        "title": "Coastal Lighthouse",
        "artist": "Catherine O'Brien",
        "description": "A majestic lighthouse standing sentinel on rugged coastal cliffs. Crashing waves and dramatic skies emphasize the power of nature and the endurance of human structures. A powerful statement piece.",
        "style": "Realism",
        "medium": "Oil on Canvas",
        "size": "26x38 inches",
        "price": 545.00,
        "year": 2023,
        "availability": "available",
        "image_url": "/static/images/coastal-lighthouse.jpg",
        "tags": ["lighthouse", "coastal", "ocean", "dramatic", "maritime", "landscape"]
    },
    {
        "title": "Zen Garden Meditation",
        "artist": "Yuki Tanaka",
        "description": "A minimalist representation of a Japanese zen garden with carefully raked sand patterns and smooth stones. The peaceful composition promotes calm and mindfulness. Ideal for meditation spaces or modern interiors.",
        "style": "Minimalism",
        "medium": "Mixed Media on Canvas",
        "size": "24x24 inches",
        "price": 365.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/zen-garden.jpg",
        "tags": ["zen", "minimalist", "japanese", "meditation", "peaceful", "simple"]
    },
    {
        "title": "Market Day in Morocco",
        "artist": "Jamal Washington",
        "description": "A vibrant scene from a Moroccan souk filled with colorful textiles, spices, and bustling activity. Rich colors and intricate details transport viewers to exotic markets. This piece celebrates cultural diversity and adventure.",
        "style": "Contemporary",
        "medium": "Oil on Canvas",
        "size": "32x44 inches",
        "price": 680.00,
        "year": 2024,
        "availability": "available",
        "image_url": "/static/images/moroccan-market.jpg",
        "tags": ["morocco", "market", "cultural", "colorful", "travel", "exotic"]
    },
    {
        "title": "Peaceful Koi Pond",
        "artist": "Yuki Tanaka",
        "description": "Graceful koi fish swimming among lily pads in a tranquil pond. The painting captures the serene beauty of these ornamental fish with careful attention to their flowing movement and vibrant colors.",
        "style": "Asian Contemporary",
        "medium": "Watercolor on Paper",
        "size": "20x30 inches",
        "price": 395.00,
        "year": 2023,
        "availability": "available",
        "image_url": "/static/images/koi-pond.jpg",
        "tags": ["koi", "fish", "pond", "asian", "peaceful", "water"]
    }
]


async def seed_database():
    """Seed the database with sample paintings and generate embeddings"""
    try:
        db = SupabaseDB()
        rag = AdvancedRAG()
        
        logger.info("Starting database seeding process...")
        
        for idx, painting_data in enumerate(SAMPLE_PAINTINGS, 1):
            try:
                # Insert painting into database
                painting = db.insert_painting(painting_data)
                
                if painting:
                    logger.info(f"[{idx}/{len(SAMPLE_PAINTINGS)}] Inserted: {painting_data['title']}")
                    
                    # Generate and store embedding
                    await rag.index_painting(painting)
                    logger.info(f"[{idx}/{len(SAMPLE_PAINTINGS)}] Indexed: {painting_data['title']}")
                else:
                    logger.warning(f"Failed to insert: {painting_data['title']}")
                    
            except Exception as e:
                logger.error(f"Error processing {painting_data['title']}: {e}")
                continue
        
        logger.info("Database seeding completed successfully!")
        logger.info(f"Total paintings added: {len(SAMPLE_PAINTINGS)}")
        
    except Exception as e:
        logger.error(f"Error during database seeding: {e}")


def seed_database_sync():
    """Synchronous version for direct execution"""
    try:
        db = SupabaseDB()
        rag = AdvancedRAG()
        
        logger.info("Starting database seeding process...")
        
        for idx, painting_data in enumerate(SAMPLE_PAINTINGS, 1):
            try:
                # Insert painting into database
                painting = db.insert_painting(painting_data)
                
                if painting:
                    logger.info(f"[{idx}/{len(SAMPLE_PAINTINGS)}] Inserted: {painting_data['title']}")
                    
                    # Generate and store embedding
                    rag.index_painting_sync(painting)
                    logger.info(f"[{idx}/{len(SAMPLE_PAINTINGS)}] Indexed: {painting_data['title']}")
                else:
                    logger.warning(f"Failed to insert: {painting_data['title']}")
                    
            except Exception as e:
                logger.error(f"Error processing {painting_data['title']}: {e}")
                continue
        
        logger.info("Database seeding completed successfully!")
        logger.info(f"Total paintings added: {len(SAMPLE_PAINTINGS)}")
        
    except Exception as e:
        logger.error(f"Error during database seeding: {e}")


if __name__ == "__main__":
    # Run the seeding process
    print("=" * 60)
    print("HANDMADE PAINTINGS STORE - DATABASE SEEDER")
    print("=" * 60)
    print("\nThis script will populate your database with sample paintings.")
    print("Make sure you have:")
    print("1. Created a .env file with your Supabase and OpenAI credentials")
    print("2. Run the SQL setup scripts in Supabase SQL Editor")
    print("\nStarting in 3 seconds...")
    
    import time
    time.sleep(3)
    
    # Use synchronous version for CLI
    seed_database_sync()
