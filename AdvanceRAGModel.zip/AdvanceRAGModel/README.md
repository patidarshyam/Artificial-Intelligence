# 🎨 Advanced RAG Handmade Paintings Store

A sophisticated online shopping platform for handmade paintings powered by **Advanced RAG (Retrieval-Augmented Generation)** technology. This application uses AI to provide intelligent, conversational product search and personalized recommendations.

## 🌟 Features

### 🤖 Advanced AI Capabilities
- **Conversational Search**: Ask natural language questions like "Show me peaceful landscapes under $500"
- **Semantic Understanding**: AI understands intent, not just keywords
- **Intelligent Recommendations**: Get personalized painting suggestions based on similarity
- **Context-Aware Responses**: AI provides detailed explanations and suggestions

### 🎯 Core Functionality
- Browse handmade paintings by style, artist, and price range
- Vector-based semantic search using embeddings
- Real-time filtering and sorting
- Detailed painting information with artist profiles
- Responsive, modern UI with smooth animations

### 🏗️ Technical Stack
- **Backend**: FastAPI (Python)
- **Vector Database**: Supabase with pgvector extension
- **AI/ML**: LangChain, OpenAI embeddings & GPT-4
- **Frontend**: Vanilla JavaScript, HTML5, CSS3
- **Embedding Model**: OpenAI text-embedding-3-small
- **LLM**: GPT-4 Turbo Preview

## 📋 Prerequisites

- Python 3.9 or higher
- Supabase account (free tier works)
- OpenAI API key
- Git (optional)

## 🚀 Installation & Setup

### Step 1: Clone or Download the Project

```bash
cd c:\PythonWS\AdvanceRAGModel
```

### Step 2: Create Virtual Environment

```powershell
# Create virtual environment
python -m venv venv

# Activate it
.\venv\Scripts\Activate
```

### Step 3: Install Dependencies

```powershell
pip install -r requirements.txt
```

### Step 4: Setup Supabase

1. **Create a Supabase Project**:
   - Go to [https://supabase.com](https://supabase.com)
   - Create a new project (free tier)
   - Note your project URL and anon key

2. **Enable pgvector Extension**:
   - Go to SQL Editor in Supabase Dashboard
   - Run this command:
   ```sql
   CREATE EXTENSION IF NOT EXISTS vector;
   ```

3. **Create Database Tables**:
   - Copy the SQL from `database.py` (lines 29-66)
   - Run it in Supabase SQL Editor
   - This creates `paintings` and `painting_embeddings` tables

4. **Create Vector Search Function**:
   - Copy the SQL function from bottom of `database.py` (lines 153-178)
   - Run it in Supabase SQL Editor
   - This enables semantic similarity search

### Step 5: Configure Environment Variables

1. Copy the example environment file:
```powershell
cp .env.example .env
```

2. Edit `.env` file with your credentials:
```env
# Supabase Configuration
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your_supabase_anon_key_here

# AI Gateway Configuration (for secure AI access)
AI_GATEWAY_CLIENT_REGISTRATION=your-client-registration
AI_GATEWAY_CLIENT_ID=your-client-id
AI_GATEWAY_CLIENT_SECRET=your-client-secret
GALILEO_CONSOLE_URL=https://console-galileo-devl.deere.com
OKTA_SSO_TOKEN_ENDPOINT=https://sso-dev.johndeere.com/oauth2/your-auth-server/v1/token
AI_GATEWAY_BASE_URL=https://ai-gateway.deere.com/openai/
AI_GATEWAY_ENABLED=true

# Application Settings
APP_HOST=localhost
APP_PORT=8000
DEBUG=True

# Vector Search Settings
EMBEDDING_MODEL=text-embedding-3-small
LLM_MODEL=gpt-4-turbo-preview
VECTOR_DIMENSIONS=1536
SIMILARITY_THRESHOLD=0.7

# Database Table Names
PAINTINGS_TABLE=paintings
EMBEDDINGS_TABLE=painting_embeddings
```

**Note:** This application uses AI Gateway for secure, managed access to OpenAI services. The gateway handles authentication via OAuth 2.0 client credentials flow.

### Step 6: Seed the Database

This will populate your database with 20 sample paintings and generate embeddings:

```powershell
python seed_data.py
```

You should see output like:
```
[1/20] Inserted: Sunset Over Lavender Fields
[1/20] Indexed: Sunset Over Lavender Fields
...
Database seeding completed successfully!
Total paintings added: 20
```

### Step 7: Start the Application

```powershell
python main.py
```

The server will start on `http://localhost:8000`

You'll see:
```
============================================================
HANDMADE PAINTINGS STORE - API SERVER
============================================================

Starting server on http://localhost:8000
API Documentation: http://localhost:8000/docs
Alternative Docs: http://localhost:8000/redoc

Press CTRL+C to stop the server
============================================================
```

### Step 8: Access the Application

Open your browser and visit:
- **Main Application**: [http://localhost:8000](http://localhost:8000)
- **API Documentation**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **Alternative Docs**: [http://localhost:8000/redoc](http://localhost:8000/redoc)

## 📖 Usage Guide

### Browsing Paintings
1. Visit the homepage
2. Browse the gallery of handmade paintings
3. Use filters (style, artist, price) to narrow down results
4. Click any painting card to view details

### AI-Powered Search
1. Navigate to the "AI Search" section
2. Type natural language queries like:
   - "I need a calming piece for my bedroom with ocean themes"
   - "Show me colorful abstract paintings under $500"
   - "Find me something similar to impressionist landscapes"
3. The AI will provide personalized recommendations with explanations

### Getting Recommendations
1. Open any painting's detail modal
2. Click "Similar Paintings" button
3. View AI-recommended similar artworks

## 🏛️ Architecture Overview

```
┌─────────────────┐
│   Frontend      │
│  (HTML/CSS/JS)  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   FastAPI       │
│   REST API      │
└────────┬────────┘
         │
    ┌────┴────┐
    ▼         ▼
┌─────────┐ ┌──────────────┐
│Supabase │ │  RAG Engine  │
│pgvector │ │  (LangChain) │
└─────────┘ └──────┬───────┘
                   │
                   ▼
            ┌──────────────┐
            │  OpenAI API  │
            │ Embeddings   │
            │    & GPT-4   │
            └──────────────┘
```

### Key Components

1. **RAG Engine** (`rag_engine.py`):
   - Generates embeddings for paintings
   - Performs semantic search
   - Provides conversational AI responses

2. **Database Layer** (`database.py`):
   - Supabase client wrapper
   - Vector similarity search
   - CRUD operations

3. **API Server** (`main.py`):
   - RESTful API endpoints
   - Request validation
   - Error handling

4. **Frontend**:
   - Responsive web interface
   - Real-time search
   - Interactive modals

## 🔌 API Endpoints

### Paintings
- `GET /api/paintings` - List all paintings with filters
- `GET /api/paintings/{id}` - Get specific painting
- `POST /api/paintings` - Create new painting
- `PUT /api/paintings/{id}` - Update painting
- `DELETE /api/paintings/{id}` - Delete painting

### Search
- `POST /api/search/semantic` - Semantic vector search
- `POST /api/search/conversational` - AI conversational search

### Recommendations
- `GET /api/recommendations/{id}` - Get similar paintings

### Metadata
- `GET /api/artists` - List all artists
- `GET /api/styles` - List all styles
- `GET /api/stats` - Get store statistics

## 🎯 RAG Implementation Details

### How RAG Works in This Application

1. **Indexing Phase**:
   - Each painting's details are converted to rich text documents
   - OpenAI generates 1536-dimensional embeddings
   - Embeddings stored in Supabase with pgvector

2. **Retrieval Phase**:
   - User query is converted to embedding
   - Vector similarity search finds relevant paintings
   - Top results retrieved based on cosine similarity

3. **Generation Phase**:
   - Retrieved paintings provide context
   - GPT-4 generates personalized responses
   - Combines factual data with conversational tone

### Prompt Engineering Strategy

The system uses carefully crafted prompts:

```python
System: "You are an expert art consultant for a handmade paintings online store..."
Context: [Relevant paintings from vector search]
User Query: "Show me peaceful landscapes..."
```

This ensures:
- Accurate information grounded in actual inventory
- Natural, helpful conversation
- Personalized recommendations

## 🛠️ Customization

### Adding More Paintings

1. Add painting data to `seed_data.py`
2. Run: `python seed_data.py`

Or use the API:
```python
POST /api/paintings
{
    "title": "New Painting",
    "artist": "Artist Name",
    "description": "...",
    "style": "Contemporary",
    "medium": "Oil on Canvas",
    "size": "24x36 inches",
    "price": 500.00
}
```

### Adjusting AI Behavior

Edit `.env`:
```env
LLM_MODEL=gpt-4-turbo-preview  # Change model
SIMILARITY_THRESHOLD=0.7        # Adjust search sensitivity
```

### Modifying Prompts

Edit `rag_engine.py` in the `intelligent_query` method to customize AI responses.

## 🐛 Troubleshooting

### Import Errors
```powershell
pip install -r requirements.txt --upgrade
```

### Supabase Connection Failed
- Verify your SUPABASE_URL and SUPABASE_KEY in `.env`
- Check if pgvector extension is enabled
- Ensure tables are created

### OpenAI API Errors
- Verify your OPENAI_API_KEY is valid
- Check API quota/billing
- Ensure you have access to embedding models

### No Search Results
- Lower SIMILARITY_THRESHOLD in `.env`
- Ensure embeddings were generated (check `seed_data.py` output)
- Verify vector search function is created in Supabase

## 📚 Project Structure

```
AdvanceRAGModel/
├── main.py                 # FastAPI application
├── rag_engine.py          # RAG implementation
├── database.py            # Supabase client
├── config.py              # Configuration management
├── seed_data.py           # Database seeder
├── requirements.txt       # Python dependencies
├── .env.example          # Environment template
├── .env                  # Your configuration (create this)
├── .gitignore           # Git ignore rules
└── static/              # Frontend files
    ├── index.html       # Main HTML
    ├── css/
    │   └── style.css    # Styles
    └── js/
        └── app.js       # JavaScript logic
```

## 🔐 Security Notes

- Never commit `.env` file to version control
- Keep API keys secure
- Use environment-specific configurations
- Enable HTTPS in production
- Implement rate limiting for production use

## 🚀 Production Deployment

For production:

1. Set `DEBUG=False` in `.env`
2. Use proper CORS origins
3. Add authentication/authorization
4. Implement caching (Redis)
5. Use production ASGI server (Gunicorn + Uvicorn)
6. Enable HTTPS
7. Set up monitoring and logging

## 📄 License

This project is created for educational purposes.

## 🤝 Contributing

Feel free to fork, modify, and use this project as a learning resource for building RAG applications.

## 📞 Support

For issues and questions:
- Check the API documentation at `/docs`
- Review Supabase logs
- Check OpenAI API status
- Verify all environment variables

## 🎓 Learning Resources

- **RAG**: [LangChain Documentation](https://python.langchain.com/)
- **Embeddings**: [OpenAI Embeddings Guide](https://platform.openai.com/docs/guides/embeddings)
- **pgvector**: [Supabase Vector Documentation](https://supabase.com/docs/guides/ai)
- **FastAPI**: [FastAPI Documentation](https://fastapi.tiangolo.com/)

---

**Built with ❤️ using Advanced RAG Technology**

*Combining the power of vector search, embeddings, and large language models to create intelligent, conversational e-commerce experiences.*
