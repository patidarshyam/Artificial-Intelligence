"""
Demo script for the Enterprise Knowledge Assistant
This script demonstrates the core RAG functionality programmatically
"""

import os
import sys
import time
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add src to path
sys.path.append('src')

from src.document_processor import create_document_processor
from src.vector_store import create_vector_store
from src.rag_pipeline import create_rag_pipeline
from src.utils import create_sample_documents

def main():
    print("🤖 Enterprise Knowledge Assistant - Demo")
    print("=" * 50)
    
    # Check for AI Gateway credentials
    if not os.getenv('AI_GATEWAY_CLIENT_ID') or not os.getenv('AI_GATEWAY_CLIENT_SECRET'):
        print("❌ AI Gateway credentials not found!")
        print("Please set AI_GATEWAY_CLIENT_ID and AI_GATEWAY_CLIENT_SECRET in your .env file")
        return
    
    print("✅ AI Gateway credentials found")
    
    # Initialize components
    print("\n📦 Initializing components...")
    document_processor = create_document_processor()
    vector_store = create_vector_store()
    rag_pipeline = create_rag_pipeline(vector_store)
    
    print("✅ Components initialized")
    
    # Load sample documents
    print("\n📚 Loading sample documents...")
    sample_docs = create_sample_documents()
    
    all_chunks = []
    for filename, content in sample_docs.items():
        print(f"   Processing: {filename}")
        chunks = document_processor.process_text_content(content, filename)
        all_chunks.extend(chunks)
        print(f"   ✅ Generated {len(chunks)} chunks")
    
    print(f"\n📊 Total chunks: {len(all_chunks)}")
    
    # Add to vector store
    print("\n🔄 Building vector database...")
    success = vector_store.add_documents(all_chunks)
    
    if not success:
        print("❌ Failed to build vector database")
        return
    
    print("✅ Vector database built successfully")
    
    # Get database stats
    stats = vector_store.get_stats()
    print(f"\n📈 Database Statistics:")
    print(f"   Total documents: {stats.get('total_documents', 0)}")
    print(f"   Unique files: {stats.get('unique_files', 0)}")
    print(f"   Average tokens per chunk: {stats.get('average_tokens_per_chunk', 0):.0f}")
    print(f"   Vector dimension: {stats.get('vector_dimension', 0)}")
    
    # Demo queries
    demo_queries = [
        "How many vacation days do employees get?",
        "What are the password requirements?",
        "How do I submit an expense report?",
        "What is the remote work policy?",
        "How do I report a security incident?"
    ]
    
    print("\n🎯 Running demo queries...")
    print("=" * 50)
    
    total_time = 0
    
    for i, query in enumerate(demo_queries, 1):
        print(f"\n📝 Query {i}: {query}")
        print("-" * 40)
        
        start_time = time.time()
        response = rag_pipeline.answer_question(query)
        end_time = time.time()
        
        response_time = end_time - start_time
        total_time += response_time
        
        print(f"💬 Answer: {response['answer'][:200]}{'...' if len(response['answer']) > 200 else ''}")
        print(f"🎯 Confidence: {response['confidence']:.1%}")
        print(f"⏱️  Response Time: {response_time:.2f}s")
        print(f"📄 Sources Found: {len(response['sources'])}")
        
        if response['sources']:
            print("📚 Top Source:")
            top_source = response['sources'][0]
            print(f"   File: {top_source['filename']}")
            print(f"   Similarity: {top_source['similarity_score']:.3f}")
            print(f"   Preview: {top_source['text_preview'][:100]}...")
    
    # Summary statistics
    avg_response_time = total_time / len(demo_queries)
    print("\n" + "=" * 50)
    print("📊 Demo Summary")
    print("=" * 50)
    print(f"✅ Processed {len(demo_queries)} queries successfully")
    print(f"⏱️  Average response time: {avg_response_time:.2f}s")
    print(f"🎯 Target response time: < 3.0s")
    print(f"🚀 Performance: {'✅ GOOD' if avg_response_time < 3.0 else '⚠️ NEEDS OPTIMIZATION'}")
    
    # Interactive mode
    print("\n🎮 Interactive Mode")
    print("=" * 30)
    print("Ask your own questions! (type 'quit' to exit)")
    
    while True:
        user_query = input("\n💬 Your question: ").strip()
        
        if user_query.lower() in ['quit', 'exit', 'q']:
            break
        
        if not user_query:
            continue
        
        print("🔄 Processing...")
        start_time = time.time()
        response = rag_pipeline.answer_question(user_query)
        end_time = time.time()
        
        print(f"\n💡 Answer:")
        print(response['answer'])
        print(f"\n📊 Confidence: {response['confidence']:.1%} | Time: {end_time - start_time:.2f}s | Sources: {len(response['sources'])}")
        
        if response['sources']:
            print(f"\n📚 Top Source: {response['sources'][0]['filename']}")
    
    print("\n👋 Thank you for trying the Enterprise Knowledge Assistant!")
    print("🚀 Start the full web app with: streamlit run app.py")

if __name__ == "__main__":
    main()
