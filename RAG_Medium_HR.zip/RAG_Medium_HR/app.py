"""
Enterprise Knowledge Assistant - Main Streamlit Application
A RAG-powered chatbot for company knowledge base queries
"""

import os
import streamlit as st
import time
import logging
from dotenv import load_dotenv
from typing import List, Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()
logger.info("Environment variables loaded")

# Import custom modules
from src.document_processor import create_document_processor
from src.vector_store import create_vector_store
from src.rag_pipeline import create_rag_pipeline
from src.utils import (
    validate_file_type, 
    get_file_info, 
    display_metrics,
    initialize_sample_data
)

# Page configuration
st.set_page_config(
    page_title="Enterprise Knowledge Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better UI
st.markdown("""
<style>
    .main-header {
        text-align: center;
        padding: 1rem 0;
        color: #1f77b4;
    }
    .chat-container {
        max-height: 600px;
        overflow-y: auto;
        padding: 1rem;
        border-radius: 10px;
        background-color: #f8f9fa;
    }
    .source-box {
        background-color: #e9ecef;
        padding: 1rem;
        border-radius: 5px;
        margin: 0.5rem 0;
        border-left: 4px solid #1f77b4;
    }
    .confidence-high { color: #28a745; }
    .confidence-medium { color: #ffc107; }
    .confidence-low { color: #dc3545; }
    .response-time {
        font-size: 0.8rem;
        color: #6c757d;
        text-align: right;
    }
</style>
""", unsafe_allow_html=True)

def initialize_session_state():
    """Initialize Streamlit session state variables."""
    logger.info("Initializing session state")
    
    if 'messages' not in st.session_state:
        st.session_state.messages = []
        logger.info("Initialized messages list")
    
    if 'vector_store' not in st.session_state:
        logger.info("Creating vector store")
        st.session_state.vector_store = create_vector_store()
        logger.info("Vector store created successfully")
    
    if 'rag_pipeline' not in st.session_state:
        logger.info("Creating RAG pipeline")
        st.session_state.rag_pipeline = create_rag_pipeline(st.session_state.vector_store)
        logger.info("RAG pipeline created successfully")
    
    if 'document_processor' not in st.session_state:
        logger.info("Creating document processor")
        st.session_state.document_processor = create_document_processor()
        logger.info("Document processor created successfully")
    
    if 'uploaded_files' not in st.session_state:
        st.session_state.uploaded_files = set()
        logger.info("Initialized uploaded files set")
    
    if 'show_sources' not in st.session_state:
        st.session_state.show_sources = True
        logger.info("Initialized show_sources setting")

def display_welcome_message():
    """Display welcome message and instructions."""
    st.markdown('<h1 class="main-header">🤖 Enterprise Knowledge Assistant</h1>', unsafe_allow_html=True)
    
    st.markdown("""
    **Welcome to your AI-powered knowledge assistant!** I can help you find information from company documents including:
    
    - 📋 HR Policies & Procedures
    - 💻 IT Manuals & Guidelines  
    - 📊 Standard Operating Procedures (SOPs)
    - 📄 Company Documentation
    
    **How to get started:**
    1. Upload your documents using the sidebar (PDF or text files)
    2. Ask questions in natural language
    3. Get accurate, source-backed answers instantly
    """)

def render_sidebar():
    """Render the sidebar with file upload and database status."""
    with st.sidebar:
        st.header("📁 Document Management")
        
        # File upload
        uploaded_files = st.file_uploader(
            "Upload company documents",
            type=['pdf', 'txt', 'md'],
            accept_multiple_files=True,
            help="Upload PDF or text files containing company information"
        )
        
        # Process uploaded files
        if uploaded_files:
            process_uploaded_files(uploaded_files)
        
        # Load sample data button
        st.markdown("---")
        if st.button("📚 Load Sample Data", help="Load sample HR, IT, and SOP documents for testing"):
            load_sample_data()
        
        # Database status
        display_database_status()
        
        # Database management
        st.markdown("---")
        st.subheader("🗄️ Database Management")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔄 Refresh", help="Refresh database status"):
                st.rerun()
        
        with col2:
            if st.button("🗑️ Clear DB", help="Clear all documents from database"):
                clear_database()
        
        # Force delete button
        st.markdown("---")
        if st.button("💥 FORCE DELETE DB", help="Permanently delete all vector database files", type="secondary"):
            force_delete_vector_db()
        
        # Settings
        st.markdown("---")
        st.subheader("⚙️ Settings")
        
        st.session_state.show_sources = st.checkbox(
            "Show source details",
            value=st.session_state.show_sources,
            help="Display document sources with each response"
        )
        
        # Display metrics
        display_metrics()

def process_uploaded_files(uploaded_files):
    """Process uploaded files and add to vector store."""
    logger.info(f"Processing {len(uploaded_files)} uploaded file(s)")
    new_files = []
    
    for file in uploaded_files:
        file_info = get_file_info(file)
        file_key = f"{file_info['name']}_{file_info['size']}"
        logger.info(f"Checking file: {file_info['name']} (size: {file_info['size']} bytes)")
        
        if file_key not in st.session_state.uploaded_files:
            if validate_file_type(file):
                new_files.append(file)
                st.session_state.uploaded_files.add(file_key)
                logger.info(f"Added new file to process: {file.name}")
            else:
                logger.warning(f"Unsupported file type: {file.name}")
                st.error(f"Unsupported file type: {file.name}")
        else:
            logger.info(f"File already processed: {file.name}")
    
    if new_files:
        logger.info(f"Starting processing of {len(new_files)} new file(s)")
        with st.spinner(f"Processing {len(new_files)} file(s)..."):
            all_chunks = []
            
            for file in new_files:
                logger.info(f"Processing file: {file.name}")
                chunks = st.session_state.document_processor.process_uploaded_file(file)
                if chunks:
                    all_chunks.extend(chunks)
                    logger.info(f"Successfully processed {file.name}: {len(chunks)} chunks created")
                    st.success(f"✅ Processed: {file.name}")
                else:
                    logger.error(f"Failed to process file: {file.name}")
                    st.error(f"❌ Failed to process: {file.name}")
            
            if all_chunks:
                logger.info(f"Adding {len(all_chunks)} chunks to vector store")
                success = st.session_state.vector_store.add_documents(all_chunks)
                if success:
                    logger.info(f"Successfully added {len(all_chunks)} chunks to knowledge base")
                    st.success(f"🎉 Added {len(all_chunks)} document chunks to knowledge base!")
                    st.rerun()
                else:
                    logger.error("Failed to add documents to vector store")

def load_sample_data():
    """Load sample documents for testing."""
    logger.info("Loading sample data")
    with st.spinner("Loading sample data..."):
        sample_docs = initialize_sample_data()
        logger.info(f"Retrieved {len(sample_docs)} sample documents")
        
        if sample_docs:
            all_chunks = []
            for filename, content in sample_docs.items():
                logger.info(f"Processing sample document: {filename}")
                chunks = st.session_state.document_processor.process_text_content(content, filename)
                all_chunks.extend(chunks)
                logger.info(f"Created {len(chunks)} chunks from {filename}")
            
            if all_chunks:
                logger.info(f"Adding {len(all_chunks)} sample chunks to vector store")
                success = st.session_state.vector_store.add_documents(all_chunks)
                if success:
                    logger.info(f"Successfully loaded {len(all_chunks)} sample chunks")
                    st.success(f"🎉 Loaded {len(all_chunks)} sample document chunks!")
                    st.session_state.documents_processed = True
                    st.rerun()
                else:
                    logger.error("Failed to add sample documents to vector store")

def display_database_status():
    """Display vector database status and statistics."""
    st.subheader("📊 Database Status")
    
    stats = st.session_state.vector_store.get_stats()
    
    if stats:
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Documents", stats.get('total_documents', 0))
            st.metric("Files", stats.get('unique_files', 0))
        
        with col2:
            st.metric("Avg Tokens", f"{stats.get('average_tokens_per_chunk', 0):.0f}")
            st.metric("Index Size", f"{stats.get('index_size_mb', 0):.1f} MB")
        
        # Model information
        st.caption(f"📡 Embedding: {stats.get('embedding_model', 'Unknown')}")
        st.caption(f"🧠 Dimension: {stats.get('vector_dimension', 'Unknown')}")
    else:
        st.info("No documents in database. Upload files to get started!")

def clear_database():
    """Clear the vector database."""
    # Initialize confirmation state
    if 'confirm_clear' not in st.session_state:
        st.session_state.confirm_clear = False
    
    if not st.session_state.confirm_clear:
        st.warning("⚠️ This will delete all documents and chat history!")
        if st.button("⚠️ Confirm Clear Database"):
            st.session_state.confirm_clear = True
            st.rerun()
    else:
        logger.warning("Clearing all documents from database")
        
        # Clear the database
        success = st.session_state.vector_store.clear_database()
        
        if success:
            # Reinitialize the vector store to ensure fresh state
            st.session_state.vector_store = create_vector_store()
            
            # Reinitialize RAG pipeline with new vector store
            st.session_state.rag_pipeline = create_rag_pipeline(st.session_state.vector_store)
            
            # Clear all session data
            st.session_state.uploaded_files.clear()
            st.session_state.messages.clear()
            st.session_state.confirm_clear = False
            
            logger.info("Database cleared successfully")
            st.success("✅ Database cleared successfully! You can now upload new documents.")
            time.sleep(1)
            st.rerun()
        else:
            st.session_state.confirm_clear = False
            logger.error("Failed to clear database")

def force_delete_vector_db():
    """Force delete all vector database files and restart."""
    import shutil
    
    if 'confirm_force_delete' not in st.session_state:
        st.session_state.confirm_force_delete = False
    
    if not st.session_state.confirm_force_delete:
        st.error("🗑️ This will PERMANENTLY DELETE all vector database files!")
        if st.button("🗑️ CONFIRM FORCE DELETE", type="primary"):
            st.session_state.confirm_force_delete = True
            st.rerun()
    else:
        try:
            logger.warning("Force deleting vector database")
            
            # Get the vector_db path
            vector_db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vector_db")
            
            # Delete the entire directory
            if os.path.exists(vector_db_path):
                shutil.rmtree(vector_db_path)
                logger.info(f"Deleted directory: {vector_db_path}")
            
            # Recreate empty directory
            os.makedirs(vector_db_path, exist_ok=True)
            logger.info(f"Recreated empty directory: {vector_db_path}")
            
            # Clear all session state to force complete reinitialization
            keys_to_delete = ['vector_store', 'rag_pipeline', 'document_processor', 'messages', 'uploaded_files']
            for key in keys_to_delete:
                if key in st.session_state:
                    del st.session_state[key]
            
            st.session_state.confirm_force_delete = False
            
            st.success("✅ Vector database PERMANENTLY DELETED! Page will reload...")
            logger.info("Vector database force deleted successfully")
            time.sleep(1)
            st.rerun()
            
        except Exception as e:
            logger.error(f"Error force deleting vector database: {str(e)}")
            st.error(f"Error: {str(e)}")
            st.session_state.confirm_force_delete = False

def display_chat_interface():
    """Display the main chat interface."""
    st.subheader("💬 Ask Questions")
    
    # Display conversation starter questions if no messages
    if not st.session_state.messages:
        st.markdown("**💡 Try asking about:**")
        starter_questions = st.session_state.rag_pipeline.get_conversation_starter_questions()
        
        cols = st.columns(2)
        for i, question in enumerate(starter_questions[:6]):
            col = cols[i % 2]
            if col.button(question, key=f"starter_{i}"):
                handle_user_question(question)
    
    # Chat messages container
    chat_container = st.container()
    
    with chat_container:
        # Display chat history
        for message in st.session_state.messages:
            display_message(message)
    
    # Chat input
    query = st.chat_input("Ask me anything about company policies, procedures, or guidelines...")
    
    if query:
        handle_user_question(query)

def handle_user_question(query: str):
    """Handle user question and generate response."""
    logger.info(f"Received user question: {query}")
    
    # Add user message
    st.session_state.messages.append({
        "role": "user",
        "content": query,
        "timestamp": time.time()
    })
    
    # Check if vector store has documents
    doc_count = st.session_state.vector_store.index.ntotal
    logger.info(f"Vector store has {doc_count} documents")
    
    if doc_count == 0:
        logger.warning("No documents in vector store")
        response = {
            'answer': "I don't have any documents to search through yet. Please upload some company documents using the sidebar to get started!",
            'sources': [],
            'confidence': 0.0,
            'response_time': 0.0
        }
    else:
        # Generate response using RAG pipeline
        logger.info("Querying RAG pipeline")
        start_time = time.time()
        with st.spinner("Searching knowledge base..."):
            response = st.session_state.rag_pipeline.answer_question(query)
        elapsed_time = time.time() - start_time
        logger.info(f"RAG pipeline response generated in {elapsed_time:.2f}s")
        logger.info(f"Response confidence: {response.get('confidence', 0.0):.3f}")
        logger.info(f"Number of sources: {len(response.get('sources', []))}")
    
    # Add assistant message
    st.session_state.messages.append({
        "role": "assistant",
        "content": response['answer'],
        "sources": response.get('sources', []),
        "confidence": response.get('confidence', 0.0),
        "response_time": response.get('response_time', 0.0),
        "timestamp": time.time()
    })
    logger.info("Response added to message history")
    
    st.rerun()

def display_message(message: Dict):
    """Display a chat message with proper formatting."""
    role = message["role"]
    content = message["content"]
    
    if role == "user":
        with st.chat_message("user"):
            st.write(content)
    
    else:  # assistant
        with st.chat_message("assistant"):
            st.write(content)
            
            # Display confidence and response time
            confidence = message.get("confidence", 0.0)
            response_time = message.get("response_time", 0.0)
            
            col1, col2, col3 = st.columns([2, 1, 1])
            with col2:
                confidence_class = "confidence-high" if confidence > 0.7 else "confidence-medium" if confidence > 0.4 else "confidence-low"
                st.markdown(f'<span class="{confidence_class}">Confidence: {confidence:.1%}</span>', unsafe_allow_html=True)
            with col3:
                st.markdown(f'<div class="response-time">{response_time:.2f}s</div>', unsafe_allow_html=True)
            
            # Display sources if available and enabled
            sources = message.get("sources", [])
            if sources and st.session_state.show_sources:
                msg_id = message.get("timestamp", time.time())
                display_sources(sources, msg_id)

def display_sources(sources: List[Dict], msg_id: float = None):
    """Display source documents with expandable details."""
    if not sources:
        return
    
    if msg_id is None:
        msg_id = time.time()
    
    st.markdown("**📚 Sources:**")
    
    for i, source in enumerate(sources, 1):
        filename = source.get('filename', 'Unknown')
        similarity = source.get('similarity_score', 0.0)
        preview = source.get('text_preview', '')
        
        with st.expander(f"Source {i}: {filename} (Similarity: {similarity:.3f})"):
            st.markdown(f"**File:** {filename}")
            st.markdown(f"**Chunk ID:** {source.get('chunk_id', 'N/A')}")
            st.markdown(f"**Similarity Score:** {similarity:.3f}")
            
            st.markdown("**Content Preview:**")
            st.markdown(f'<div class="source-box">{preview}</div>', unsafe_allow_html=True)
            
            if st.button(f"Show full text", key=f"full_text_{msg_id}_{i}"):
                st.text_area(
                    "Full content:",
                    source.get('full_text', ''),
                    height=200,
                    key=f"full_content_{msg_id}_{i}"
                )

def main():
    """Main application function."""
    logger.info("Starting main application")
    
    # Initialize session state
    initialize_session_state()
    
    # Check for AI Gateway credentials
    if not os.getenv('AI_GATEWAY_CLIENT_ID') or not os.getenv('AI_GATEWAY_CLIENT_SECRET'):
        logger.error("AI Gateway credentials not found in environment variables")
        st.error("🔑 AI Gateway credentials not found! Please set AI_GATEWAY_CLIENT_ID and AI_GATEWAY_CLIENT_SECRET in your environment variables.")
        st.info("You can set them in a .env file in the project root directory.")
        st.stop()
    
    logger.info("AI Gateway credentials found")
    
    # Render sidebar
    render_sidebar()
    
    # Main content area
    doc_count = st.session_state.vector_store.index.ntotal
    logger.info(f"Vector store has {doc_count} documents")
    
    if doc_count == 0:
        display_welcome_message()
        
        # Show quick start options
        st.markdown("### 🚀 Quick Start")
        col1, col2 = st.columns(2)
        
        with col1:
            st.info("**Option 1:** Upload your company documents using the sidebar")
        
        with col2:
            st.info("**Option 2:** Try the sample data to see how it works")
    
    else:
        # Display chat interface when documents are available
        display_chat_interface()
    
    # Footer
    st.markdown("---")
    st.markdown(
        '<div style="text-align: center; color: #6c757d; font-size: 0.8rem;">'
        'Enterprise Knowledge Assistant v1.0 | Built with Streamlit & OpenAI'
        '</div>',
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    logger.info("="*50)
    logger.info("Enterprise Knowledge Assistant Starting")
    logger.info("="*50)
    main()
