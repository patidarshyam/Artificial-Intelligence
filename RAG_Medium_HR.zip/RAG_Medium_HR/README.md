# 🤖 Enterprise Knowledge Assistant

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.28+-red.svg)](https://streamlit.io/)
[![OpenAI](https://img.shields.io/badge/OpenAI-GPT--3.5/4-green.svg)](https://openai.com/)
[![FAISS](https://img.shields.io/badge/FAISS-Vector%20Search-orange.svg)](https://github.com/facebookresearch/faiss)

A sophisticated **Retrieval-Augmented Generation (RAG)** chatbot built with Streamlit to help employees efficiently retrieve and understand internal company information such as HR policies, IT manuals, and standard operating procedures (SOPs).

## 🎯 Features

- 📄 **Multi-format Document Support**: Upload PDFs and text files
- 🔍 **Intelligent Search**: FAISS-powered vector similarity search
- 🤖 **AI-Powered Responses**: GPT-based answer generation grounded in company documents
- 📊 **Source Attribution**: View document snippets and sources for each response
- ⚡ **Fast Performance**: Optimized for sub-3-second response times
- 🔄 **Incremental Updates**: Add new documents without rebuilding the entire database
- 📈 **Real-time Analytics**: Performance metrics and usage tracking

## 🚀 Quick Start

### Option 1: Automated Setup (Recommended)

**macOS/Linux:**
```bash
git clone https://github.com/writersrinivasan/RAG_Medium_HR.git
cd RAG_Medium_HR
chmod +x setup.sh
./setup.sh
```

**Windows:**
```cmd
git clone https://github.com/writersrinivasan/RAG_Medium_HR.git
cd RAG_Medium_HR
setup.bat
```

### Option 2: Manual Setup

1. **Clone the repository:**
   ```bash
   git clone https://github.com/writersrinivasan/RAG_Medium_HR.git
   cd RAG_Medium_HR
   ```

2. **Create virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment:**
   ```bash
   cp .env.example .env
   # Edit .env and add your OpenAI API key
   ```

5. **Run the application:**
   ```bash
   streamlit run app.py
   ```

## 🔑 Configuration

Create a `.env` file with your OpenAI API key:

```bash
OPENAI_API_KEY=your_openai_api_key_here
EMBEDDING_MODEL=text-embedding-3-small
CHAT_MODEL=gpt-3.5-turbo
MAX_TOKENS=1000
TEMPERATURE=0.1
CHUNK_SIZE=1000
CHUNK_OVERLAP=200
MAX_RETRIEVAL_DOCS=5
```

Get your API key from: [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)

## Usage

1. **Upload Documents**: Use the sidebar to upload PDF or text files
2. **Ask Questions**: Type your questions in the chat interface
3. **View Sources**: Expand the source sections to see relevant document snippets
4. **Monitor Database**: Check the sidebar for document count and database status

## Architecture

- **Frontend**: Streamlit web interface
- **Vector Database**: FAISS for similarity search
- **Embeddings**: OpenAI text-embedding-3-small
- **LLM**: OpenAI GPT-3.5-turbo or GPT-4
- **Document Processing**: PyPDF2 for PDF extraction, custom text chunking

## Performance Targets

- Query response time: < 3 seconds
- RAG accuracy: ≥ 90% for document-based questions
- Supports moderate corpus sizes (up to 1000+ documents)

## File Structure

```
├── app.py                 # Main Streamlit application
├── src/
│   ├── document_processor.py  # Document ingestion and chunking
│   ├── vector_store.py        # FAISS vector database management
│   ├── rag_pipeline.py        # RAG implementation
│   └── utils.py              # Utility functions
├── data/                     # Document storage
├── vector_db/               # FAISS index storage
└── requirements.txt         # Dependencies
```
