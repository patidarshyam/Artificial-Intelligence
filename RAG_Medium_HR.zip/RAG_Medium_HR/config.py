# Configuration file for the Enterprise Knowledge Assistant

import os
from typing import Dict, Any

# Default configuration values
DEFAULT_CONFIG = {
    # AI Gateway Settings (replacing OpenAI)
    'AI_GATEWAY_CLIENT_REGISTRATION': '',
    'AI_GATEWAY_CLIENT_ID': '',
    'AI_GATEWAY_CLIENT_SECRET': '',
    'OKTA_SSO_TOKEN_ENDPOINT': '',
    'EMBEDDING_MODEL': 'text-embedding-3-small',
    'CHAT_MODEL': 'gpt-4o-mini-2024-07-18',
    'MAX_TOKENS': 1000,
    'TEMPERATURE': 0.1,
    
    # Vector Database Settings
    'CHUNK_SIZE': 1000,
    'CHUNK_OVERLAP': 200,
    'MAX_RETRIEVAL_DOCS': 5,
    'VECTOR_DIMENSION': 1536,
    
    # Application Settings
    'MAX_FILE_SIZE_MB': 50,
    'ALLOWED_FILE_TYPES': ['.pdf', '.txt', '.md'],
    'MAX_QUERY_LENGTH': 1000,
    'SESSION_TIMEOUT_MINUTES': 60,
    
    # Performance Settings
    'CACHE_RESPONSES': True,
    'BATCH_SIZE': 10,
    'MAX_CONCURRENT_UPLOADS': 3,
    
    # UI Settings
    'SHOW_CONFIDENCE_SCORES': True,
    'SHOW_RESPONSE_TIME': True,
    'SHOW_SOURCE_PREVIEW_LENGTH': 200,
    'MAX_CHAT_HISTORY': 50
}

def load_config() -> Dict[str, Any]:
    """Load configuration from environment variables with defaults."""
    config = {}
    
    for key, default_value in DEFAULT_CONFIG.items():
        env_value = os.getenv(key)
        
        if env_value is not None:
            # Type conversion based on default value type
            if isinstance(default_value, bool):
                config[key] = env_value.lower() in ('true', '1', 'yes', 'on')
            elif isinstance(default_value, int):
                try:
                    config[key] = int(env_value)
                except ValueError:
                    config[key] = default_value
            elif isinstance(default_value, float):
                try:
                    config[key] = float(env_value)
                except ValueError:
                    config[key] = default_value
            elif isinstance(default_value, list):
                # Assume comma-separated values for lists
                config[key] = [item.strip() for item in env_value.split(',')]
            else:
                config[key] = env_value
        else:
            config[key] = default_value
    
    return config

def validate_config(config: Dict[str, Any]) -> bool:
    """Validate configuration values."""
    errors = []
    
    # Required settings for AI Gateway
    if not config.get('AI_GATEWAY_CLIENT_ID'):
        errors.append("AI_GATEWAY_CLIENT_ID is required")
    if not config.get('AI_GATEWAY_CLIENT_SECRET'):
        errors.append("AI_GATEWAY_CLIENT_SECRET is required")
    if not config.get('OKTA_SSO_TOKEN_ENDPOINT'):
        errors.append("OKTA_SSO_TOKEN_ENDPOINT is required")
    
    # Numeric validations
    if config.get('CHUNK_SIZE', 0) < 100:
        errors.append("CHUNK_SIZE must be at least 100")
    
    if config.get('CHUNK_OVERLAP', 0) < 0:
        errors.append("CHUNK_OVERLAP must be non-negative")
    
    if config.get('MAX_TOKENS', 0) < 100:
        errors.append("MAX_TOKENS must be at least 100")
    
    if not 0 <= config.get('TEMPERATURE', 0) <= 2:
        errors.append("TEMPERATURE must be between 0 and 2")
    
    if config.get('MAX_RETRIEVAL_DOCS', 0) < 1:
        errors.append("MAX_RETRIEVAL_DOCS must be at least 1")
    
    # Model validations
    valid_embedding_models = [
        'text-embedding-3-small',
        'text-embedding-3-large',
        'text-embedding-ada-002'
    ]
    
    if config.get('EMBEDDING_MODEL') not in valid_embedding_models:
        errors.append(f"EMBEDDING_MODEL must be one of: {', '.join(valid_embedding_models)}")
    
    valid_chat_models = [
        'gpt-4o-mini-2024-07-18',
        'gpt-4o-2024-11-20',
        'gpt-4o-2024-08-06',
        'gpt-5-2025-08-07',
        'gpt-5-mini-2025-08-07',
        'gpt-3.5-turbo',
        'gpt-4',
        'gpt-4-turbo-preview',
        'gpt-4o',
        'gpt-4o-mini'
    ]
    
    if config.get('CHAT_MODEL') not in valid_chat_models:
        errors.append(f"CHAT_MODEL must be one of: {', '.join(valid_chat_models)}")
    
    if errors:
        raise ValueError(f"Configuration validation failed: {'; '.join(errors)}")
    
    return True

# Global configuration instance
CONFIG = load_config()

def get_config() -> Dict[str, Any]:
    """Get the current configuration."""
    return CONFIG.copy()

def update_config(updates: Dict[str, Any]) -> None:
    """Update configuration values."""
    global CONFIG
    CONFIG.update(updates)
    validate_config(CONFIG)
