# 🤖 Enterprise Knowledge Assistant - Usage Guide

## Overview
The Enterprise Knowledge Assistant is a sophisticated RAG (Retrieval-Augmented Generation) application that helps employees quickly find accurate information from company documents. It combines advanced document processing, vector similarity search, and AI-powered response generation.

## 🚀 Getting Started

### 1. Quick Setup
```bash
# Clone or extract the project
cd RAG_Medium_HR

# Run the setup script (will install dependencies and start the app)
./setup.sh  # macOS/Linux
# or
setup.bat   # Windows
```

### 2. Manual Setup
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env and add your OpenAI API key

# Start the application
streamlit run app.py
```

## 📚 Using the Application

### Document Upload
1. **Sidebar Upload**: Use the file uploader in the sidebar
2. **Supported Formats**: PDF, TXT, MD files
3. **Sample Data**: Click "Load Sample Data" to try with example documents
4. **Batch Upload**: Select multiple files at once

### Asking Questions
1. **Natural Language**: Ask questions in plain English
2. **Specific Queries**: Be specific for better results
3. **Follow-ups**: Ask follow-up questions for clarification
4. **Context**: Questions are answered based on uploaded documents only

### Understanding Responses
- **Confidence Score**: Green (high), Yellow (medium), Red (low)
- **Response Time**: Time taken to generate the answer
- **Sources**: Clickable sources showing relevant document sections
- **Source Preview**: Snippet of relevant text from documents

## 💡 Best Practices

### Document Preparation
- **Clean Documents**: Ensure documents are well-formatted
- **Logical Structure**: Use clear headings and sections
- **Complete Information**: Include comprehensive details
- **Regular Updates**: Keep documents current

### Effective Questioning
- **Be Specific**: "What is the vacation policy?" vs "Tell me about time off"
- **Use Keywords**: Include relevant terms from your documents
- **Ask One Thing**: Focus on one topic per question
- **Context**: Provide context if the topic is ambiguous

### Examples of Good Questions
```
✅ Good Questions:
- "How many sick days do employees get per year?"
- "What are the password requirements for company systems?"
- "What is the process for submitting expense reports?"
- "How do I request remote work approval?"

❌ Avoid These:
- "Tell me everything about HR" (too broad)
- "What should I do?" (no context)
- "Is this allowed?" (unclear what "this" refers to)
```

## 🔧 Customization

### Configuration Options
Edit `.env` file to customize:

```bash
# AI Model Settings
CHAT_MODEL=gpt-4                    # Use GPT-4 for better accuracy
EMBEDDING_MODEL=text-embedding-3-large  # Better embeddings
TEMPERATURE=0.0                     # More deterministic responses

# Document Processing
CHUNK_SIZE=1500                     # Larger chunks for more context
CHUNK_OVERLAP=300                   # More overlap for better continuity
MAX_RETRIEVAL_DOCS=3               # Fewer sources for faster responses

# Response Settings
MAX_TOKENS=1500                     # Longer responses
```

### Performance Tuning

**For Better Accuracy:**
- Use `gpt-4` instead of `gpt-3.5-turbo`
- Increase `CHUNK_SIZE` to 1500-2000
- Use `text-embedding-3-large`
- Increase `MAX_RETRIEVAL_DOCS` to 7-10

**For Faster Responses:**
- Use `gpt-3.5-turbo`
- Reduce `CHUNK_SIZE` to 800
- Reduce `MAX_RETRIEVAL_DOCS` to 3
- Lower `MAX_TOKENS` to 500

## 📊 Features Overview

### Core Features
- ✅ **Multi-format Support**: PDF, TXT, MD files
- ✅ **Intelligent Chunking**: Optimized document segmentation
- ✅ **Vector Search**: FAISS-powered similarity search
- ✅ **Source Attribution**: See exactly where answers come from
- ✅ **Confidence Scoring**: Know how reliable each answer is
- ✅ **Real-time Processing**: Instant responses to queries
- ✅ **Session Analytics**: Track performance and usage

### Advanced Features
- ✅ **Incremental Updates**: Add documents without rebuilding
- ✅ **Duplicate Detection**: Avoid processing same files twice
- ✅ **Context Preservation**: Maintain conversation context
- ✅ **Response Caching**: Faster repeated queries
- ✅ **Error Handling**: Graceful handling of edge cases
- ✅ **Performance Monitoring**: Real-time metrics display

## 🎯 Use Cases

### HR Department
- Employee policy questions
- Benefits and compensation queries
- Leave and attendance policies
- Performance review procedures

### IT Support
- System access procedures
- Security policy clarification
- Software installation guidelines
- Troubleshooting steps

### Operations
- Standard operating procedures
- Process documentation
- Workflow guidelines
- Compliance requirements

### Training & Onboarding
- New employee orientation
- Role-specific procedures
- Company culture information
- Safety guidelines

## 📈 Performance Metrics

### Target Performance
- **Response Time**: < 3 seconds per query
- **Accuracy**: ≥ 90% for document-based questions
- **Document Processing**: < 30 seconds per document
- **Concurrent Users**: 10-50 users depending on hardware

### Monitoring
- Real-time response times
- Query success rates
- Document processing status
- API usage tracking
- User session analytics

## 🔍 Troubleshooting

### Common Issues

**No answers or "I don't have information":**
- Check if relevant documents are uploaded
- Try rephrasing your question
- Ensure documents contain the information you're seeking
- Verify document processing completed successfully

**Slow responses:**
- Check internet connection
- Reduce `MAX_RETRIEVAL_DOCS` in configuration
- Use `gpt-3.5-turbo` instead of `gpt-4`
- Consider upgrading your OpenAI plan

**Inaccurate answers:**
- Use more specific questions
- Check source documents for accuracy
- Increase `MAX_RETRIEVAL_DOCS` for more context
- Consider using `gpt-4` for complex queries

**Document processing errors:**
- Ensure files are not corrupted
- Check file format is supported
- Verify file size is reasonable (< 50MB)
- Try processing files individually

## 🔒 Security & Privacy

### Data Protection
- Documents stored locally by default
- No data sent to third parties except OpenAI
- API keys encrypted in environment
- Session data cleared on restart

### Recommendations
- Use dedicated OpenAI API key
- Monitor API usage and costs
- Regularly update dependencies
- Implement access controls for sensitive documents

## 📞 Support

### Getting Help
1. **Check this guide** for common solutions
2. **Review error messages** in the application
3. **Check application logs** for detailed error information
4. **Verify configuration** in `.env` file
5. **Test with sample data** to isolate issues

### Technical Requirements
- **Python**: 3.8 or higher
- **Memory**: 4GB+ RAM recommended
- **Storage**: 1GB+ for vector database
- **Internet**: Required for OpenAI API calls

### API Costs (Approximate)
- **Embeddings**: ~$0.01 per 1000 documents
- **Chat**: ~$0.002-0.06 per response (depending on model)
- **Monthly Cost**: $10-50 for typical enterprise usage

The Enterprise Knowledge Assistant is designed to be your intelligent document companion, making company information instantly accessible and searchable. Start with the sample data to explore its capabilities, then upload your own documents to create a customized knowledge base for your organization.
