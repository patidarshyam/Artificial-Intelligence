#!/usr/bin/env python3
"""
Quick verification script for Enterprise Knowledge Assistant
Tests that all dependencies are properly installed and working
"""

import sys
import os

def test_imports():
    """Test all critical imports"""
    print("🔍 Testing critical imports...")
    
    try:
        import streamlit as st
        print("✅ Streamlit imported successfully")
    except ImportError as e:
        print(f"❌ Streamlit import failed: {e}")
        return False
    
    try:
        import openai
        print("✅ OpenAI imported successfully")
    except ImportError as e:
        print(f"❌ OpenAI import failed: {e}")
        return False
    
    try:
        import faiss
        print("✅ FAISS imported successfully")
    except ImportError as e:
        print(f"❌ FAISS import failed: {e}")
        return False
    
    try:
        import PyPDF2
        print("✅ PyPDF2 imported successfully")
    except ImportError as e:
        print(f"❌ PyPDF2 import failed: {e}")
        return False
    
    try:
        import pandas as pd
        import numpy as np
        import plotly
        import tiktoken
        from dotenv import load_dotenv
        print("✅ All supporting libraries imported successfully")
    except ImportError as e:
        print(f"❌ Supporting library import failed: {e}")
        return False
    
    return True

def test_modules():
    """Test our custom modules"""
    print("\n🔍 Testing custom modules...")
    
    try:
        sys.path.append('src')
        from src.document_processor import create_document_processor
        from src.vector_store import create_vector_store
        from src.rag_pipeline import create_rag_pipeline
        from src.utils import count_tokens
        print("✅ All custom modules imported successfully")
        return True
    except ImportError as e:
        print(f"❌ Custom module import failed: {e}")
        return False

def test_basic_functionality():
    """Test basic functionality without API calls"""
    print("\n🔍 Testing basic functionality...")
    
    try:
        # Test document processor
        from src.document_processor import create_document_processor
        processor = create_document_processor()
        
        # Test with sample text
        sample_text = "This is a test document for the Enterprise Knowledge Assistant."
        chunks = processor.chunk_text(sample_text, "test.txt")
        
        if chunks and len(chunks) > 0:
            print("✅ Document processing works")
        else:
            print("❌ Document processing failed")
            return False
        
        # Test token counting
        from src.utils import count_tokens
        token_count = count_tokens("This is a test sentence.")
        
        if isinstance(token_count, int) and token_count > 0:
            print("✅ Token counting works")
        else:
            print("❌ Token counting failed")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Basic functionality test failed: {e}")
        return False

def main():
    print("🚀 Enterprise Knowledge Assistant - Verification Test")
    print("=" * 55)
    
    # Test imports
    if not test_imports():
        print("\n❌ Import tests failed. Please check your installation.")
        return False
    
    # Test custom modules
    if not test_modules():
        print("\n❌ Custom module tests failed. Please check the src/ directory.")
        return False
    
    # Test basic functionality
    if not test_basic_functionality():
        print("\n❌ Basic functionality tests failed.")
        return False
    
    print("\n" + "=" * 55)
    print("🎉 All tests passed! Your installation is ready.")
    print("\n📋 Next steps:")
    print("1. Create a .env file with your OpenAI API key:")
    print("   cp .env.example .env")
    print("   # Then edit .env and add: OPENAI_API_KEY=your_key_here")
    print("\n2. Run the application:")
    print("   streamlit run app.py")
    print("\n3. Or try the demo:")
    print("   python demo.py")
    print("\n🚀 Happy knowledge assisting!")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
