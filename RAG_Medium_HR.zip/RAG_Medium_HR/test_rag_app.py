"""
Test suite for the Enterprise Knowledge Assistant
Run these tests to validate the RAG pipeline functionality
"""

import os
import sys
import pytest
import tempfile
from typing import List, Dict, Any

# Add src to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.document_processor import DocumentProcessor
from src.vector_store import VectorStore
from src.rag_pipeline import RAGPipeline
from src.utils import count_tokens, get_file_hash


class TestDocumentProcessor:
    """Test document processing functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.processor = DocumentProcessor(chunk_size=500, chunk_overlap=100)
        self.sample_text = """
        Company Policy Manual
        
        Section 1: Vacation Policy
        All full-time employees are entitled to 15 days of paid vacation per year.
        Vacation requests must be submitted at least 2 weeks in advance.
        
        Section 2: Remote Work Policy
        Employees may work remotely up to 3 days per week with manager approval.
        All remote work must be approved through the HR portal.
        """
    
    def test_text_cleaning(self):
        """Test text cleaning functionality."""
        dirty_text = "This   has    excessive\n\n\nwhitespace  \t  and    weird\rcharacters."
        cleaned = self.processor.clean_text(dirty_text)
        
        assert "excessive whitespace" in cleaned
        assert "  " not in cleaned
        assert "\n\n" not in cleaned
    
    def test_text_chunking(self):
        """Test text chunking with overlap."""
        chunks = self.processor.chunk_text(self.sample_text, "test_doc.txt")
        
        assert len(chunks) > 0
        assert all('text' in chunk for chunk in chunks)
        assert all('filename' in chunk for chunk in chunks)
        assert all('chunk_id' in chunk for chunk in chunks)
        
        # Check that all chunks have content
        assert all(len(chunk['text'].strip()) > 0 for chunk in chunks)
    
    def test_chunk_metadata(self):
        """Test chunk metadata creation."""
        chunks = self.processor.chunk_text(self.sample_text, "test_doc.txt")
        
        for chunk in chunks:
            assert chunk['filename'] == "test_doc.txt"
            assert isinstance(chunk['chunk_id'], int)
            assert chunk['chunk_id'] >= 0
            assert 'token_count' in chunk
            assert 'char_count' in chunk
            assert 'source' in chunk


class TestVectorStore:
    """Test vector store functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        # Use a temporary directory for testing
        self.temp_dir = tempfile.mkdtemp()
        self.vector_store = VectorStore()
        self.vector_store.index_path = self.temp_dir
    
    def test_embedding_generation(self):
        """Test embedding generation (requires API key)."""
        if not os.getenv('OPENAI_API_KEY'):
            pytest.skip("OpenAI API key not available")
        
        text = "This is a test document for embedding generation."
        embedding = self.vector_store.generate_embedding(text)
        
        if embedding is not None:
            assert embedding.shape == (1536,)  # Default embedding dimension
            assert -1.1 <= embedding.max() <= 1.1  # Normalized embeddings
            assert -1.1 <= embedding.min() <= 1.1
    
    def test_empty_index_search(self):
        """Test search on empty index."""
        results = self.vector_store.search("test query")
        assert results == []
    
    def test_stats_empty_index(self):
        """Test statistics on empty index."""
        stats = self.vector_store.get_stats()
        assert stats['total_documents'] == 0
        assert stats['unique_files'] == 0


class TestRAGPipeline:
    """Test RAG pipeline functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.vector_store = VectorStore()
        self.vector_store.index_path = self.temp_dir
        self.rag_pipeline = RAGPipeline(self.vector_store)
    
    def test_system_prompt_creation(self):
        """Test system prompt creation."""
        prompt = self.rag_pipeline._create_system_prompt()
        
        assert "Enterprise Knowledge Assistant" in prompt
        assert "company documents" in prompt
        assert "cite your sources" in prompt
    
    def test_context_creation(self):
        """Test context creation from documents."""
        documents = [
            {
                'filename': 'test1.txt',
                'text': 'This is test document 1.',
                'similarity_score': 0.95
            },
            {
                'filename': 'test2.txt', 
                'text': 'This is test document 2.',
                'similarity_score': 0.87
            }
        ]
        
        context = self.rag_pipeline._create_context_from_documents(documents)
        
        assert '[Source 1: test1.txt' in context
        assert '[Source 2: test2.txt' in context
        assert 'This is test document 1.' in context
        assert 'This is test document 2.' in context
    
    def test_confidence_calculation(self):
        """Test confidence score calculation."""
        # High confidence case
        high_confidence_docs = [
            {'similarity_score': 0.95},
            {'similarity_score': 0.90},
            {'similarity_score': 0.85}
        ]
        
        high_confidence = self.rag_pipeline._calculate_confidence(high_confidence_docs)
        assert high_confidence > 0.7
        
        # Low confidence case
        low_confidence_docs = [
            {'similarity_score': 0.3},
            {'similarity_score': 0.2}
        ]
        
        low_confidence = self.rag_pipeline._calculate_confidence(low_confidence_docs)
        assert low_confidence < 0.5
        
        # Empty case
        empty_confidence = self.rag_pipeline._calculate_confidence([])
        assert empty_confidence == 0.0
    
    def test_conversation_starters(self):
        """Test conversation starter questions."""
        starters = self.rag_pipeline.get_conversation_starter_questions()
        
        assert len(starters) > 0
        assert all(isinstance(q, str) for q in starters)
        assert any('vacation' in q.lower() for q in starters)
        assert any('password' in q.lower() for q in starters)


class TestUtils:
    """Test utility functions."""
    
    def test_token_counting(self):
        """Test token counting functionality."""
        text = "This is a test sentence for token counting."
        token_count = count_tokens(text)
        
        assert isinstance(token_count, int)
        assert token_count > 0
        assert token_count < len(text)  # Should be fewer tokens than characters
    
    def test_file_hash_generation(self):
        """Test file hash generation."""
        content1 = b"This is test content 1"
        content2 = b"This is test content 2"
        content1_copy = b"This is test content 1"
        
        hash1 = get_file_hash(content1)
        hash2 = get_file_hash(content2)
        hash1_copy = get_file_hash(content1_copy)
        
        assert hash1 != hash2  # Different content should have different hashes
        assert hash1 == hash1_copy  # Same content should have same hash
        assert len(hash1) == 32  # MD5 hash length


class TestIntegration:
    """Integration tests for the complete RAG pipeline."""
    
    def setup_method(self):
        """Set up integration test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        
        self.processor = DocumentProcessor(chunk_size=200, chunk_overlap=50)
        self.vector_store = VectorStore()
        self.vector_store.index_path = self.temp_dir
        self.rag_pipeline = RAGPipeline(self.vector_store)
        
        # Sample documents
        self.sample_docs = {
            "hr_policy.txt": """
            HR Policy Manual
            
            Vacation Policy:
            All employees get 15 vacation days per year.
            Requests must be submitted 2 weeks in advance.
            
            Sick Leave Policy:
            Employees get 10 sick days per year.
            Medical documentation required for 3+ consecutive days.
            """,
            
            "it_manual.txt": """
            IT Security Manual
            
            Password Requirements:
            - Minimum 12 characters
            - Must include uppercase, lowercase, numbers, symbols
            - Change every 90 days
            
            Software Installation:
            All software requires IT approval.
            Submit requests through ServiceDesk portal.
            """
        }
    
    @pytest.mark.skipif(not os.getenv('OPENAI_API_KEY'), reason="OpenAI API key not available")
    def test_end_to_end_workflow(self):
        """Test complete workflow from document ingestion to question answering."""
        
        # Step 1: Process documents
        all_chunks = []
        for filename, content in self.sample_docs.items():
            chunks = self.processor.process_text_content(content, filename)
            all_chunks.extend(chunks)
        
        assert len(all_chunks) > 0
        
        # Step 2: Add to vector store
        success = self.vector_store.add_documents(all_chunks)
        assert success
        
        # Step 3: Test search
        search_results = self.vector_store.search("vacation days")
        assert len(search_results) > 0
        assert any('vacation' in result['text'].lower() for result in search_results)
        
        # Step 4: Test RAG pipeline
        response = self.rag_pipeline.answer_question("How many vacation days do employees get?")
        
        assert 'answer' in response
        assert len(response['answer']) > 0
        assert 'sources' in response
        assert response['confidence'] > 0
        
        # Check that the answer contains relevant information
        answer_lower = response['answer'].lower()
        assert '15' in answer_lower or 'fifteen' in answer_lower
    
    @pytest.mark.skipif(not os.getenv('OPENAI_API_KEY'), reason="OpenAI API key not available")
    def test_no_relevant_documents(self):
        """Test behavior when no relevant documents are found."""
        
        # Add documents
        all_chunks = []
        for filename, content in self.sample_docs.items():
            chunks = self.processor.process_text_content(content, filename)
            all_chunks.extend(chunks)
        
        self.vector_store.add_documents(all_chunks)
        
        # Ask about something not in the documents
        response = self.rag_pipeline.answer_question("What is the company's pet policy?")
        
        assert 'answer' in response
        assert 'don\'t have information' in response['answer'].lower()
        assert response['confidence'] == 0.0 or len(response['sources']) == 0


def run_tests():
    """Run all tests."""
    pytest.main([__file__, "-v"])


if __name__ == "__main__":
    run_tests()
