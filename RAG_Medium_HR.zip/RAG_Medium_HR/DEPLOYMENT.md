# Deployment Guide for Enterprise Knowledge Assistant

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- OpenAI API key (get one at [OpenAI Platform](https://platform.openai.com/api-keys))

### Easy Setup (Recommended)

**On macOS/Linux:**
```bash
./setup.sh
```

**On Windows:**
```cmd
setup.bat
```

### Manual Setup

1. **Clone/Download the project**
2. **Create virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment:**
   ```bash
   cp .env.example .env
   # Edit .env and add your OpenAI API key
   ```

5. **Run the application:**
   ```bash
   streamlit run app.py
   ```

## 🌐 Production Deployment

### Option 1: Streamlit Cloud (Easiest)

1. **Push code to GitHub repository**
2. **Visit [Streamlit Cloud](https://streamlit.io/cloud)**
3. **Connect your GitHub repository**
4. **Add environment variables:**
   - `OPENAI_API_KEY`: Your OpenAI API key
5. **Deploy**

### Option 2: Docker Deployment

1. **Create Dockerfile:**
```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8501

CMD ["streamlit", "run", "app.py", "--server.port=8501", "--server.address=0.0.0.0"]
```

2. **Build and run:**
```bash
docker build -t enterprise-knowledge-assistant .
docker run -p 8501:8501 -e OPENAI_API_KEY=your_key_here enterprise-knowledge-assistant
```

### Option 3: AWS EC2 Deployment

1. **Launch EC2 instance** (Ubuntu 20.04 LTS recommended)
2. **SSH into instance and setup:**
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv git
git clone your-repo-url
cd enterprise-knowledge-assistant
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

3. **Configure environment:**
```bash
cp .env.example .env
nano .env  # Add your OpenAI API key
```

4. **Run with PM2 for process management:**
```bash
sudo npm install -g pm2
pm2 start "streamlit run app.py --server.port=8501 --server.address=0.0.0.0" --name knowledge-assistant
pm2 startup
pm2 save
```

5. **Setup Nginx reverse proxy:**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:8501;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Option 4: Heroku Deployment

1. **Create Procfile:**
```
web: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0
```

2. **Deploy:**
```bash
heroku create your-app-name
heroku config:set OPENAI_API_KEY=your_key_here
git push heroku main
```

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENAI_API_KEY` | Your OpenAI API key | Required |
| `EMBEDDING_MODEL` | OpenAI embedding model | `text-embedding-3-small` |
| `CHAT_MODEL` | OpenAI chat model | `gpt-3.5-turbo` |
| `CHUNK_SIZE` | Document chunk size | `1000` |
| `CHUNK_OVERLAP` | Chunk overlap size | `200` |
| `MAX_RETRIEVAL_DOCS` | Max documents to retrieve | `5` |
| `MAX_TOKENS` | Max response tokens | `1000` |
| `TEMPERATURE` | Response creativity | `0.1` |

### Performance Tuning

**For large document collections:**
- Increase `CHUNK_SIZE` to 1500-2000
- Reduce `CHUNK_OVERLAP` to 100-150
- Use `text-embedding-3-large` for better accuracy
- Consider using `gpt-4` for complex queries

**For faster responses:**
- Reduce `MAX_RETRIEVAL_DOCS` to 3
- Use smaller `CHUNK_SIZE` (800-1000)
- Use `gpt-3.5-turbo` instead of `gpt-4`

## 📊 Monitoring & Analytics

### Health Checks
```bash
curl http://localhost:8501/_stcore/health
```

### Logs
```bash
# View Streamlit logs
tail -f ~/.streamlit/logs/streamlit.log

# With PM2
pm2 logs knowledge-assistant
```

### Metrics to Monitor
- Response time per query
- Document processing time
- Vector database size
- API usage and costs
- User session duration

## 🔒 Security Considerations

### Production Security Checklist

- [ ] **API Key Security**: Never expose OpenAI API key in client-side code
- [ ] **File Upload Limits**: Restrict file sizes and types
- [ ] **Input Validation**: Sanitize user inputs
- [ ] **Rate Limiting**: Implement request rate limiting
- [ ] **HTTPS**: Use SSL certificates in production
- [ ] **Authentication**: Add user authentication if needed
- [ ] **Data Privacy**: Ensure document confidentiality
- [ ] **Access Logs**: Monitor and log access patterns

### Authentication Setup (Optional)

For enterprise deployment, add authentication:

```python
import streamlit_authenticator as stauth

# In app.py
names = ['John Doe', 'Jane Smith']
usernames = ['jdoe', 'jsmith']
passwords = ['abc123', 'def456']  # Use hashed passwords

hashed_passwords = stauth.Hasher(passwords).generate()

authenticator = stauth.Authenticate(
    names, usernames, hashed_passwords,
    'knowledge_assistant', 'abcdef', cookie_expiry_days=30
)

name, authentication_status, username = authenticator.login('Login', 'main')

if authentication_status == True:
    # Show main app
    main()
elif authentication_status == False:
    st.error('Username/password is incorrect')
elif authentication_status == None:
    st.warning('Please enter your username and password')
```

## 🎯 Scaling Considerations

### Horizontal Scaling
- Use load balancers for multiple instances
- Implement sticky sessions for user state
- Use shared vector database (Redis/PostgreSQL with pgvector)

### Database Scaling
- For large document collections, consider:
  - PostgreSQL with pgvector extension
  - Pinecone or Weaviate for managed vector databases
  - Qdrant for self-hosted vector database

### Cost Optimization
- Cache embeddings to avoid regeneration
- Use batch processing for large uploads
- Monitor OpenAI API usage
- Consider fine-tuned models for domain-specific tasks

## 🐛 Troubleshooting

### Common Issues

**Application won't start:**
- Check Python version (3.8+ required)
- Verify all dependencies installed
- Check OpenAI API key in .env file

**Slow responses:**
- Reduce document chunk size
- Limit number of retrieved documents
- Use faster embedding model

**Out of memory errors:**
- Reduce batch size for document processing
- Use streaming for large files
- Increase server memory allocation

**Vector database corruption:**
- Delete vector_db directory
- Re-upload documents to rebuild index

### Debug Mode
```bash
# Run with debug logging
STREAMLIT_LOGGER_LEVEL=debug streamlit run app.py
```

## 📞 Support

For issues and questions:
1. Check the troubleshooting section above
2. Review application logs
3. Check OpenAI API status
4. Verify environment configuration

## 🔄 Updates

To update the application:
1. Backup your vector database and documents
2. Pull latest changes
3. Update dependencies: `pip install -r requirements.txt`
4. Restart the application

The application includes automatic migration handling for database schema changes.
