#!/bin/bash

# Enterprise Knowledge Assistant - Quick Setup Script
# This script sets up the environment and runs the application

set -e  # Exit on any error

echo "🚀 Setting up Enterprise Knowledge Assistant..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    echo "Please install Python 3.8 or higher from https://www.python.org/"
    exit 1
fi

# Check Python version
python_version=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
required_version="3.8"

if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" != "$required_version" ]; then
    echo "❌ Python $required_version or higher is required. Found: $python_version"
    exit 1
fi

echo "✅ Python $python_version found"

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
    echo "✅ Virtual environment created"
fi

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install requirements
echo "📚 Installing requirements..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
    echo "✅ Requirements installed"
else
    echo "❌ requirements.txt not found"
    exit 1
fi

# Check for .env file
if [ ! -f ".env" ]; then
    echo "⚠️ .env file not found. Creating from template..."
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo "📝 Please edit .env file and add your OpenAI API key"
        echo "   You can get an API key from: https://platform.openai.com/api-keys"
        echo ""
        echo "❗ IMPORTANT: Set OPENAI_API_KEY in .env before proceeding"
        echo ""
        read -p "Press Enter after you've updated the .env file..."
    else
        echo "❌ .env.example not found"
        exit 1
    fi
fi

# Check if OpenAI API key is set
source .env
if [ -z "$OPENAI_API_KEY" ] || [ "$OPENAI_API_KEY" = "your_openai_api_key_here" ]; then
    echo "❌ OpenAI API key not set in .env file"
    echo "   Please edit .env and set OPENAI_API_KEY=your_actual_api_key"
    exit 1
fi

echo "✅ OpenAI API key found"

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p data vector_db

echo "✅ Setup complete!"
echo ""
echo "🎉 Starting Enterprise Knowledge Assistant..."
echo "   The app will open in your browser at http://localhost:8501"
echo ""
echo "💡 Tips:"
echo "   - Upload PDF or text files using the sidebar"
echo "   - Try the sample data to get started quickly"
echo "   - Ask questions in natural language"
echo ""

# Run the Streamlit app
streamlit run app.py
