#!/bin/bash

# Enterprise Knowledge Assistant Launcher
echo "🚀 Starting Enterprise Knowledge Assistant..."

# Activate virtual environment
source venv/bin/activate

# Set the environment
export PYTHONPATH="${PYTHONPATH}:$(pwd)/src"

# Start the application
echo "📱 Starting Streamlit application..."
echo "🌐 The app will be available at: http://localhost:8501"
echo "📝 Press Ctrl+C to stop the application"
echo ""

streamlit run app.py --server.port=8501 --server.address=localhost
