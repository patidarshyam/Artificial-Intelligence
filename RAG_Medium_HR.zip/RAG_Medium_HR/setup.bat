@echo off
REM Enterprise Knowledge Assistant - Windows Setup Script

echo 🚀 Setting up Enterprise Knowledge Assistant...

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python is required but not installed.
    echo Please install Python 3.8 or higher from https://www.python.org/
    pause
    exit /b 1
)

echo ✅ Python found

REM Create virtual environment if it doesn't exist
if not exist "venv" (
    echo 📦 Creating virtual environment...
    python -m venv venv
    echo ✅ Virtual environment created
)

REM Activate virtual environment
echo 🔄 Activating virtual environment...
call venv\Scripts\activate.bat

REM Upgrade pip
echo ⬆️ Upgrading pip...
python -m pip install --upgrade pip

REM Install requirements
echo 📚 Installing requirements...
if exist "requirements.txt" (
    pip install -r requirements.txt
    echo ✅ Requirements installed
) else (
    echo ❌ requirements.txt not found
    pause
    exit /b 1
)

REM Check for .env file
if not exist ".env" (
    echo ⚠️ .env file not found. Creating from template...
    if exist ".env.example" (
        copy ".env.example" ".env"
        echo 📝 Please edit .env file and add your OpenAI API key
        echo    You can get an API key from: https://platform.openai.com/api-keys
        echo.
        echo ❗ IMPORTANT: Set OPENAI_API_KEY in .env before proceeding
        echo.
        pause
    ) else (
        echo ❌ .env.example not found
        pause
        exit /b 1
    )
)

REM Create necessary directories
echo 📁 Creating directories...
if not exist "data" mkdir data
if not exist "vector_db" mkdir vector_db

echo ✅ Setup complete!
echo.
echo 🎉 Starting Enterprise Knowledge Assistant...
echo    The app will open in your browser at http://localhost:8501
echo.
echo 💡 Tips:
echo    - Upload PDF or text files using the sidebar
echo    - Try the sample data to get started quickly
echo    - Ask questions in natural language
echo.

REM Run the Streamlit app
streamlit run app.py

pause
