"""
Utility functions for the Enterprise Knowledge Assistant
"""

import os
import hashlib
import tiktoken
from typing import List, Dict, Any
import streamlit as st
from datetime import datetime
import json


def count_tokens(text: str, model: str = "gpt-4o-mini-2024-07-18") -> int:
    """Count the number of tokens in a text string."""
    try:
        encoding = tiktoken.encoding_for_model(model)
        return len(encoding.encode(text))
    except:
        # Fallback estimation: ~4 characters per token
        return len(text) // 4


def get_file_hash(file_content: bytes) -> str:
    """Generate a hash for file content to detect duplicates."""
    return hashlib.md5(file_content).hexdigest()


def format_response_with_sources(response: str, sources: List[Dict[str, Any]]) -> str:
    """Format the AI response with source citations."""
    if not sources:
        return response
    
    # Add source citations to the response
    formatted_response = response + "\n\n**Sources:**\n"
    for i, source in enumerate(sources, 1):
        filename = source.get('filename', 'Unknown')
        page = source.get('page', 'N/A')
        formatted_response += f"{i}. {filename} (Page: {page})\n"
    
    return formatted_response


def validate_file_type(file) -> bool:
    """Validate if the uploaded file is supported."""
    if file is None:
        return False
    
    allowed_extensions = ['.pdf', '.txt', '.md']
    file_extension = os.path.splitext(file.name)[1].lower()
    return file_extension in allowed_extensions


def get_file_info(file) -> Dict[str, Any]:
    """Extract file information."""
    return {
        'name': file.name,
        'size': file.size,
        'type': file.type,
        'extension': os.path.splitext(file.name)[1].lower()
    }


def safe_filename(filename: str) -> str:
    """Create a safe filename for storage."""
    # Remove or replace unsafe characters
    safe_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_"
    return "".join(c if c in safe_chars else "_" for c in filename)


def log_interaction(query: str, response: str, sources: List[Dict], response_time: float):
    """Log user interactions for analytics (optional)."""
    log_entry = {
        'timestamp': datetime.now().isoformat(),
        'query': query,
        'response_length': len(response),
        'sources_count': len(sources),
        'response_time': response_time
    }
    
    # In a production environment, you might want to save this to a database
    # For now, we'll just store it in session state for the current session
    if 'interaction_log' not in st.session_state:
        st.session_state.interaction_log = []
    
    st.session_state.interaction_log.append(log_entry)


def display_metrics():
    """Display performance metrics in the sidebar."""
    if 'interaction_log' not in st.session_state:
        return
    
    log = st.session_state.interaction_log
    if not log:
        return
    
    with st.sidebar:
        st.subheader("📊 Session Analytics")
        
        total_queries = len(log)
        avg_response_time = sum(entry['response_time'] for entry in log) / total_queries
        avg_sources = sum(entry['sources_count'] for entry in log) / total_queries
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Queries", total_queries)
            st.metric("Avg Response Time", f"{avg_response_time:.2f}s")
        
        with col2:
            st.metric("Avg Sources", f"{avg_sources:.1f}")
            
        # Response time chart
        if total_queries > 1:
            import plotly.graph_objects as go
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                y=[entry['response_time'] for entry in log],
                mode='lines+markers',
                name='Response Time',
                line=dict(color='#1f77b4')
            ))
            fig.update_layout(
                title="Response Time Trend",
                yaxis_title="Seconds",
                xaxis_title="Query #",
                height=200,
                margin=dict(l=0, r=0, t=30, b=0)
            )
            st.plotly_chart(fig, use_container_width=True)


def create_sample_documents():
    """Create sample documents for testing purposes."""
    sample_docs = {
        "hr_policy_sample.txt": """
HR POLICY MANUAL - SAMPLE

1. VACATION POLICY
All full-time employees are entitled to 15 days of paid vacation per year.
Vacation requests must be submitted at least 2 weeks in advance.
Vacation days do not roll over to the next year.

2. REMOTE WORK POLICY
Employees may work remotely up to 3 days per week with manager approval.
All remote work must be approved in advance through the HR portal.
Equipment for remote work will be provided by the company.

3. SICK LEAVE POLICY
Employees receive 10 sick days per year.
Sick leave can be used for personal illness or to care for immediate family members.
Medical documentation may be required for absences longer than 3 consecutive days.

4. PERFORMANCE REVIEW PROCESS
Performance reviews are conducted annually in Q4.
Employees will receive feedback on goals, competencies, and career development.
Salary adjustments are based on performance review outcomes.
        """,
        
        "it_manual_sample.txt": """
IT MANUAL - SAMPLE

1. PASSWORD POLICY
Passwords must be at least 12 characters long.
Passwords must include uppercase, lowercase, numbers, and special characters.
Passwords must be changed every 90 days.
Do not reuse the last 5 passwords.

2. SOFTWARE INSTALLATION
All software installations require IT approval.
Submit requests through the IT ServiceDesk portal.
Personal software is not permitted on company devices.

3. DATA BACKUP PROCEDURES
All critical data must be backed up daily.
Use the company-approved cloud storage solution.
Local backups should be stored on designated network drives.
Test backup restoration quarterly.

4. SECURITY INCIDENT REPORTING
Report security incidents immediately to security@company.com
Include date, time, affected systems, and description of the incident.
Do not attempt to resolve security incidents independently.
        """,
        
        "sop_sample.txt": """
STANDARD OPERATING PROCEDURES - SAMPLE

1. CUSTOMER ONBOARDING PROCESS
Step 1: Collect customer requirements and documentation
Step 2: Create customer account in CRM system
Step 3: Schedule kickoff meeting within 5 business days
Step 4: Assign dedicated customer success manager
Step 5: Conduct training sessions as needed

2. EXPENSE REPORTING PROCEDURE
All expenses must be submitted within 30 days of incurrence.
Receipts are required for all expenses over $25.
Submit expense reports through the finance portal.
Manager approval is required before reimbursement.

3. MEETING ROOM BOOKING
Meeting rooms can be booked through the office calendar system.
Maximum booking duration is 4 hours.
Cancel unused bookings at least 1 hour in advance.
Clean up the room after use.

4. VENDOR MANAGEMENT PROCESS
All new vendors must complete the vendor registration process.
Conduct due diligence review for vendors over $50K annual spend.
Contracts must be reviewed by legal department.
Performance reviews conducted annually for all active vendors.
        """
    }
    
    return sample_docs


def initialize_sample_data():
    """Initialize the app with sample documents if no documents are uploaded."""
    if 'documents_processed' not in st.session_state:
        st.session_state.documents_processed = False
    
    if not st.session_state.documents_processed:
        sample_docs = create_sample_documents()
        
        # Save sample documents to data directory
        for filename, content in sample_docs.items():
            data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
            os.makedirs(data_dir, exist_ok=True)
            file_path = os.path.join(data_dir, filename)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
        
        return sample_docs
    
    return {}
