"""
Vector store management using FAISS for the Enterprise Knowledge Assistant
Handles embedding generation, storage, and similarity search
"""

import os
import pickle
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
import faiss
import streamlit as st
from openai import OpenAI
import json
from datetime import datetime
import requests
from requests.auth import HTTPBasicAuth
import urllib3
import warnings

# Suppress SSL warnings for development
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings('ignore', message='Unverified HTTPS request')


class VectorStore:
    """FAISS-based vector store for document embeddings."""
    
    def __init__(self, embedding_model: str = "text-embedding-3-small", dimension: int = 1536):
        self.embedding_model = embedding_model
        self.dimension = dimension
        self.client = None
        self.index = None
        self.documents = []
        self.metadata = []
        self.index_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "vector_db")
        os.makedirs(self.index_path, exist_ok=True)
        self.gateway_token = None
        
        # Initialize AI Gateway client
        self._initialize_gateway_client()
        
        # Load existing index if available
        self._load_index()
    
    def _initialize_gateway_client(self):
        """Initialize client with OpenAI API or AI Gateway credentials."""
        use_ai_gateway = os.getenv('AI_GATEWAY_ENABLED', 'false').lower() == 'true'
        
        if use_ai_gateway:
            self._initialize_ai_gateway_client()
        else:
            self._initialize_openai_client()
    
    def _initialize_openai_client(self):
        """Initialize OpenAI client directly."""
        api_key = os.getenv('OPENAI_API_KEY')
        base_url = os.getenv('OPENAI_BASE_URL', 'https://api.openai.com/v1')
        
        if not api_key:
            st.warning("⚠️ OpenAI API key not found. Please set OPENAI_API_KEY in your .env file.")
            self.client = None
            return
        
        try:
            self.client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=30
            )
            st.info(f"✅ Connected to OpenAI API")
        except Exception as e:
            st.warning(f"⚠️ OpenAI initialization warning: {str(e)}")
            self.client = None
    
    def _initialize_ai_gateway_client(self):
        """Initialize AI Gateway client with OAuth credentials - Deere AI Gateway."""
        client_id = os.getenv('AI_GATEWAY_CLIENT_ID')
        client_secret = os.getenv('AI_GATEWAY_CLIENT_SECRET')
        registration_id = os.getenv('AI_GATEWAY_CLIENT_REGISTRATION')
        okta_endpoint = os.getenv('OKTA_SSO_TOKEN_ENDPOINT')
        gateway_base_url = os.getenv('AI_GATEWAY_BASE_URL', 'https://ai-gateway.deere.com/openai/')
        dummy_api_key = os.getenv('AI_GATEWAY_DUMMY_API_KEY', 'sk-000000000000000000000000000000000000000000000000')
        
        if not all([client_id, client_secret, registration_id, okta_endpoint]):
            st.warning("⚠️ AI Gateway credentials incomplete. Please set AI_GATEWAY_CLIENT_ID, AI_GATEWAY_CLIENT_SECRET, AI_GATEWAY_CLIENT_REGISTRATION, and OKTA_SSO_TOKEN_ENDPOINT.")
            self.client = None
            return
        
        try:
            # Get OAuth token from OKTA with correct scope
            headers = {"Content-Type": "application/x-www-form-urlencoded"}
            data = {
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
                "scope": "mlops.deere.com/model-deployments.llm.region-restricted-invocations",
            }
            
            token_response = requests.post(
                okta_endpoint,
                headers=headers,
                data=data,
                timeout=30,
                verify=False  # Disable SSL verification for development
            )
            token_response.raise_for_status()
            access_token = token_response.json().get('access_token')
            
            if not access_token:
                st.warning("❌ Failed to retrieve access token from OKTA endpoint")
                self.client = None
                return
            
            # Initialize OpenAI client with Deere AI Gateway
            # Use default_headers to pass the authorization and registration ID
            self.client = OpenAI(
                api_key=dummy_api_key,
                base_url=gateway_base_url,
                default_headers={
                    "Authorization": f"Bearer {access_token}",
                    "deere-ai-gateway-registration-id": registration_id,
                },
                timeout=30
            )
            st.success(f"✅ Connected to Deere AI Gateway: {gateway_base_url}")
        except requests.exceptions.Timeout:
            st.warning("⏱️ OKTA token endpoint request timed out. Check your network connection.")
            self.client = None
        except requests.exceptions.ConnectionError:
            st.warning("🔗 Cannot connect to OKTA endpoint. Ensure you have internet access.")
            self.client = None
        except Exception as e:
            st.warning(f"⚠️ AI Gateway initialization error: {str(e)}")
            self.client = None
    
    def _load_index(self):
        """Load existing FAISS index and metadata."""
        try:
            index_file = os.path.join(self.index_path, "faiss_index.index")
            metadata_file = os.path.join(self.index_path, "metadata.pkl")
            documents_file = os.path.join(self.index_path, "documents.pkl")
            
            if os.path.exists(index_file) and os.path.exists(metadata_file):
                # Load FAISS index
                self.index = faiss.read_index(index_file)
                
                # Load metadata
                with open(metadata_file, 'rb') as f:
                    self.metadata = pickle.load(f)
                
                # Load documents
                if os.path.exists(documents_file):
                    with open(documents_file, 'rb') as f:
                        self.documents = pickle.load(f)
                
                # Only show message if there are documents
                if len(self.metadata) > 0:
                    st.success(f"Loaded existing vector database with {len(self.metadata)} documents")
                else:
                    st.info("Vector database is empty. Upload documents to get started.")
            else:
                # Create new index
                self.index = faiss.IndexFlatIP(self.dimension)  # Inner product for cosine similarity
                self.metadata = []
                self.documents = []
                st.info("Created new vector database")
        
        except Exception as e:
            st.error(f"Error loading vector database: {str(e)}")
            # Create new index on error
            self.index = faiss.IndexFlatIP(self.dimension)
            self.metadata = []
            self.documents = []
    
    def _save_index(self):
        """Save FAISS index and metadata to disk."""
        try:
            os.makedirs(self.index_path, exist_ok=True)
            
            # Save FAISS index
            index_file = os.path.join(self.index_path, "faiss_index.index")
            faiss.write_index(self.index, index_file)
            
            # Save metadata
            metadata_file = os.path.join(self.index_path, "metadata.pkl")
            with open(metadata_file, 'wb') as f:
                pickle.dump(self.metadata, f)
            
            # Save documents
            documents_file = os.path.join(self.index_path, "documents.pkl")
            with open(documents_file, 'wb') as f:
                pickle.dump(self.documents, f)
            
            # Save index info
            info_file = os.path.join(self.index_path, "index_info.json")
            with open(info_file, 'w') as f:
                json.dump({
                    'total_documents': len(self.metadata),
                    'embedding_model': self.embedding_model,
                    'dimension': self.dimension,
                    'last_updated': datetime.now().isoformat()
                }, f, indent=2)
            
        except Exception as e:
            st.error(f"Error saving vector database: {str(e)}")
    
    def generate_embedding(self, text: str) -> Optional[np.ndarray]:
        """Generate embedding for a text string."""
        if not self.client:
            st.error("OpenAI client not initialized")
            return None
        
        try:
            response = self.client.embeddings.create(
                model=self.embedding_model,
                input=text.replace("\n", " ")
            )
            
            embedding = np.array(response.data[0].embedding, dtype=np.float32)
            
            # Normalize for cosine similarity
            embedding = embedding / np.linalg.norm(embedding)
            
            return embedding
        
        except Exception as e:
            st.error(f"Error generating embedding: {str(e)}")
            return None
    
    def add_documents(self, chunks: List[Dict[str, Any]]) -> bool:
        """Add document chunks to the vector store."""
        if not chunks:
            return True
        
        if not self.client:
            st.error("Cannot add documents: OpenAI client not initialized")
            return False
        
        try:
            # Generate embeddings for all chunks
            embeddings = []
            valid_chunks = []
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            for i, chunk in enumerate(chunks):
                status_text.text(f"Processing chunk {i+1}/{len(chunks)}")
                
                embedding = self.generate_embedding(chunk['text'])
                if embedding is not None:
                    embeddings.append(embedding)
                    valid_chunks.append(chunk)
                
                progress_bar.progress((i + 1) / len(chunks))
            
            if not embeddings:
                st.error("No valid embeddings generated")
                return False
            
            # Add to FAISS index
            embeddings_matrix = np.vstack(embeddings)
            self.index.add(embeddings_matrix)
            
            # Store metadata and documents
            self.metadata.extend(valid_chunks)
            self.documents.extend([chunk['text'] for chunk in valid_chunks])
            
            # Save to disk
            self._save_index()
            
            progress_bar.empty()
            status_text.empty()
            
            st.success(f"Added {len(valid_chunks)} documents to vector database")
            return True
        
        except Exception as e:
            st.error(f"Error adding documents to vector store: {str(e)}")
            return False
    
    def search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Search for similar documents using vector similarity."""
        if not self.client or self.index.ntotal == 0:
            return []
        
        try:
            # Generate query embedding
            query_embedding = self.generate_embedding(query)
            if query_embedding is None:
                return []
            
            # Reshape for FAISS
            query_vector = query_embedding.reshape(1, -1)
            
            # Search
            scores, indices = self.index.search(query_vector, min(top_k, self.index.ntotal))
            
            # Prepare results
            results = []
            for i, (score, idx) in enumerate(zip(scores[0], indices[0])):
                if idx < len(self.metadata):
                    result = self.metadata[idx].copy()
                    result['similarity_score'] = float(score)
                    result['rank'] = i + 1
                    results.append(result)
            
            return results
        
        except Exception as e:
            st.error(f"Error searching vector store: {str(e)}")
            return []
    
    def get_stats(self) -> Dict[str, Any]:
        """Get vector store statistics."""
        if not self.index:
            return {}
        
        total_docs = self.index.ntotal
        unique_files = len(set(meta.get('filename', '') for meta in self.metadata))
        
        # Calculate average chunk sizes
        if self.metadata:
            avg_tokens = sum(meta.get('token_count', 0) for meta in self.metadata) / len(self.metadata)
            avg_chars = sum(meta.get('char_count', 0) for meta in self.metadata) / len(self.metadata)
        else:
            avg_tokens = avg_chars = 0
        
        return {
            'total_documents': total_docs,
            'unique_files': unique_files,
            'embedding_model': self.embedding_model,
            'vector_dimension': self.dimension,
            'average_tokens_per_chunk': avg_tokens,
            'average_chars_per_chunk': avg_chars,
            'index_size_mb': self._get_index_size_mb()
        }
    
    def _get_index_size_mb(self) -> float:
        """Get the size of the index files in MB."""
        try:
            total_size = 0
            for filename in os.listdir(self.index_path):
                file_path = os.path.join(self.index_path, filename)
                if os.path.isfile(file_path):
                    total_size += os.path.getsize(file_path)
            return total_size / (1024 * 1024)  # Convert to MB
        except:
            return 0.0
    
    def clear_database(self):
        """Clear all data from the vector store."""
        try:
            # Reset index and data first
            self.index = faiss.IndexFlatIP(self.dimension)
            self.metadata = []
            self.documents = []
            
            # Remove all saved files
            if os.path.exists(self.index_path):
                for filename in os.listdir(self.index_path):
                    file_path = os.path.join(self.index_path, filename)
                    try:
                        if os.path.isfile(file_path):
                            os.remove(file_path)
                    except Exception as e:
                        print(f"Warning: Could not delete {file_path}: {e}")
            
            return True
        
        except Exception as e:
            st.error(f"Error clearing vector database: {str(e)}")
            return False
    
    def delete_by_filename(self, filename: str):
        """Delete all chunks from a specific file."""
        try:
            # Find indices to remove
            indices_to_remove = []
            for i, meta in enumerate(self.metadata):
                if meta.get('filename') == filename:
                    indices_to_remove.append(i)
            
            if not indices_to_remove:
                st.warning(f"No documents found for file: {filename}")
                return
            
            # Remove from metadata and documents (in reverse order to maintain indices)
            for idx in reversed(indices_to_remove):
                del self.metadata[idx]
                del self.documents[idx]
            
            # Rebuild FAISS index (FAISS doesn't support deletion, so we rebuild)
            self._rebuild_index()
            
            st.success(f"Removed {len(indices_to_remove)} chunks from {filename}")
        
        except Exception as e:
            st.error(f"Error deleting file from vector store: {str(e)}")
    
    def _rebuild_index(self):
        """Rebuild the FAISS index from existing documents."""
        if not self.documents:
            self.index = faiss.IndexFlatIP(self.dimension)
            self._save_index()
            return
        
        # Generate embeddings for all remaining documents
        embeddings = []
        for doc in self.documents:
            embedding = self.generate_embedding(doc)
            if embedding is not None:
                embeddings.append(embedding)
        
        if embeddings:
            # Create new index
            self.index = faiss.IndexFlatIP(self.dimension)
            embeddings_matrix = np.vstack(embeddings)
            self.index.add(embeddings_matrix)
            
            # Save to disk
            self._save_index()


def create_vector_store() -> VectorStore:
    """Factory function to create a vector store with default settings."""
    embedding_model = os.getenv('EMBEDDING_MODEL', 'text-embedding-3-small')
    
    # Determine dimension based on model
    dimension = 1536 if 'text-embedding-3-small' in embedding_model else 1536
    
    return VectorStore(embedding_model=embedding_model, dimension=dimension)
