"""
RAG (Retrieval-Augmented Generation) pipeline for the Enterprise Knowledge Assistant
Combines document retrieval with AI generation for accurate, grounded responses
"""

import os
from typing import List, Dict, Any, Optional, Tuple
import streamlit as st
from openai import OpenAI
import time
from datetime import datetime
import requests
from requests.auth import HTTPBasicAuth
import urllib3
import warnings
from src.vector_store import VectorStore
from src.utils import count_tokens, log_interaction

# Suppress SSL warnings for development
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings('ignore', message='Unverified HTTPS request')


class RAGPipeline:
    """Complete RAG pipeline for question answering."""
    
    def __init__(self, vector_store: VectorStore, chat_model: str = "gpt-4o-mini-2024-07-18"):
        self.vector_store = vector_store
        self.chat_model = chat_model
        self.client = None
        self.max_tokens = int(os.getenv('MAX_TOKENS', 1000))
        self.temperature = float(os.getenv('TEMPERATURE', 0.1))
        self.max_retrieval_docs = int(os.getenv('MAX_RETRIEVAL_DOCS', 5))
        self.gateway_token = None
        
        # Initialize AI Gateway client
        self._initialize_gateway_client()
    
    def _initialize_gateway_client(self):
        """Initialize client with OpenAI API or AI Gateway credentials."""
        use_ai_gateway = os.getenv('AI_GATEWAY_ENABLED', 'false').lower() == 'true'
        
        if use_ai_gateway:
            self._initialize_ai_gateway_client()
        else:
            self._initialize_openai_client()
    
    def _initialize_openai_client(self):
        """Initialize OpenAI client directly."""
        api_key = os.getenv('OPENAI_API_KEY')
        base_url = os.getenv('OPENAI_BASE_URL', 'https://api.openai.com/v1')
        
        if not api_key:
            st.warning("⚠️ OpenAI API key not found. Please set OPENAI_API_KEY in your .env file.")
            self.client = None
            return
        
        try:
            self.client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=30
            )
            st.info(f"✅ Connected to OpenAI API")
        except Exception as e:
            st.warning(f"⚠️ OpenAI initialization warning: {str(e)}")
            self.client = None
    
    def _initialize_ai_gateway_client(self):
        """Initialize AI Gateway client with OAuth credentials - Deere AI Gateway."""
        client_id = os.getenv('AI_GATEWAY_CLIENT_ID')
        client_secret = os.getenv('AI_GATEWAY_CLIENT_SECRET')
        registration_id = os.getenv('AI_GATEWAY_CLIENT_REGISTRATION')
        okta_endpoint = os.getenv('OKTA_SSO_TOKEN_ENDPOINT')
        gateway_base_url = os.getenv('AI_GATEWAY_BASE_URL', 'https://ai-gateway.deere.com/openai/')
        dummy_api_key = os.getenv('AI_GATEWAY_DUMMY_API_KEY', 'sk-000000000000000000000000000000000000000000000000')
        
        if not all([client_id, client_secret, registration_id, okta_endpoint]):
            st.warning("⚠️ AI Gateway credentials incomplete. Please set AI_GATEWAY_CLIENT_ID, AI_GATEWAY_CLIENT_SECRET, AI_GATEWAY_CLIENT_REGISTRATION, and OKTA_SSO_TOKEN_ENDPOINT.")
            self.client = None
            return
        
        try:
            # Get OAuth token from OKTA with correct scope
            headers = {"Content-Type": "application/x-www-form-urlencoded"}
            data = {
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
                "scope": "mlops.deere.com/model-deployments.llm.region-restricted-invocations",
            }
            
            token_response = requests.post(
                okta_endpoint,
                headers=headers,
                data=data,
                timeout=30,
                verify=False  # Disable SSL verification for development
            )
            token_response.raise_for_status()
            access_token = token_response.json().get('access_token')
            
            if not access_token:
                st.warning("❌ Failed to retrieve access token from OKTA endpoint")
                self.client = None
                return
            
            # Initialize OpenAI client with Deere AI Gateway
            # Use default_headers to pass the authorization and registration ID
            self.client = OpenAI(
                api_key=dummy_api_key,
                base_url=gateway_base_url,
                default_headers={
                    "Authorization": f"Bearer {access_token}",
                    "deere-ai-gateway-registration-id": registration_id,
                },
                timeout=30
            )
            st.success(f"✅ Connected to Deere AI Gateway: {gateway_base_url}")
        except requests.exceptions.Timeout:
            st.warning("⏱️ OKTA token endpoint request timed out. Check your network connection.")
            self.client = None
        except requests.exceptions.ConnectionError:
            st.warning("🔗 Cannot connect to OKTA endpoint. Ensure you have internet access.")
            self.client = None
        except Exception as e:
            st.warning(f"⚠️ AI Gateway initialization error: {str(e)}")
            self.client = None
    
    def retrieve_relevant_documents(self, query: str, top_k: Optional[int] = None) -> List[Dict[str, Any]]:
        """Retrieve relevant documents for a query."""
        if top_k is None:
            top_k = self.max_retrieval_docs
        
        return self.vector_store.search(query, top_k=top_k)
    
    def _create_context_from_documents(self, documents: List[Dict[str, Any]]) -> str:
        """Create context string from retrieved documents."""
        if not documents:
            return ""
        
        context_parts = []
        for i, doc in enumerate(documents, 1):
            filename = doc.get('filename', 'Unknown')
            text = doc.get('text', '')
            score = doc.get('similarity_score', 0.0)
            
            context_parts.append(f"[Source {i}: {filename} (Relevance: {score:.3f})]\n{text}\n")
        
        return "\n".join(context_parts)
    
    def _create_system_prompt(self) -> str:
        """Create the system prompt for the AI assistant."""
        return """You are an Enterprise Knowledge Assistant designed to help employees find accurate information from company documents.

INSTRUCTIONS:
1. Answer questions ONLY based on the provided context from company documents
2. If the answer is not in the provided context, clearly state that you don't have that information
3. Always cite your sources by referencing the source numbers [Source 1], [Source 2], etc.
4. Provide clear, concise, and actionable answers
5. If multiple sources contain relevant information, synthesize them appropriately
6. For policy questions, provide exact policy details when available
7. If information seems incomplete, mention what additional details might be needed

STYLE:
- Professional and helpful tone
- Use bullet points or numbered lists for clarity when appropriate
- Highlight key information (policies, deadlines, requirements)
- Be concise but comprehensive

Remember: You are a trusted assistant helping employees navigate company information. Accuracy and source attribution are crucial."""
    
    def _create_user_prompt(self, query: str, context: str) -> str:
        """Create the user prompt with query and context."""
        if not context:
            return f"""Question: {query}

No relevant documents were found in the company knowledge base for this question. Please let the user know that you don't have information about this topic and suggest they contact the relevant department or check with their manager."""
        
        return f"""Context from company documents:
{context}

Question: {query}

Please provide a comprehensive answer based on the context above. Remember to cite your sources using [Source X] notation."""
    
    def generate_response(self, query: str, retrieved_docs: List[Dict[str, Any]]) -> Tuple[str, List[Dict[str, Any]]]:
        """Generate AI response based on query and retrieved documents."""
        if not self.client:
            error_msg = "Cannot process request: OpenAI/Gateway client not initialized. Check your configuration."
            st.error(f"❌ {error_msg}")
            return f"I'm sorry, but I cannot process your request at the moment. {error_msg}", []
        
        try:
            # Create context from retrieved documents
            context = self._create_context_from_documents(retrieved_docs)
            
            # Create prompts
            system_prompt = self._create_system_prompt()
            user_prompt = self._create_user_prompt(query, context)
            
            # Check token limits
            total_tokens = count_tokens(system_prompt + user_prompt, self.chat_model)
            max_context_tokens = 3000  # Leave room for response
            
            if total_tokens > max_context_tokens:
                # Truncate context if too long
                context = self._truncate_context(context, max_context_tokens - count_tokens(system_prompt + query))
                user_prompt = self._create_user_prompt(query, context)
            
            try:
                # Generate response with detailed error handling
                response = self.client.chat.completions.create(
                    model=self.chat_model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    max_tokens=self.max_tokens,
                    temperature=self.temperature,
                    top_p=0.9,
                    frequency_penalty=0.1,
                    presence_penalty=0.1
                )
            except Exception as api_error:
                error_detail = str(api_error)
                st.error(f"❌ API Error: {error_detail}")
                print(f"API Error Details: {error_detail}")
                if "Connection" in error_detail or "timeout" in error_detail.lower():
                    return "I apologize, but there's a connection issue with the AI service. Please check your gateway configuration and network connection.", []
                else:
                    return f"I apologize, but I encountered an API error: {error_detail}", []
            
            ai_response = response.choices[0].message.content.strip()
            
            # Prepare source information
            sources = self._prepare_sources(retrieved_docs)
            
            return ai_response, sources
        
        except Exception as e:
            error_msg = f"Error generating response: {str(e)}"
            st.error(f"❌ {error_msg}")
            print(f"Full error traceback: {error_msg}")
            import traceback
            traceback.print_exc()
            return "I apologize, but I encountered an error while processing your question. Please try again.", []
    
    def _truncate_context(self, context: str, max_tokens: int) -> str:
        """Truncate context to fit within token limits."""
        if count_tokens(context) <= max_tokens:
            return context
        
        # Split by sources and truncate
        sources = context.split("[Source")
        truncated_parts = ["[Source" + sources[0]]  # Keep first part
        current_tokens = count_tokens(truncated_parts[0])
        
        for i in range(1, len(sources)):
            source_text = "[Source" + sources[i]
            source_tokens = count_tokens(source_text)
            
            if current_tokens + source_tokens > max_tokens:
                break
            
            truncated_parts.append(source_text)
            current_tokens += source_tokens
        
        return "".join(truncated_parts)
    
    def _prepare_sources(self, retrieved_docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Prepare source information for display."""
        sources = []
        for doc in retrieved_docs:
            sources.append({
                'filename': doc.get('filename', 'Unknown'),
                'chunk_id': doc.get('chunk_id', 0),
                'similarity_score': doc.get('similarity_score', 0.0),
                'text_preview': doc.get('text', '')[:200] + "..." if len(doc.get('text', '')) > 200 else doc.get('text', ''),
                'full_text': doc.get('text', ''),
                'source_id': doc.get('source', 'Unknown')
            })
        return sources
    
    def answer_question(self, query: str) -> Dict[str, Any]:
        """Complete RAG pipeline: retrieve and generate answer."""
        start_time = time.time()
        
        try:
            # Step 1: Retrieve relevant documents
            retrieved_docs = self.retrieve_relevant_documents(query)
            
            if not retrieved_docs:
                response = """I don't have information about this topic in the current knowledge base. 

This could mean:
- The information isn't available in the uploaded documents
- Your question might need to be phrased differently
- You might need to contact the relevant department directly

Please try rephrasing your question or contact your manager or the appropriate department for assistance."""
                
                end_time = time.time()
                return {
                    'answer': response,
                    'sources': [],
                    'retrieval_count': 0,
                    'response_time': end_time - start_time,
                    'confidence': 0.0
                }
            
            # Step 2: Generate AI response
            ai_response, sources = self.generate_response(query, retrieved_docs)
            
            # Step 3: Calculate confidence score
            confidence = self._calculate_confidence(retrieved_docs)
            
            end_time = time.time()
            response_time = end_time - start_time
            
            # Log the interaction
            log_interaction(query, ai_response, sources, response_time)
            
            return {
                'answer': ai_response,
                'sources': sources,
                'retrieval_count': len(retrieved_docs),
                'response_time': response_time,
                'confidence': confidence,
                'query': query,
                'timestamp': datetime.now().isoformat()
            }
        
        except Exception as e:
            end_time = time.time()
            error_response = f"I apologize, but I encountered an error while processing your question: {str(e)}"
            
            return {
                'answer': error_response,
                'sources': [],
                'retrieval_count': 0,
                'response_time': end_time - start_time,
                'confidence': 0.0,
                'error': str(e)
            }
    
    def _calculate_confidence(self, retrieved_docs: List[Dict[str, Any]]) -> float:
        """Calculate confidence score based on retrieval quality."""
        if not retrieved_docs:
            return 0.0
        
        # Base confidence on similarity scores
        scores = [doc.get('similarity_score', 0.0) for doc in retrieved_docs]
        
        if not scores:
            return 0.0
        
        # Weight: highest score gets most weight, others contribute less
        weighted_score = scores[0] * 0.5
        if len(scores) > 1:
            weighted_score += sum(scores[1:]) * 0.3 / len(scores[1:])
        
        # Additional factors
        doc_count_factor = min(len(scores) / self.max_retrieval_docs, 1.0) * 0.2
        
        # Normalize to 0-1 range
        confidence = min(weighted_score + doc_count_factor, 1.0)
        
        return confidence
    
    def get_conversation_starter_questions(self) -> List[str]:
        """Get sample questions to help users get started."""
        return [
            "What is the company's vacation policy?",
            "How do I submit an expense report?",
            "What are the password requirements for company systems?",
            "How do I request remote work approval?",
            "What is the process for booking meeting rooms?",
            "How do I report a security incident?",
            "What are the performance review procedures?",
            "How do I onboard a new customer?",
            "What is the sick leave policy?",
            "How do I install new software on my work computer?"
        ]
    
    def suggest_related_questions(self, current_query: str, retrieved_docs: List[Dict[str, Any]]) -> List[str]:
        """Suggest related questions based on retrieved documents."""
        if not retrieved_docs:
            return []
        
        # Extract key topics from retrieved documents
        topics = set()
        for doc in retrieved_docs:
            filename = doc.get('filename', '').lower()
            if 'hr' in filename or 'policy' in filename:
                topics.update(['vacation', 'sick leave', 'performance review', 'benefits'])
            elif 'it' in filename or 'manual' in filename:
                topics.update(['password', 'software', 'security', 'backup'])
            elif 'sop' in filename or 'procedure' in filename:
                topics.update(['process', 'workflow', 'approval', 'booking'])
        
        # Generate related questions based on topics
        question_templates = {
            'vacation': "How many vacation days do employees get?",
            'sick leave': "What is the sick leave policy?",
            'password': "What are the password requirements?",
            'security': "How do I report a security incident?",
            'process': "What is the customer onboarding process?",
            'booking': "How do I book a meeting room?"
        }
        
        suggestions = []
        for topic in list(topics)[:3]:  # Limit to 3 suggestions
            if topic in question_templates:
                suggestions.append(question_templates[topic])
        
        return suggestions


def create_rag_pipeline(vector_store: VectorStore) -> RAGPipeline:
    """Factory function to create a RAG pipeline with default settings."""
    chat_model = os.getenv('CHAT_MODEL', 'gpt-4o-mini-2024-07-18')
    return RAGPipeline(vector_store=vector_store, chat_model=chat_model)
