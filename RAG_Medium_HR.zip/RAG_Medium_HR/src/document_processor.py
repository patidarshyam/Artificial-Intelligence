"""
Document processing module for the Enterprise Knowledge Assistant
Handles PDF and text file extraction, cleaning, and chunking
"""

import os
import re
from typing import List, Dict, Any, Optional
import PyPDF2
from io import StringIO
import streamlit as st
from src.utils import count_tokens, get_file_hash, safe_filename


class DocumentProcessor:
    """Process and chunk documents for vector storage."""
    
    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.processed_files = set()
    
    def extract_text_from_pdf(self, file) -> str:
        """Extract text content from PDF file."""
        try:
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            
            for page_num, page in enumerate(pdf_reader.pages):
                try:
                    page_text = page.extract_text()
                    if page_text.strip():  # Only add non-empty pages
                        text += f"\n--- Page {page_num + 1} ---\n"
                        text += page_text
                except Exception as e:
                    st.warning(f"Could not extract text from page {page_num + 1}: {str(e)}")
                    continue
            
            return text
        
        except Exception as e:
            st.error(f"Error processing PDF: {str(e)}")
            return ""
    
    def extract_text_from_txt(self, file) -> str:
        """Extract text content from text file."""
        try:
            # Handle both uploaded files and string content
            if hasattr(file, 'read'):
                content = file.read()
                if isinstance(content, bytes):
                    content = content.decode('utf-8')
                return content
            else:
                return str(file)
        
        except Exception as e:
            st.error(f"Error processing text file: {str(e)}")
            return ""
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text content."""
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^\w\s\.\,\!\?\:\;\-\(\)\[\]\"\'\/]', '', text)
        
        # Remove page separators if they exist
        text = re.sub(r'--- Page \d+ ---', '', text)
        
        # Normalize line breaks
        text = re.sub(r'\n+', '\n', text)
        
        return text.strip()
    
    def chunk_text(self, text: str, filename: str) -> List[Dict[str, Any]]:
        """Split text into chunks with metadata."""
        if not text:
            return []
        
        # Clean the text first
        cleaned_text = self.clean_text(text)
        
        # Split into sentences for better chunking
        sentences = re.split(r'(?<=[.!?])\s+', cleaned_text)
        
        chunks = []
        current_chunk = ""
        current_tokens = 0
        chunk_id = 0
        
        for sentence in sentences:
            sentence_tokens = count_tokens(sentence)
            
            # If adding this sentence would exceed chunk size, save current chunk
            if current_tokens + sentence_tokens > self.chunk_size and current_chunk:
                chunks.append(self._create_chunk_metadata(
                    current_chunk.strip(), 
                    filename, 
                    chunk_id,
                    current_tokens
                ))
                
                # Start new chunk with overlap
                overlap_text = self._get_overlap_text(current_chunk, self.chunk_overlap)
                current_chunk = overlap_text + " " + sentence
                current_tokens = count_tokens(current_chunk)
                chunk_id += 1
            else:
                current_chunk += " " + sentence
                current_tokens += sentence_tokens
        
        # Add the last chunk if it has content
        if current_chunk.strip():
            chunks.append(self._create_chunk_metadata(
                current_chunk.strip(), 
                filename, 
                chunk_id,
                current_tokens
            ))
        
        return chunks
    
    def _create_chunk_metadata(self, text: str, filename: str, chunk_id: int, token_count: int) -> Dict[str, Any]:
        """Create metadata for a text chunk."""
        return {
            'text': text,
            'filename': filename,
            'chunk_id': chunk_id,
            'token_count': token_count,
            'char_count': len(text),
            'source': f"{filename}_chunk_{chunk_id}"
        }
    
    def _get_overlap_text(self, text: str, max_tokens: int) -> str:
        """Get the last portion of text for overlap."""
        if not text or max_tokens <= 0:
            return ""
        
        # Split into words and take the last portion
        words = text.split()
        overlap_words = []
        token_count = 0
        
        # Build overlap from the end backwards
        for word in reversed(words):
            word_tokens = count_tokens(word)
            if token_count + word_tokens > max_tokens:
                break
            overlap_words.insert(0, word)
            token_count += word_tokens
        
        return " ".join(overlap_words)
    
    def process_uploaded_file(self, file) -> List[Dict[str, Any]]:
        """Process an uploaded file and return chunks."""
        if not file:
            return []
        
        # Check for duplicates
        file_content = file.read()
        file_hash = get_file_hash(file_content)
        
        if file_hash in self.processed_files:
            st.warning(f"File {file.name} has already been processed.")
            return []
        
        # Reset file pointer
        file.seek(0)
        
        # Extract text based on file type
        file_extension = os.path.splitext(file.name)[1].lower()
        
        if file_extension == '.pdf':
            text = self.extract_text_from_pdf(file)
        elif file_extension in ['.txt', '.md']:
            text = self.extract_text_from_txt(file)
        else:
            st.error(f"Unsupported file type: {file_extension}")
            return []
        
        if not text:
            st.error(f"No text could be extracted from {file.name}")
            return []
        
        # Save file to data directory for reference
        safe_name = safe_filename(file.name)
        data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
        os.makedirs(data_dir, exist_ok=True)
        file_path = os.path.join(data_dir, safe_name)
        
        with open(file_path, 'wb') as f:
            f.write(file_content)
        
        # Process and chunk the text
        chunks = self.chunk_text(text, file.name)
        
        # Mark file as processed
        self.processed_files.add(file_hash)
        
        return chunks
    
    def process_text_content(self, text: str, filename: str) -> List[Dict[str, Any]]:
        """Process raw text content and return chunks."""
        if not text:
            return []
        
        return self.chunk_text(text, filename)
    
    def get_processing_stats(self, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get statistics about processed chunks."""
        if not chunks:
            return {}
        
        total_tokens = sum(chunk['token_count'] for chunk in chunks)
        total_chars = sum(chunk['char_count'] for chunk in chunks)
        avg_chunk_size = total_tokens / len(chunks) if chunks else 0
        
        return {
            'total_chunks': len(chunks),
            'total_tokens': total_tokens,
            'total_characters': total_chars,
            'average_chunk_size': avg_chunk_size,
            'files_processed': len(set(chunk['filename'] for chunk in chunks))
        }
    
    def validate_chunks(self, chunks: List[Dict[str, Any]]) -> bool:
        """Validate that chunks are properly formatted."""
        required_fields = ['text', 'filename', 'chunk_id', 'source']
        
        for chunk in chunks:
            for field in required_fields:
                if field not in chunk:
                    st.error(f"Chunk missing required field: {field}")
                    return False
            
            if not chunk['text'] or not chunk['text'].strip():
                st.error("Found chunk with empty text")
                return False
        
        return True


def create_document_processor() -> DocumentProcessor:
    """Factory function to create a document processor with default settings."""
    # Get settings from environment or use defaults
    chunk_size = int(os.getenv('CHUNK_SIZE', 1000))
    chunk_overlap = int(os.getenv('CHUNK_OVERLAP', 200))
    
    return DocumentProcessor(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
