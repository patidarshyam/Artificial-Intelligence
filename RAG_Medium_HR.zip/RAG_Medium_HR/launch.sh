#!/bin/bash

echo "🚀 Enterprise Knowledge Assistant - Launcher"
echo "============================================="
echo ""

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "❌ .env file not found. Please create it first:"
    echo "   cp .env.example .env"
    echo "   # Then edit .env and add your OpenAI API key"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "❌ Virtual environment not found. Please run setup first:"
    echo "   ./setup.sh"
    exit 1
fi

echo "📦 Activating virtual environment..."
source venv/bin/activate

echo "🔑 Checking OpenAI API key..."
if ! grep -q "sk-" .env; then
    echo "⚠️  Warning: OpenAI API key not found or invalid in .env file"
    echo "   Please ensure your .env file contains: OPENAI_API_KEY=sk-..."
    echo ""
fi

echo "🌐 Starting Streamlit application..."
echo "📍 URL: http://localhost:8501"
echo "📝 Press Ctrl+C to stop the application"
echo ""
echo "💡 Tips:"
echo "   - Upload PDF or text files using the sidebar"
echo "   - Try the 'Load Sample Data' button to get started"
echo "   - Ask questions in natural language"
echo ""

# Start Streamlit
export PYTHONPATH="${PYTHONPATH}:$(pwd)/src"
streamlit run app.py --server.port=8501 --server.address=localhost --browser.gatherUsageStats=false
